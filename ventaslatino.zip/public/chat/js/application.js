$('[data-toggle="confirmation"]').confirmation();
$('[data-toggle="confirmation-singleton"]').confirmation({ singleton: true });
$('[data-toggle="confirmation-popout"]').confirmation({ popout: true });

