<?php
define('RUNNING_FROM_ROOT', true);
include 'public/index.php';
?>