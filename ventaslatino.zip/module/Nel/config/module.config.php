<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                    'type' => 'Zend\Mvc\Router\Http\Literal',
                    'options' => array(
                        'route'    => '/',
                        'defaults' => array(
                            'controller' => 'Nel\Controller\Index',
                            'action'     => 'index',
                        ),
                    ),
                    'may_terminate' => true,
                        'child_routes' => array(
                            'default' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '[:controller[/:action][/:id]]',
                                    'constraints' => array(
                                        'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*'
                                    ),
                                    'defaults' => array(
                                        'action' => 'index',
                                        '__NAMESPACE__' => 'Nel\Controller'
                                        
                                    )
                                )
                            )
                        )
                    ),
        ),
    ),
    'service_manager' => array(
        'abstract_factories' => array(
            'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
            'Zend\Log\LoggerAbstractServiceFactory',
        ),
        'aliases' => array(
            'translator' => 'MvcTranslator',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'Nel\Controller\Index' => 'Nel\Controller\IndexController',
            'Nel\Controller\Login' => 'Nel\Controller\LoginController',
            'Nel\Controller\Tiendas' => 'Nel\Controller\TiendasController',
            'Nel\Controller\Productos' => 'Nel\Controller\ProductosController',
            'Nel\Controller\Configuracion' => 'Nel\Controller\ConfiguracionController',
            'Nel\Controller\Contactodir' => 'Nel\Controller\ContactodirController',
            'Nel\Controller\ContactoTienda' => 'Nel\Controller\ContactoTiendaController',
            'Nel\Controller\DireccionTienda' => 'Nel\Controller\DireccionTiendaController',
            'Nel\Controller\CantonProvincia' => 'Nel\Controller\CantonProvinciaController',
            'Nel\Controller\ParroquiaCanton' => 'Nel\Controller\ParroquiaCantonController',
            'Nel\Controller\CategoriaProducto' => 'Nel\Controller\CategoriaProductoController',
            'Nel\Controller\FotosProductos' => 'Nel\Controller\FotosProductosController',
            'Nel\Controller\CaracteristicaProducto' => 'Nel\Controller\CaracteristicaProductoController',
            'Nel\Controller\PrecioProducto' => 'Nel\Controller\PrecioProductoController',
            'Nel\Controller\FotosTienda' => 'Nel\Controller\FotosTiendaController',
            'Nel\Controller\NombreTienda' => 'Nel\Controller\NombreTiendaController',
            'Nel\Controller\DescripcionTienda' => 'Nel\Controller\DescripcionTiendaController',
            'Nel\Controller\Certificacion' => 'Nel\Controller\CertificacionController',
            'Nel\Controller\Legal' => 'Nel\Controller\LegalController',
            'Nel\Controller\Usuario' => 'Nel\Controller\UsuarioController',
            'Nel\Controller\Pedidos' => 'Nel\Controller\PedidosController',
            'Nel\Controller\CabeceraPedido' => 'Nel\Controller\CabeceraPedidoController',
        ),
    ),
    'view_manager' => array(
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'layout/login'           => __DIR__ . '/../view/layout/login.phtml',
            'layout/inicio'           => __DIR__ . '/../view/layout/inicio.phtml',
            'layout/renovar'           => __DIR__ . '/../view/layout/renovar.phtml',
            'nel/index/index' => __DIR__ . '/../view/nel/index/index.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
        
        //poder usar el ajax
        'strategies' => array (
            'ViewJsonStrategy'
        ),
    ),
    // Placeholder for console routes
    'console' => array(
        'router' => array(
            'routes' => array(
            ),
        ),
    ),
);
