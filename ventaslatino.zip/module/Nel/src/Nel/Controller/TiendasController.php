<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\DescripcionTienda;
use Nel\Modelo\Entity\FotoTienda;
use Nel\Modelo\Entity\NombreTienda;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter;

class TiendasController extends AbstractActionController
{
    public $dbAdapter;
    public function filtrartiendasAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCodigos = new Codigos($this->dbAdapter);
                $objDescripcionTienda = new DescripcionTienda($this->dbAdapter);
                $objFotoTienda = new FotoTienda($this->dbAdapter);
                $objNombreTienda = new NombreTienda($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $codigoEncriptado = $post['codigo'];
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTiendas = $this->dbAdapter->query("select *
                        from `tiendas` inner join `asignartipotienda` on `tiendas`.`idTienda` = `asignartipotienda`.`idTienda`
                        inner join `tipotienda` on `tipotienda`.`idTipoTienda` = `asignartipotienda`.`idTipoTienda`
                        where `tiendas`.`idUsuario` = $idUsuario ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                        if(count($listaTiendas) == 0){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO HAY TIENDAS DISPONIBLES</div>';
                        }else{
                            $tabla = '';
                            foreach ($listaTiendas as $valueTiendas){
                                $nombreUsuario = $valueTiendas['nombreUsuario'];
                                $listaDescripcionTienda = $objDescripcionTienda->filtrarDescripcionTiendaPorTiendaActivo($valueTiendas['idTienda']);
                                $listaNombreTienda = $objNombreTienda->filtrarNombreTiendaPorTiendaActivo($valueTiendas['idTienda']);
                                $listaFotoTienda = $objFotoTienda->filtrarFotoTiendaPorTiendaActivo($valueTiendas['idTienda']);
                                
                                $tipoTienda = $valueTiendas['descripcionTipoTienda'];
                                $descripcionTienda = "";
                                if(count($listaDescripcionTienda) == 1){
                                    $descripcionTienda = $listaDescripcionTienda[0]['descripcionTienda'];
                                }
                                $fotoTienda = '<img class="img-responsive" src="'.$this->getRequest()->getBaseUrl().'/public/images/otras/nodisponible.png" alt="">'; 
                                if(count($listaFotoTienda) > 0){
                                    $fotoTienda = '<img class="img-responsive" src="'.$this->getRequest()->getBaseUrl().$listaFotoTienda[0]['rutaFoto'].'" alt="">'; 
                                }
                                $nombreTienda = 'SIN NOMBRE';
                                if(count($listaNombreTienda) == 1){
                                    $nombreTienda = $listaNombreTienda[0]['nombreTienda'];
                                }
                                
                                $tabla = $tabla.'<div class="col-sm-4">
                                    <div class="product-image-wrapper">
                                        <div class="single-products">
                                            <div class="productinfo text-center">
                                                '.$fotoTienda.'
                                                <h4>'.$nombreTienda.'</h4>
                                                <p>
                                                    '.$tipoTienda.'
                                                </p>
                                            </div>
                                            <div class="product-overlay">
                                                <div class="overlay-content">
                                                    <h2>Detalle</h2>
                                                    <p>
                                                        '.$descripcionTienda.'
                                                    </p>
                                                    <a href="'.$this->getRequest()->getBaseUrl().'/index/configuracion/'.$nombreUsuario.'" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Ir a tienda</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>';
                            }
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    
}