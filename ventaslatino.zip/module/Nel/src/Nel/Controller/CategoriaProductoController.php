<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\CategoriaProducto;
use Nel\Modelo\Entity\AsignarCategoriaProducto;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\Tiendas;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter;

class CategoriaProductoController extends AbstractActionController
{
    public $dbAdapter;
    
    public function movercategoriaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
            
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objAsignarCategoriaProducto = new AsignarCategoriaProducto($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTiendaModalMover'];
                $perteneceAEncriptado = $post['idPerteneceAModalMover'];
                $idAsignarCategoriaEncriptado = trim($post['idAsignarCategoriaModalMover']);
                $codigoEncriptado = $post['codModalMover'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($perteneceAEncriptado == NULL || $perteneceAEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idAsignarCategoriaEncriptado == NULL || $idAsignarCategoriaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $perteneceA = 0;
                            if($perteneceAEncriptado != '0'){
                                $perteneceA = $objMetodos->desencriptar($perteneceAEncriptado);
                            }
                            $idAsignarCategoria = $objMetodos->desencriptar($idAsignarCategoriaEncriptado);
                            if(!is_numeric($perteneceA)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else if(!is_numeric($idAsignarCategoria)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaAsignarCategoria = $this->dbAdapter->query("select * 
                                from `asignarcategoriaproducto` inner join `categoriaproducto` 
                                on `asignarcategoriaproducto`.`idCategoria` = `categoriaproducto`.`idCategoriaProducto`
                                where `asignarcategoriaproducto`.`idAsignarCategoriaProducto` =  $idAsignarCategoria   
                                ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                                
                                if(count($listaAsignarCategoria) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA CATEGORÍA</div>';
                                }else if($listaAsignarCategoria[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTA CATEGORÍA NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    if($perteneceA == 0){
                                        $perteneceA = NULL;
                                    }
                                    $arrayAsignarCategoria = array(
                                      'perteneceA'=>$perteneceA  
                                    );
                                    if($objAsignarCategoriaProducto->actualizarAsignarCategoriaProducto($idAsignarCategoria, $arrayAsignarCategoria) == FALSE){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MOVIÓ LA CATEGORÍA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $mensaje = '<div class="alert alert-success text-center" role="alert">SE HA MOVIDO LA CETEGORÍA EXITOSAMENTE</div>';
                                        $validar = TRUE;
                                    }
                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'id'=>$idAsignarCategoriaEncriptado,'idT'=>$idTiendaEncriptado));
                                }
                            }
                            
                        }
                    }
                }
                return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
            }
        }
    }
    
    public function filtrarformmmovercategoriaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $codigoEncriptado = $post['cod3'];
                $idAsignarCategoriaEncriptado = $post['id'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idAsignarCategoriaEncriptado == NULL || $idAsignarCategoriaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        $idAsignarCategoria = $objMetodos->desencriptar($idAsignarCategoriaEncriptado);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else if(!is_numeric($idAsignarCategoria)){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $listaAsignarCategoria = $this->dbAdapter->query("select * 
                                from `asignarcategoriaproducto` inner join `categoriaproducto` 
                                on `asignarcategoriaproducto`.`idCategoria` = `categoriaproducto`.`idCategoriaProducto`
                                where `asignarcategoriaproducto`.`idAsignarCategoriaProducto` = $idAsignarCategoria  
                                ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                            if(count($listaAsignarCategoria) != 1){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA CATEGORÍA</div>';
                            }else if($listaAsignarCategoria[0]['idTienda'] != $idTienda){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTA CATEGORÍA NO PERTENECE A SU TIENDA</div>';
                            }else{
                                
                                
                                $idCategoria = $listaAsignarCategoria[0]['idCategoria'];
                                $perteneceA = $listaAsignarCategoria[0]['perteneceA'];
                                
                                
                                
                                $consulta = '';
                                if($perteneceA != NULL){
                                    $consulta="`asignarcategoriaproducto`.`idCategoria` != $perteneceA and";
                                }else{
                                   $consulta="`asignarcategoriaproducto`.`idCategoria` != $idCategoria and";
                                }
                                
                                $listaAsignarCategoriaPrincipales = $this->dbAdapter->query("select * 
                                from `asignarcategoriaproducto` inner join `categoriaproducto` 
                                on `asignarcategoriaproducto`.`idCategoria` = `categoriaproducto`.`idCategoriaProducto`
                                where $consulta `asignarcategoriaproducto`.`idTienda` = $idTienda and `asignarcategoriaproducto`.`perteneceA` is null  
                                order by `categoriaproducto`.`descripcionCategoria` asc",Adapter::QUERY_MODE_EXECUTE)->toArray();
                                $options = '<option value="0">MOVER A LA RAÍZ</option>';
                                if($listaAsignarCategoria[0]['perteneceA'] == NULL){
                                    $options = '';
                                }
                                foreach ($listaAsignarCategoriaPrincipales as $value) {
                                    $idAsignarCategoriaProducto3 = $value['idAsignarCategoriaProducto'];
                                    $listaProductos = $this->dbAdapter->query("select * 
                                       from `productos`
                                       where `productos`.`idAsignarCategoriaProducto` = $idAsignarCategoriaProducto3
                                       limit  1 ",Adapter::QUERY_MODE_EXECUTE)->toArray();                                        
                                    if(count($listaProductos) == 0){
                                        $idCategoriaEncriptado2 = $objMetodos->encriptar($value['idCategoria']);
                                        $options = $options.'<option value="'.$idCategoriaEncriptado2.'">'.$value['descripcionCategoria'].'</option>';
                                    }
                                }

                                $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                                if(count($listaCodigo3) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else{
                                    $codigoInsertar = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);


                                    $tabla='<h5 class="text-center">MOVER '.$listaAsignarCategoria[0]['descripcionCategoria'].'</h5>
                                            <input type="hidden" id="codModalMover" name="codModalMover" value="'.$codigoInsertar.'">
                                            <input type="hidden" id="idTiendaModalMover" name="idTiendaModalMover" value="'.$idTiendaEncriptado.'">
                                            <input id="idAsignarCategoriaModalMover" name="idAsignarCategoriaModalMover" type="hidden" value="'.$idAsignarCategoriaEncriptado.'">
                                            <div class="form-group">
                                                <select id="idPerteneceAModalMover" name="idPerteneceAModalMover" class="form-control">
                                                    '.$options.'
                                                </select>
                                            </div><div class="form-group text-center"><button  id="btnGuardarMoverCategoria" class="btn btn-danger btn-square btn-sm" data-loading-text="GUARDANDO..." type="submit">GUARDAR</button></div>';
                                    $mensaje = '';
                                    $validar = TRUE;
                                    return  new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    public function deshabilitarcategoriaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
            
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objAsignarCategoriaProducto = new AsignarCategoriaProducto($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $idAsignarCategoriaProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod3'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idAsignarCategoriaProductoEncriptado == NULL || $idAsignarCategoriaProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(4);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">hNO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idAsignarCategoriaProducto = $objMetodos->desencriptar($idAsignarCategoriaProductoEncriptado);
                            $listaAsignarCategoriaProducto = $objAsignarCategoriaProducto->filtrarAsignarCategoriaProducto($idAsignarCategoriaProducto);
                            if(count($listaAsignarCategoriaProducto) != 1){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA CATEGORÍA</div>';
                            }else{
                                $listaPerteneceA = array();
                                $perteneceA = $listaAsignarCategoriaProducto[0]['perteneceA'];
                                if($perteneceA == NULL){
                                    $listaPerteneceA = $objAsignarCategoriaProducto->filtrarAsignarCategoriaProductoPorTiendaActivo($idTienda, NULL);
                                }else{
                                    $listaPerteneceA = $objAsignarCategoriaProducto->filtrarAsignarCategoriaProductoPorTiendaActivo($idTienda, $perteneceA);
                                }
                                
                                if(count($listaPerteneceA) >= 10 && $perteneceA == NULL &&  $listaAsignarCategoriaProducto[0]['estado'] == FALSE){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">SÓLO SE PUEDEN HABILITAR MÁXIMO 10 CATEGORÍAS PRINCIPALES, PARA PODER HABILITARLA DEBE DESHABILITAR UNA DIFERENTE</div>';
                                }else if(count($listaPerteneceA) >= 10 && $perteneceA > 0 &&  $listaAsignarCategoriaProducto[0]['estado'] == FALSE){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">SÓLO SE PUEDEN HABILITAR MÁXIMO 10 SUBCATEGORÍAS POR CATEGORÍA, PARA PODER HABILITARLA DEBE DESHABILITAR UNA DIFERENTE</div>';
                                }else{
                                    $estado = TRUE;
                                    if($listaAsignarCategoriaProducto[0]['estado'] == TRUE){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE DESHABILITÓ LA CATEGORÍA COMUNÍQUESE CON NEL - LATINO</div>';
                                        $estado = 0;
                                    }else{
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE HABILITÓ LA CATEGORÍA COMUNÍQUESE CON NEL - LATINO</div>';
                                    }
                                    $array = array(
                                        'estado'=>$estado
                                    );   
                                    if($objAsignarCategoriaProducto->actualizarAsignarCategoriaProducto($idAsignarCategoriaProducto, $array) == FALSE){
                                        $mensaje = $mensaje;
                                    }else{
                                        $mensaje = '';
                                        $validar = TRUE;
                                    }
                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'id'=>$idTiendaEncriptado));
                                }
                            }
                        }
                    }
                }
                return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
            }
        }
    }
    
    public function eliminarcategoriaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objAsignarCategoriaProducto = new AsignarCategoriaProducto($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $idAsignarCategoriaProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod3'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idAsignarCategoriaProductoEncriptado == NULL || $idAsignarCategoriaProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(4);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idAsignarCategoriaProducto = $objMetodos->desencriptar($idAsignarCategoriaProductoEncriptado);
                            $listaAsignarCategoriaProducto = $objAsignarCategoriaProducto->filtrarAsignarCategoriaProducto($idAsignarCategoriaProducto);
                            if(count($listaAsignarCategoriaProducto) != 1){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA CATEGORÍA</div>';
                            }else{
                                $listaProductos = $this->dbAdapter->query("select * 
                                from `productos`
                                where `productos`.`idAsignarCategoriaProducto` = $idAsignarCategoriaProducto
                                limit  1 ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                                if(count($listaProductos) > 0){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTA CATEGORÍA NO PUEDE SER ELIMINADA PORQUE YA CONTIENE PRODUCTOS</div>';
                                }else{
                                    
                                    $objAsignarCategoriaProducto->eliminarAsignarCategoriaProducto($idAsignarCategoriaProducto);
                                    $listaAsignarCategoriaProducto2 = $objAsignarCategoriaProducto->filtrarAsignarCategoriaProductoActivo($idAsignarCategoriaProducto);
                                    if(count($listaAsignarCategoriaProducto2) > 0){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE ELIMINÓ LA CATEGORÍA COMUNÍQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $mensaje = '';
                                        $validar = TRUE;
                                    }
                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'id'=>$idTiendaEncriptado));
                                }
                            }
                        }
                    }
                }
                return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
            }
        }
    }

    public function ingresarcategoriaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objAsignarCategoriaProducto = new AsignarCategoriaProducto($this->dbAdapter);
                $objCategoriaProducto = new CategoriaProducto($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTienda'];
                $perteneceAEncriptado = $post['pertenecea'];
                $descripcionCategoria = trim($post['descripcionCategoria']);
                $codigoEncriptado = $post['cod2'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($perteneceAEncriptado == NULL){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($objMetodos->soloLetras($descripcionCategoria) == FALSE || strlen($descripcionCategoria) > 22){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE PERMITEN CARACTERES ESPECIALES Y MÁXIMO 22 CARTACTERES</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                           
                            if($perteneceAEncriptado != '0'){
                                $perteneceA = $objMetodos->desencriptar($perteneceAEncriptado);
                            }else{
                                $perteneceA = 0;
                            }
                            if(!is_numeric($perteneceA)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert"> NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                             }else{
                                $listaCategoriasPerteneceA = array();
                                if($perteneceAEncriptado != '0'){
                                   $listaCategoriasPerteneceA = $objAsignarCategoriaProducto->filtrarAsignarCategoriaProductoPorTiendaActivo($idTienda, $perteneceA);
                                }else{
                                   $listaCategoriasPerteneceA = $objAsignarCategoriaProducto->filtrarAsignarCategoriaProductoPorTiendaActivo($idTienda, NULL);
                                }
                                 
                                 if(count($listaCategoriasPerteneceA) >= 10 && $perteneceA == 0){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">SÓLO SE PUEDEN INGRESAR MÁXIMO 10 CATEGORÍAS PRINCIPALES</div>';
                                 }else if(count($listaCategoriasPerteneceA) >= 10 && $perteneceA > 0){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">SÓLO SE PUEDEN INGRESAR MÁXIMO 10 SUBCATEGORÍAS POR CATEGORÍA</div>';
                                 }else{
                                    $arrayCategoriaProducto = array(
                                        'descripcionCategoria'=>  strtoupper($descripcionCategoria),
                                        'estadoCategoria'=>TRUE
                                    );
                                    $idCategoriaProducto = $objCategoriaProducto->ingresarCategoriaProducto($arrayCategoriaProducto);
                                    
                                    
                                    
                                    if($idCategoriaProducto == 0){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE INGRESÓ LA CATEGORÍA COMUNÍQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $perteneceA2 = NULL;
                                        if($perteneceA != 0){
                                            $perteneceA2 = $perteneceA;
                                        }
                                        $arrayAsignarCategoriaProducto = array(
                                            'idTienda'=>$idTienda,
                                            'idCategoria'=>$idCategoriaProducto,
                                            'perteneceA'=>$perteneceA2,
                                            'estado'=>TRUE
                                        );
                                        if($objAsignarCategoriaProducto->ingresarAsignarCategoriaProducto($arrayAsignarCategoriaProducto) == 0){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE INGRESÓ LA CATEGORÍA COMUNÍQUESE CON NEL - LATINO</div>';
                                        }else{
                                            $validar = true;
                                            $mensaje = '<div class="alert alert-success text-center" role="alert">INGRESADO CORRECTAMENTE</div>';
                                        }
                                    }  
                                 
                                 }
                            }
                        }
                    }
                }
                return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
            }
        }
    }
    
    public function filtrarcategoriaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['id'];
                $codigoEncriptado = $post['cod1'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{

                            $listaAsignarCategoriaProducto = $this->dbAdapter->query("select * 
                                        from `asignarcategoriaproducto` inner join `categoriaproducto` 
                                        on `asignarcategoriaproducto`.`idCategoria` = `categoriaproducto`.`idCategoriaProducto`
                                        where `asignarcategoriaproducto`.`idTienda` = $idTienda and `asignarcategoriaproducto`.`perteneceA` is NULL
                                        order by `categoriaproducto`.`descripcionCategoria` asc ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                            $categoriaProducto = "";
                            if(count($listaAsignarCategoriaProducto) > 0){
                                $subcategoriaProducto = '';
                                $i = 0;
                                foreach ($listaAsignarCategoriaProducto as $valueCategorias) {
                                    $perteneceA = $valueCategorias['idCategoria'];
                                    $idAsignarCategoriaProducto = $valueCategorias['idAsignarCategoriaProducto'];
                                    $idAsignarCategoriaEncriptado = $objMetodos->encriptar($valueCategorias['idAsignarCategoriaProducto']);
                                    $subcategoriaProducto = $this->obtenerSubcategoriaAction($idTienda, $perteneceA,"",$i);
                                    $i = $subcategoriaProducto['contador'];
                                    $botonDeshabilitarCategoria = '<span id="iconDesh'.$i.'" title="DESHABILITAR '.$valueCategorias['descripcionCategoria'].'" style="cursor: pointer;" onclick="deshabilitarCategoria(\''.$idAsignarCategoriaEncriptado.'\','.$i.');" class="badge pull-right"><i class="fa fa-check-square"></i></span>';
                                    $colorFondo = '';
                                    if($valueCategorias['estado'] == FALSE){
                                        $colorFondo = 'background-color: #FFAEAE;';
                                        $botonDeshabilitarCategoria = '<span id="iconDesh'.$i.'" title="HABILITAR '.$valueCategorias['descripcionCategoria'].'" style="cursor: pointer;" onclick="deshabilitarCategoria(\''.$idAsignarCategoriaEncriptado.'\','.$i.');" class="badge pull-right"><i class="fa fa-minus-square"></i></span>';
                                    }
                                    if($subcategoriaProducto['validar'] == 0){
                                        $perteneceAEncriptado = $objMetodos->encriptar($valueCategorias['idCategoriaProducto']);
                                        $botonEliminarCategoria = '';

                                        $listaProductos = $this->dbAdapter->query("select * 
                                            from `productos`
                                            where `productos`.`idAsignarCategoriaProducto` = $idAsignarCategoriaProducto
                                            limit  1 ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                                        $botonAgregarSubcategoria = 'YA CONTIENE PRODUCTOS';
                                        $botonMoverCategoria = '<span data-toggle="modal" data-target="#modalFormMoverCategoria" title="MOVER '.$valueCategorias['descripcionCategoria'].'" style="cursor: pointer;" onclick="filtrarFormMoverCategoria(\''.$idAsignarCategoriaEncriptado.'\');"  class="badge pull-right"><i class="fa fa-arrows"></i></span>';
                                        if(count($listaProductos) == 0){
                                            $botonEliminarCategoria = '<span id="icon'.$i.'" title="ELIMINAR '.$valueCategorias['descripcionCategoria'].'" style="cursor: pointer;" onclick="eliminarCategoria(\''.$idAsignarCategoriaEncriptado.'\','.$i.');"  class="badge pull-right"><i class="fa fa-times"></i></span>';
                                            $botonAgregarSubcategoria = '<div class="panel panel-default">
                                                            <div class="panel-heading">
                                                                <a style="cursor: pointer;" data-toggle="modal" data-target="#modalForm" onclick="obtenerPerteneceA(\''.$perteneceAEncriptado.'\');">ADD SUBCATEGORÍA</a>
                                                            </div>
                                                        </div>';
                                        }
                                        $categoriaProducto = $categoriaProducto.'<div class="panel panel-default">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    '.$botonDeshabilitarCategoria.$botonEliminarCategoria.$botonMoverCategoria.'
                                                    <a style="'.$colorFondo.'" data-toggle="collapse" data-parent="#cp'.$i.'" href="#cp'.$i.'" class="">
                                                        <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                                                        '.$valueCategorias['descripcionCategoria'].'
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="cp'.$i.'" class="panel-collapse in" style="height: auto;">
                                                <div class="panel-body">
                                                    <ul>
                                                        '.$botonAgregarSubcategoria.'
                                                    </ul>
                                                </div>
                                            </div>
                                            
                                        </div>';
                                    }else{
                                        $categoriaProducto = $categoriaProducto.'
                                            <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    '.$botonDeshabilitarCategoria.'
                                                    <a style="'.$colorFondo.'" data-toggle="collapse" data-parent="#cp'.$i.'" href="#cp'.$i.'" class="">
                                                        <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                                                        '.$valueCategorias['descripcionCategoria'].'
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="cp'.$i.'" class="panel-collapse in" style="height: auto;">
                                                <div class="panel-body">
                                                    <ul>
                                                        '.$subcategoriaProducto['menu'].'
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>';
                                    }
                                    $i++;
                                }
                            }else{
                                $categoriaProducto = "";
                            }
                            $tabla = '<div class="left-sidebar"><div class=" panel-group category-products" id="accordian"><div class="panel panel-default">
                                <div class="panel-heading">
                                    <a style="cursor: pointer;" data-toggle="modal" data-target="#modalForm" onclick="obtenerPerteneceA(0);">ADD CATEGORÍA <span class="badge pull-right"><i class="fa fa-cog"></i></span></a>
                                </div>
                            </div>'.$categoriaProducto.'</div></div>';
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }

    public function obtenerSubcategoriaAction($idTienda,$perteneceA,$menu,$i){
       $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
       $objMetodos = new Metodos();
       $objAsignarCategoria = new AsignarCategoriaProducto($this->dbAdapter);
       $listaAsignarCategoria = $this->dbAdapter->query("select * 
                    from `asignarcategoriaproducto` inner join `categoriaproducto` 
                    on `asignarcategoriaproducto`.`idCategoria` = `categoriaproducto`.`idCategoriaProducto`
                    where `asignarcategoriaproducto`.`idTienda` = $idTienda and `asignarcategoriaproducto`.`perteneceA` = $perteneceA 
                    order by `categoriaproducto`.`descripcionCategoria` asc ",Adapter::QUERY_MODE_EXECUTE)->toArray();
       $totalSubcategoria = count($listaAsignarCategoria);
       if(count($listaAsignarCategoria) == 0){
           $array = array(
               'menu'=>$menu,
               'validar'=>0,
               'contador'=>$i
           );
           return $array;
       }else{
            foreach ($listaAsignarCategoria as $valueAsignarCategoria) {
                $idCategoria = $valueAsignarCategoria['idCategoria'];
                $idAsignarCategoriaProducto = $valueAsignarCategoria['idAsignarCategoriaProducto'];
                $idAsignarCategoriaEncriptado = $objMetodos->encriptar($valueAsignarCategoria['idAsignarCategoriaProducto']);
                $subCategoria = $this->obtenerSubcategoriaAction($idTienda, $idCategoria,"",$i);
                $i = $subCategoria['contador'];
                $botonEliminarCategoria = '';
                $listaProductos = $this->dbAdapter->query("select * 
                from `productos`
                where `productos`.`idAsignarCategoriaProducto` = $idAsignarCategoriaProducto
                limit  1 ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                $botonMoverCategoria = '<span data-toggle="modal" data-target="#modalFormMoverCategoria" title="MOVER '.$valueAsignarCategoria['descripcionCategoria'].'" style="cursor: pointer;" onclick="filtrarFormMoverCategoria(\''.$idAsignarCategoriaEncriptado.'\');"  class="badge pull-right"><i class="fa fa-arrows"></i></span>';
                if(count($listaProductos) == 0){
                    $botonEliminarCategoria = '<span id="icon'.$i.'" title="ELIMINAR '.$valueAsignarCategoria['descripcionCategoria'].'" style="cursor: pointer;" onclick="eliminarCategoria(\''.$idAsignarCategoriaEncriptado.'\','.$i.');" class="badge pull-right"><i class="fa fa-times"></i></span>';
                }
                $botonDeshabilitarCategoria = '<span id="iconDesh'.$i.'" title="DESHABILITAR '.$valueAsignarCategoria['descripcionCategoria'].'" style="cursor: pointer;" onclick="deshabilitarCategoria(\''.$idAsignarCategoriaEncriptado.'\','.$i.');" class="badge pull-right"><i class="fa fa-check-square"></i></span>';
                $colorFondo = '';
                if($valueAsignarCategoria['estado'] == FALSE){
                    $colorFondo = 'background-color: #FFAEAE;';
                    $botonDeshabilitarCategoria = '<span id="iconDesh'.$i.'" title="HABILITAR '.$valueAsignarCategoria['descripcionCategoria'].'" style="cursor: pointer;" onclick="deshabilitarCategoria(\''.$idAsignarCategoriaEncriptado.'\','.$i.');" class="badge pull-right"><i class="fa fa-minus-square"></i></span>';
                }
                if($subCategoria['validar'] == 0){
                    $botonAgregarSubcategoria = '';
                    if($totalSubcategoria == 1){
                        $perteneceAEncriptado = $objMetodos->encriptar($perteneceA);
                        $botonAgregarSubcategoria = '<div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <a style="cursor: pointer;" data-toggle="modal" data-target="#modalForm" onclick="obtenerPerteneceA(\''.$perteneceAEncriptado.'\');">ADD SUBCATEGORÍA</a>
                                                </div>
                                            </div>';
                    }
                    $menu = $menu.$botonDeshabilitarCategoria.$botonEliminarCategoria.$botonMoverCategoria.'<div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title"><a class="finalMenu" style="cursor: pointer; '.$colorFondo.'" >'.$valueAsignarCategoria['descripcionCategoria'].'</a></h4>
                                </div>
                            </div>'.$botonAgregarSubcategoria;
                    $totalSubcategoria --;
                }else{
                    $menu = $menu.'
                            <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a style="'.$colorFondo.'" data-toggle="collapse" data-parent="#cp'.$i.'" href="#cp'.$i.'" class="">
                                        <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                                        '.$valueAsignarCategoria['descripcionCategoria'].'
                                    </a>
                                </h4>
                            </div>
                            <div id="cp'.$i.'" class="panel-collapse in" style="height: auto;">
                                <div class="panel-body">
                                    <ul>
                                        '.$subCategoria['menu'].'
                                    </ul>
                                </div>
                            </div>
                        </div>';
                }
                $i++;
            }
            $array2 = array(
               'menu'=>$menu,
               'validar'=>1,
               'contador'=>$i
           );
           return $array2;
       }
    }
}