<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\DireccionTienda;
use Nel\Modelo\Entity\Provincias;
use Nel\Modelo\Entity\Tiendas;
use Nel\Modelo\Entity\CantonProvincia;
use Nel\Modelo\Entity\ParroquiaCanton;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter;

class DireccionTiendaController extends AbstractActionController
{
    public $dbAdapter;
    public function filtrardirecciontiendaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCodigos = new Codigos($this->dbAdapter);
                $objTieda = new Tiendas($this->dbAdapter);
                $objDireccionTienda = new DireccionTienda($this->dbAdapter);
                $objProvincias = new Provincias($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $codigoEncriptado = $post['cod1'];
                $idTiendaEncriptado = $post['id'];
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $listaCodigo6 = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo6[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTiendas = $objTieda->filtrarTiendaActivo($idTienda);
                        if(count($listaTiendas) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTiendas[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idTiendaEncriptado = $objMetodos->encriptar($idTienda);      
                            $listaDireccionTienda = $objDireccionTienda->filtrarDireccionTiendaPorTiendaActivo($idTienda);
                            $direccionTienda = ''; 
                            $listaProvincias = $objProvincias->obtenerProvinciasActivo();
                            $optionProvincias = '<option value="0">SELECCIONE UNA PROVINCIA</option>';
                            $optionCantones = '<option value="0">SELECCIONE UN CANTÓN</option>';
                            $optionParroquias = '<option value="0">SELECCIONE UNA PARROUIA</option>';
                            if(count($listaDireccionTienda) == 0 || count($listaDireccionTienda) > 1){
                                $listaCodigo2 = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                                $codigoModal = $objMetodos->encriptar($listaCodigo2[0]['nombreCodigo']);
                                if(count($listaProvincias) > 0){
                                    foreach ($listaProvincias as $valueProvincias) {
                                        $idProvinciaEncriptado = $objMetodos->encriptar($valueProvincias['idProvincia']);
                                        $optionProvincias = $optionProvincias.'<option  value="'.$idProvinciaEncriptado.'">'.$valueProvincias['nombreProvincia'].'</option>';
                                      
                                    }
                                }
                                $direccionTienda = '<input value="'.$codigoModal.'" id="codMod" name="codMod" type="hidden" class="form-control" >
                                    <h4>Provincia: <select onchange="filtrarCantonProvincia();" id="provincia" name="provincia" class="form-control" >'.$optionProvincias.'</select></h4>
                                    <h4>Cantón: <select onchange="filtrarParroquiaCanton();" id="canton" name="canton" class="form-control" >'.$optionCantones.'</select></h4>
                                    <h4>Parroquia: <select id="parroquia" name="parroquia" class="form-control" >'.$optionParroquias.'</select></h4>
                                    <h4>Dirección: <input id="direccion2" name="direccion2" type="text" class="form-control" ></h4>
                                    <h4>Referencia: <textarea rows="4"  id="referencia" name="referencia" class="form-control"></textarea></h4>
                                    <button onclick="guardarDireccion(\''.$idTiendaEncriptado.'\');" class="btn btn-primary btn-sm btn-square" type="button" id="btnGuardarDireccion" data-loading-text="GUARDANDO...">GUARDAR</button>';
                            }else if(count($listaDireccionTienda) == 1){
                                $listaCodigo2 = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                                $codigoModal = $objMetodos->encriptar($listaCodigo2[0]['nombreCodigo']);
                                if(count($listaProvincias) > 0){
                                    foreach ($listaProvincias as $valueProvincias) {
                                        $idProvinciaEncriptado = $objMetodos->encriptar($valueProvincias['idProvincia']);
                                        $idProvincia = $valueProvincias['idProvincia'];
                                        $listaCantonProvincia = $this->dbAdapter->query("select * 
                                        from `cantonprovincia` inner join  `cantones` on `cantonprovincia`.`idCanton` = `cantones`.`idCanton`
                                        where `cantonprovincia`.`idProvincia` = $idProvincia and `cantones`.`estado` = true
                                        order by `cantones`.`nombreCanton` asc ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                                        if($valueProvincias['idProvincia'] != $listaDireccionTienda[0]['idProvincia']){
                                            $optionProvincias = $optionProvincias.'<option  value="'.$idProvinciaEncriptado.'">'.$valueProvincias['nombreProvincia'].'</option>';
                                        }else{
                                            foreach ($listaCantonProvincia as $valueCantonProvincia) {
                                                $idCantonEncriptado = $objMetodos->encriptar($valueCantonProvincia['idCanton']);
                                                $idCanton = $valueCantonProvincia['idCanton'];
                                                $listaParroquiaCanton = $this->dbAdapter->query("select * 
                                                from `parroquiacanton` inner join  `parroquias` on `parroquiacanton`.`idParroquia` = `parroquias`.`idParroquia`
                                                where `parroquiacanton`.`idCanton` = $idCanton and `parroquias`.`estado` = true
                                                order by `parroquias`.`nombreParroquia` asc ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                                                if($valueCantonProvincia['idCanton'] != $listaDireccionTienda[0]['idCanton']){
                                                    $optionCantones = $optionCantones.'<option value="'.$idCantonEncriptado.'">'.$valueCantonProvincia['nombreCanton'].'</option>';
                                                }else{
                                                    foreach ($listaParroquiaCanton as $valueParroquiaCanton) {
                                                        $idParroquiaEncriptado = $objMetodos->encriptar($valueParroquiaCanton['idParroquia']);
                                                        if($valueParroquiaCanton['idParroquia'] != $listaDireccionTienda[0]['idParroquia']){
                                                            $optionParroquias = $optionParroquias.'<option value="'.$idCantonEncriptado.'">'.$valueParroquiaCanton['nombreParroquia'].'</option>';
                                                        }else{
                                                            $optionParroquias = $optionParroquias.'<option selected value="'.$idParroquiaEncriptado.'">'.$valueParroquiaCanton['nombreParroquia'].'</option>';
                                                        }
                                                    }
                                                    $optionCantones = $optionCantones.'<option selected value="'.$idCantonEncriptado.'">'.$valueCantonProvincia['nombreCanton'].'</option>';
                                                }
                                            }
                                            $optionProvincias = $optionProvincias.'<option selected value="'.$idProvinciaEncriptado.'">'.$valueProvincias['nombreProvincia'].'</option>';
                                        }
                                    }
                                }
                                $direccionTienda = '<input  value="'.$codigoModal.'" id="codMod" name="codMod" type="hidden" class="form-control" >
                                        <h4>Provincia: <select onchange="filtrarCantonProvincia();" id="provincia" name="provincia" class="form-control" >'.$optionProvincias.'</select></h4>
                                    <h4>Cantón: <select onchange="filtrarParroquiaCanton();" id="canton" name="canton" class="form-control" >'.$optionCantones.'</select></h4>
                                    <h4>Parroquia: <select id="parroquia" name="parroquia" class="form-control" >'.$optionParroquias.'</select></h4>
                                    <h4>Dirección: <input value="'.$listaDireccionTienda[0]['direccion'].'" id="direccion2" name="direccion2" type="text" class="form-control" ></h4>
                                    <h4>Referencia: <textarea rows="4"  id="referencia" name="referencia" class="form-control">'.$listaDireccionTienda[0]['referencia'].'</textarea></h4>
                                    <button onclick="guardarDireccion(\''.$idTiendaEncriptado.'\');" class="btn btn-primary btn-sm btn-square" type="button" id="btnGuardarDireccion" data-loading-text="GUARDANDO...">GUARDAR</button>';
                            } 
                            $tabla = $direccionTienda;
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    public function guardardirecciontiendaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCodigos = new Codigos($this->dbAdapter);
                $objTieda = new Tiendas($this->dbAdapter);
                $objCantonProvincia = new CantonProvincia($this->dbAdapter);
                $objParroquiaCanton = new ParroquiaCanton($this->dbAdapter);
                $objDireccionTienda = new DireccionTienda($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $codigoEncriptado = $post['codMod'];
                $idTiendaEncriptado = $post['id'];
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idProvinciaEncriptado = $post['idProvincia'];
                $idCantonEncriptado = $post['idCanton'];
                $idParroquiaEncriptado = $post['idParroquia'];
                $direccion = $post['direccion'];
                $referencia = $post['referencia'];
                
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProvinciaEncriptado == "0"){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">SELECCIONE UNA PROVINCIA</div>';
                }else if($idCantonEncriptado == "0"){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">SELECCIONE UN CANTÓN</div>';
                }else if($idParroquiaEncriptado == "0"){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">SELECCIONE UNA PARROQUIA</div>';
                }else if($direccion == "" || $objMetodos->soloLetras($direccion) == FALSE){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">LA DIRECCIÓN INGRESADA NO ES VÁLIDA (NO UTILICES CARACTERES ESPECIALES)</div>';
                }else if($referencia == "" || $objMetodos->soloLetras($referencia) == FALSE){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">LA REFERENCIA INGRESADA NO ES VÁLIDA (NO UTILICES CARACTERES ESPECIALES)</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $listaCodigoInsert = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigoModif = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigoInsert[0]['nombreCodigo'] && $listaCodigo[0]['nombreCodigo'] != $listaCodigoModif[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTieda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProvincia = $objMetodos->desencriptar($idProvinciaEncriptado);
                            $idCanton = $objMetodos->desencriptar($idCantonEncriptado);
                            $idParroquia = $objMetodos->desencriptar($idParroquiaEncriptado);
                            $listaCantonProvincia =  $objCantonProvincia->filtrarCantonProvinciaPorCantonProvinciaActivo($idProvincia, $idCanton);
                            $listaParroquiaCanton = $objParroquiaCanton->filtrarParroquiaCantonPorCantonParroquiaActivo($idCanton, $idParroquia);
                            
                            if(count($listaCantonProvincia) == 0){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">EL CANTÓN SELECCIONADO NO COINCIDE CON LA PROVINCIA</div>';
                            }else if(count($listaParroquiaCanton) == 0){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">LA PARROQUIA SELECCIONADA NO COINCIDE CON EL CANTÓN</div>';
                            }else{
                                $listaDireccionTienda = $objDireccionTienda->filtrarDireccionTiendaPorTiendaActivo($idTienda);
                                ini_set('date.timezone','America/Bogota'); 
                                $fechaIngreso = date("Y-m-d H:i:s",time());
                                if(count($listaDireccionTienda) == 0){
                                    $arrayDireccionTienda = array(
                                        'idTienda'=>$idTienda,
                                        'idProvincia'=>$idProvincia,
                                        'idCanton'=>$idCanton,
                                        'idParroquia'=>$idParroquia,
                                        'direccion'=>$direccion,
                                        'referencia'=>$referencia,
                                        'fechaIngreso'=>  $fechaIngreso,
                                        'estado'=>TRUE
                                    );
                                    if($objDireccionTienda->ingresarDireccionTienda($arrayDireccionTienda) == 0){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE COMPLETARON LOS CAMBIOS POR FAVOR COMUNIQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $mensaje = '<div class="alert alert-success text-center" role="alert">CAMBIOS REALIAZADOS CORRECTAMENTE</div>';
                                        $validar = TRUE; 
                                    }
                                }else{
                                    $arrayDireccionTiendaMod = array(
                                        'estado'=>0
                                    );
                                    if($objDireccionTienda->actualizarDireccionTienda($idTienda, $arrayDireccionTiendaMod) == FALSE){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE COMPLETARON LOS CAMBIOS POR FAVOR COMUNIQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $arrayDireccionTienda = array(
                                            'idTienda'=>$idTienda,
                                            'idProvincia'=>$idProvincia,
                                            'idCanton'=>$idCanton,
                                            'idParroquia'=>$idParroquia,
                                            'direccion'=>$direccion,
                                            'referencia'=>$referencia,
                                            'fechaIngreso'=>  $fechaIngreso,
                                            'estado'=>TRUE
                                        );
                                        
                                        if($objDireccionTienda->ingresarDireccionTienda($arrayDireccionTienda) == 0){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE COMPLETARON LOS CAMBIOS POR FAVOR COMUNIQUESE CON NEL - LATINO</div>';
                                        }else{
                                            $mensaje = '<div class="alert alert-success text-center" role="alert">CAMBIOS REALIAZADOS CORRECTAMENTE</div>';
                                            $validar = TRUE; 
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    
}