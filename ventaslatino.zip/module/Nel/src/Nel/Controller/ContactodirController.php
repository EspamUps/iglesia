<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\FotoTienda;
use Nel\Modelo\Entity\Tiendas;
use Nel\Modelo\Entity\ContactoTienda;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter;

class ContactodirController extends AbstractActionController
{
    public $dbAdapter;
    public function filtrarcontactodirAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCodigos = new Codigos($this->dbAdapter);
                $objFotoTienda = new FotoTienda($this->dbAdapter);
                $objTieda = new Tiendas($this->dbAdapter);
                $objContactoTienda = new ContactoTienda($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $codigoEncriptado = $post['cod1'];
                $nombreUsuarioEncriptado = $post['id'];
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($nombreUsuarioEncriptado == NULL || $nombreUsuarioEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $listaCodigo6 = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $nombreUsuario = $objMetodos->desencriptar($nombreUsuarioEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo6[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if($objMetodos->comprobarCadena($nombreUsuario) == false){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(count($listaCodigo3) != 1){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTiendas = $objTieda->filtrarTiendaPorNombreUsuarioActivo($nombreUsuario);
                        if(count($listaTiendas) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTiendas[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idTienda = $listaTiendas[0]['idTienda'];
                             $idTiendaEncriptado = $objMetodos->encriptar($idTienda);      
                            
                            $listaDireccionTienda = $this->dbAdapter->query("SELECT * 
                            FROM `direcciontienda` inner join `provincias` on `direcciontienda`.`idProvincia` = `provincias`.`idProvincia`
                            inner join `cantones` on `direcciontienda`.`idCanton` = `cantones`.`idCanton`
                            inner join `parroquias` on `direcciontienda`.`idParroquia` = `parroquias`.`idParroquia`
                            where `direcciontienda`.`idTienda` = $idTienda and `direcciontienda`.`estado` = true",Adapter::QUERY_MODE_EXECUTE)->toArray();
                            
                            $direccionTienda = '<button class="btn btn-danger btn-square btn-sm" data-toggle="modal" data-target="#modalForm" onclick="cargandoFormModal();filtrarDireccionTienda(\''.$idTiendaEncriptado.'\');">Agregar dirección</button>';
                            if(count($listaDireccionTienda) == 1){
                                $direccionTienda = '<h4>Provincia: '.$listaDireccionTienda[0]['nombreProvincia'].'</h4>
                                        <h4>Cantón: '.$listaDireccionTienda[0]['nombreCanton'].'</h4>
                                        <h4>Parroquia: '.$listaDireccionTienda[0]['nombreParroquia'].'</h4>
                                        <h4>Dirección: '.$listaDireccionTienda[0]['direccion'].'</h4>
                                        <h4>Referencia: '.$listaDireccionTienda[0]['referencia'].'</h4>
                                        <button class="btn btn-danger btn-square btn-sm" data-toggle="modal" data-target="#modalForm" onclick="cargandoFormModal();filtrarDireccionTienda(\''.$idTiendaEncriptado.'\');">Actualizar dirección</button>';
                            }
                            $listaContactoTienda = $objContactoTienda->filtrarContactoTiendaPorTiendaActivo($idTienda);
                            $contactoTienda = '<button class="btn btn-danger btn-square btn-sm" data-toggle="modal" data-target="#modalForm" onclick="cargandoFormModal();filtrarContactoTienda(\''.$idTiendaEncriptado.'\');">Agregar contactos</button>'; 
                            if(count($listaContactoTienda) == 1){
                                $contactoTienda = '<h4>Correo: '.$listaContactoTienda[0]['correo'].'</h4>
                                    <h4>Teléfono: '.$listaContactoTienda[0]['telefono'].'</h4>
                                    <h4>Whatsapp: '.$listaContactoTienda[0]['whatsapp'].'</h4>
                                    <h4>Facebook: <a target="_blank" href="'.$listaContactoTienda[0]['facebook'].'">'.$listaContactoTienda[0]['facebook'].'</a></h4>
                                    <button class="btn btn-danger btn-square btn-sm" data-toggle="modal" data-target="#modalForm" onclick="cargandoFormModal();filtrarContactoTienda(\''.$idTiendaEncriptado.'\');">Actualizar contactos</button>';
                            }
                            $listaFotoTienda = $objFotoTienda->filtrarFotoTiendaPorTiendaActivo($idTienda);
                            $fotoTienda = '';
                            if(count($listaFotoTienda) != 1){
                                $fotoTienda = $this->getRequest()->getBaseUrl().'/public/images/otras/nodisponible.png';
                            }else{
                                $fotoTienda = $this->getRequest()->getBaseUrl().$listaFotoTienda[0]['rutaFoto'];
                            }
                            $cod3 = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                            $tabla = '<div class="category-tab">
                                    <div class="col-sm-12">
                                        <ul class="nav nav-tabs">
                                            <li class="active"><a href="#contacto" data-toggle="tab">Contacto</a></li>
                                            <li><a href="#direccion" data-toggle="tab">Dirección</a></li>
                                            <li><a href="#contrasena" data-toggle="tab">Actualizar contraseña</a></li>
                                        </ul>
                                    </div>
                                    <div class="tab-content">
                                        <div class="tab-pane fade active in" id="contacto">
                                            <div class="col-sm-4">
                                                <div class="product-image-wrapper">
                                                    <div class="single-products">
                                                        <div class="productinfo text-center">
                                                            <img class="img-responsive" src="'.$fotoTienda.'" alt="">
                                                            <h2></h2>
                                                            <p><button onclick="limpiarInputFileModal();" class="btn btn-danger btn-square btn-sm" data-toggle="modal" data-target="#modalFormFotoTienda">Actualizar foto</button></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-8">'.$contactoTienda.'</div>
                                        </div>
                                        <div class="tab-pane fade in" id="direccion">
                                            <div class="col-sm-4">
                                                <div class="product-image-wrapper">
                                                    <div class="single-products">
                                                        <div class="productinfo text-center">
                                                            <img class="img-responsive" src="'.$fotoTienda.'" alt="">
                                                            <h2></h2>
                                                            <p><button class="btn btn-danger btn-square btn-sm" data-toggle="modal" data-target="#modalForm" onclick="cargandoFormModal();filtrarFotoTienda(\''.$idTiendaEncriptado.'\');">Actualizar foto</button></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-8">'.$direccionTienda.'</div>
                                        </div>
                                        <div class="tab-pane fade in" id="contrasena">
                                            <div class="col-sm-4">
                                                <div class="product-image-wrapper">
                                                    <div class="single-products">
                                                        <div class="productinfo text-center">
                                                            <img class="img-responsive" src="'.$fotoTienda.'" alt="">
                                                            <h2></h2>
                                                            <p><button class="btn btn-danger btn-square btn-sm" data-toggle="modal" data-target="#modalForm" onclick="cargandoFormModal();filtrarFotoTienda(\''.$idTiendaEncriptado.'\');">Actualizar foto</button></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-8">
                                                <form id="formActualizarContrasena">
                                                    <div class="form-group">
                                                        <input type="hidden" id="cod3Contrasena" name="cod3Contrasena" autocomplete="off" value="'.$cod3.'" class="form-control">
                                                        <label for="contrasena1">Contraseña actual</label>
                                                        <input type="password" id="contrasena1" name="contrasena1" autocomplete="off" class="form-control">
                                                        <label for="contrasena2">Nueva contraseña</label>
                                                        <input type="password" id="contrasena2" name="contrasena2" autocomplete="off" class="form-control">
                                                        <label for="contrasena3">Repita la nueva contraseña</label>
                                                        <input type="password" id="contrasena3" name="contrasena3" autocomplete="off" class="form-control">
                                                    </div>
                                                    <button class="btn btn-danger btn-sm" onclick="actualizarContrasena();" id="btnActualizarContrasena" type="button" data-loading-text="GUARDANDO...">GUARDAR</button> 
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                </div>';
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
}