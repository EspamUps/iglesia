<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Modelo\Entity\Tiendas;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\FotosProducto;
use Nel\Modelo\Entity\Paginas;
use Nel\Modelo\Entity\Productos;
use Nel\Modelo\Entity\CaracteristicasProducto;
use Zend\Session\Container;

class CaracteristicaProductoController extends AbstractActionController
{
    public $dbAdapter;
    
    public function eliminarcaracteristicaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objCaracteristicaProducto = new CaracteristicasProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $objPaginas = new Paginas($this->dbAdapter);
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $idProductoEncriptado = $post['id2'];
                $idCaracterisiticaProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod3'];
                $listaPagina = $objPaginas->filtrarPaginaActivo(1);
                if(count($listaPagina) != 1){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INTERNO DEL SISTEMA POR FAVOR COMUNÍCATE CON NEL - LATINO</div>';
                }else if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idCaracterisiticaProductoEncriptado == NULL || $idCaracterisiticaProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(4);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                            }else{
                                $listaProduto = $objProductos->filtrarProducto($idProducto);
                                if(count($listaProduto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProduto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $idCaracteristicaProducto = $objMetodos->desencriptar($idCaracterisiticaProductoEncriptado);
                                    if(!is_numeric($idCaracteristicaProducto)){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                    }else{
                                        $listaCaracteristicaProducto = $objCaracteristicaProducto->filtrarCaracteristicaProducto($idCaracteristicaProducto);
                                        if(count($listaCaracteristicaProducto) != 1){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">LA CARACTERÍSTICA NO EXISTE</div>';
                                        }else if($listaCaracteristicaProducto[0]['idProducto'] != $idProducto){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTA CARACTERÍSTICA NO PERTENECE A ESTE PRODUCTO</div>';
                                        }else{
                                            $objCaracteristicaProducto->eliminarCaracteristicaProducto($idCaracteristicaProducto);
                                            $listaCaracteristicaProducto2 = $objCaracteristicaProducto->filtrarCaracteristicaProducto($idCaracteristicaProducto);
                                            if(count($listaCaracteristicaProducto2) > 0){
                                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE ELIMINÓ LA CARACTERÍSTICA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                            }else{
                                                $mensaje = '';
                                                $validar = TRUE;
                                                return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idProducto'=>$idProductoEncriptado));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    public function ingresarcaracteristicaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
            
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCaracteristicasProducto = new CaracteristicasProducto($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTiendaModalCarac'];
                $codigoEncriptado = $post['cod1ModalCarac'];
                $caracteristicaProducto = $post['caracteristicaProductoModal'];
                $idProductoEncriptado = $post['idProductoModalCarac'];
                if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($objMetodos->comprobarCadena($caracteristicaProducto) == FALSE){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR LA CARACTERÍSTICA NO DEBE ESTAR EN BLANCO NI CONTENER CARACTERES ESPECIALES</div>';
                }else if(strlen($caracteristicaProducto) > 200){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">LA CARACTERÍSTICA NO DEBE SUPERAR LOS 200 CARACTERES</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto =  $objProductos->filtrarProducto($idProducto);
                                if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $listaCaracteristicaProducto = $objCaracteristicasProducto->filtrarCaracteristicaProductoPorProducto($idProducto);
                                    if(count($listaCaracteristicaProducto) > 10){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">YA EXISTEN 10 CARACTERÍSTICAS EN ESTE PRODUCTO</div>';
                                    }else{
                                        ini_set('date.timezone','America/Bogota'); 
                                        $hoy = getdate();
                                        $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                                        $arrayCaracteristica = array(
                                            'idProducto'=>$idProducto,
                                            'descripcion'=>$caracteristicaProducto,
                                            'fechaIngreso'=>$fechaSubida,
                                            'estado'=>TRUE
                                        );

                                        if($objCaracteristicasProducto->ingresarcaracteristicaProducto($arrayCaracteristica) == 0){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE INGRESÓ LA CARACTERÍSTICA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                        }else{
                                            $mensaje = '<div class="alert alert-success text-center" role="alert">GUARDADA EXITOSAMENTE</div>';
                                            $validar = TRUE;
                                        }
                                        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idProducto'=>$idProductoEncriptado));
                                        
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    public function filtrarcaracteristicaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objProducto = new Productos($this->dbAdapter);
                $objPagina = new Paginas($this->dbAdapter);
                $objCaracteristicaProducto = new CaracteristicasProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $codigoEncriptado = $post['cod1'];
                $idProductoEncriptado = $post['id'];
                $listaPagina = $objPagina->filtrarPaginaActivo(1);
                if(count($listaPagina) != 1){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INTERNO DEL SISTEMA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                }else if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto = $objProducto->filtrarProducto($idProducto);
                                 if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO EXISTE</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                                    $nombreCodigoEncriptado = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                                    $listaCaracteristicaProducto = $objCaracteristicaProducto->filtrarCaracteristicaProductoPorProducto($idProducto);
                                    
                                    $formNuevaCaracteristica = '';
                                    if(count($listaCaracteristicaProducto) < 10){
                                        $formNuevaCaracteristica = '
                                            <div class="form-group col-sm-12 text-center" >
                                                <input id="idTiendaModalCarac" name="idTiendaModalCarac" type="hidden" value="'.$idTiendaEncriptado.'">
                                                <input id="cod1ModalCarac" name="cod1ModalCarac" type="hidden" value="'.$nombreCodigoEncriptado.'">
                                                <input id="idProductoModalCarac" name="idProductoModalCarac" type="hidden" value="'.$idProductoEncriptado.'">
                                                <label>INGRESA UNA CARACTERÍSTICA MÁXIMO 10</label>
                                                <textarea maxlength="200" class="form-control" rows="4" id="caracteristicaProductoModal" name="caracteristicaProductoModal"></textarea>
                                            </div><button id="btnGuardarCaracteristicaProducto" type="submit" class="btn btn-danger btn-sm" data-loading-text="GUARDANDO...">GUARDAR</button>';
                                    }   
                                    $tabla = '';
                                    if(count($listaCaracteristicaProducto) > 0){
                                        foreach ($listaCaracteristicaProducto as $value) {
                                            $idCaracteristicaProductoEncriptado = $objMetodos->encriptar($value['idCaracteristicaProducto']);
                                            $btnEliminarCaracteristica = '<i onclick="eliminarCaracteristicaProducto(\''.$idCaracteristicaProductoEncriptado.'\',\''.$idProductoEncriptado.'\');" title="ELIMIINAR ESTA CARACTERÍSTICA" class="fa fa-times" style="cursor: pointer;"></i>';
                                            $tabla = $tabla.'<p  style="text-align: justify;"><li>'.$value['descripcion'].$btnEliminarCaracteristica.'</li></p>';
                                        }
                                    }
                                    $tabla = '<div class="col-sm-12">'.$tabla.'</div>';
                                    $mensaje = '';
                                    $validar = TRUE;
                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla,'formNuevaCaracteristica'=>$formNuevaCaracteristica));
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
}