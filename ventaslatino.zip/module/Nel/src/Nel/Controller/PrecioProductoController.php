<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Modelo\Entity\Tiendas;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\PrecioProducto;
use Nel\Modelo\Entity\Productos;
use Zend\Session\Container;

class PrecioProductoController extends AbstractActionController
{
    public $dbAdapter;
    public function moficarprecioproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objPrecioProducto = new PrecioProducto($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTiendaModalPrecio'];
                $codigoEncriptado = $post['cod1ModalPrecio'];
                $precio = $post['precioModal'];
                $idProductoEncriptado = $post['idProductoModalPrecio'];
                if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if(!is_numeric($precio)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL PRECIO DEBEN SER SÓLO NUMEROS</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto =  $objProductos->filtrarProducto($idProducto);
                                if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    ini_set('date.timezone','America/Bogota'); 
                                    $hoy = getdate();
                                    $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                                    $listaPrecioProducto = $objPrecioProducto->filtrarPrecioProductoPorProductoActivo($idProducto);
                                    
                                    
                                    if(count($listaPrecioProducto) == 0){
                                        $arrayPrecio = array(
                                            'idProducto'=>$idProducto,
                                            'precio'=>$precio,
                                            'fechaIngresoPrecio'=>$fechaSubida,
                                            'fechaEliminado'=>NULL,
                                            'estado'=>TRUE
                                        );
                                        
                                        $idPrecio = $objPrecioProducto->ingresarPrecioProducto($arrayPrecio);
                                        if($idPrecio == 0){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE GUARDÓ EL PRECIO POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                        }else{
                                           $mensaje = '<div class="alert alert-success text-center" role="alert">GUARDADA EXITOSAMENTE</div>';
                                           $validar = TRUE; 
                                        }
                                    }else if(count($listaPrecioProducto) == 1){
                                        $arrayPrecioM = array(
                                            'estado'=>0,
                                            'fechaEliminado'=>$fechaSubida
                                        );
                                        
                                        if($objPrecioProducto->actualizarPrecio($listaPrecioProducto[0]['idPrecioProducto'], $arrayPrecioM) == FALSE){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE GUARDÓ EL PRECIO POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                        }else{
                                            $arrayPrecio = array(
                                                'idProducto'=>$idProducto,
                                                'precio'=>$precio,
                                                'fechaIngresoPrecio'=>$fechaSubida,
                                                'fechaEliminado'=>NULL,
                                                'estado'=>TRUE
                                            );
                                        
                                            $idPrecio = $objPrecioProducto->ingresarPrecioProducto($arrayPrecio);
                                            if($idPrecio == 0){
                                                $arrayPrecioM = array(
                                                    'estado'=>TRUE,
                                                    'fechaEliminado'=>NULL
                                                );
                                                $objPrecioProducto->actualizarPrecio($listaPrecioProducto[0]['idPrecioProducto'], $arrayPrecioM);
                                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE GUARDÓ EL PRECIO POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                            }else{
                                               $mensaje = '<div class="alert alert-success text-center" role="alert">GUARDADA EXITOSAMENTE</div>';
                                               $validar = TRUE; 
                                            }
                                        }
                                    }else{
                                         $arrayPrecioM = array(
                                            'estado'=>0,
                                        );
                                        if($objPrecioProducto->actualizarPrecioPorProducto($idProducto, $arrayPrecioM) == FALSE){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE GUARDÓ EL PRECIO POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                        }else{
                                            $arrayPrecio = array(
                                                'idProducto'=>$idProducto,
                                                'precio'=>$precio,
                                                'fechaIngresoPrecio'=>$fechaSubida,
                                                'fechaEliminado'=>NULL,
                                                'estado'=>TRUE
                                            );
                                        
                                            $idPrecio = $objPrecioProducto->ingresarPrecioProducto($arrayPrecio);
                                            if($idPrecio == 0){
                                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE GUARDÓ EL PRECIO POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                            }else{
                                               $mensaje = '<div class="alert alert-success text-center" role="alert">GUARDADA EXITOSAMENTE</div>';
                                               $validar = TRUE; 
                                            }
                                        }
                                    }

                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idProducto'=>$idProductoEncriptado));
                                }
                            
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    public function filtrarprecioproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objProducto = new Productos($this->dbAdapter);
                $objPrecioProducto = new PrecioProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $codigoEncriptado = $post['cod1'];
                $idProductoEncriptado = $post['id'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto = $objProducto->filtrarProducto($idProducto);
                                 if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO EXISTE</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $listaCodigoInsert = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                                    $nombreCodigoInsertEncriptado = $objMetodos->encriptar($listaCodigoInsert[0]['nombreCodigo']);
                                    $listaPrecioProducto = $objPrecioProducto->filtrarPrecioProductoPorProductoActivo($idProducto);
                                    $formNuevoPrecioProducto = '';
                                    if(count($listaPrecioProducto) != 1){
                                        $formNuevoPrecioProducto = '
                                            <div class="form-group col-sm-12 text-center" >
                                                <input id="idTiendaModalPrecio" name="idTiendaModalPrecio" type="hidden" value="'.$idTiendaEncriptado.'">
                                                <input id="cod1ModalPrecio" name="cod1ModalPrecio" type="hidden" value="'.$nombreCodigoInsertEncriptado.'">
                                                <input id="idProductoModalPrecio" name="idProductoModalPrecio" type="hidden" value="'.$idProductoEncriptado.'">
                                                <input type="number" step="0.01" class="form-control" id="precioModal" name="precioModal" value="0.00">   
                                            </div><button id="btnGuardarPrecioProducto" type="submit" class="btn btn-danger btn-sm" data-loading-text="GUARDANDO...">GUARDAR</button>';
                                    }else{
                                         $formNuevoPrecioProducto = '<div class="form-group col-sm-12 text-center" >
                                                <input id="idTiendaModalPrecio" name="idTiendaModalPrecio" type="hidden" value="'.$idTiendaEncriptado.'">
                                                <input id="cod1ModalPrecio" name="cod1ModalPrecio" type="hidden" value="'.$nombreCodigoInsertEncriptado.'">
                                                <input id="idProductoModalPrecio" name="idProductoModalPrecio" type="hidden" value="'.$idProductoEncriptado.'">
                                                <input type="number" step="0.01" class="form-control" id="precioModal" name="precioModal" value="'.$listaPrecioProducto[0]['precio'].'"> 
                                            </div><button id="btnGuardarPrecioProducto" type="submit" class="btn btn-danger btn-sm" data-loading-text="GUARDANDO...">GUARDAR</button>';
                                    }
                                    $tabla = '';
                                    $mensaje = '';
                                    $validar = TRUE;
                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla,'formNuevoPrecioProducto'=>$formNuevoPrecioProducto));
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
}