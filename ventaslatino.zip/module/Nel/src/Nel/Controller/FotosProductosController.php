<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Modelo\Entity\Tiendas;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\FotosProducto;
use Nel\Modelo\Entity\Productos;
use Zend\Session\Container;


class FotosProductosController extends AbstractActionController
{
    public $dbAdapter;
    
    public function eliminarfotoproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objFotoProducto = new FotosProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $idProductoEncriptado = $post['id2'];
                $idFotoProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod3'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idFotoProductoEncriptado == NULL || $idFotoProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(4);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                            }else{
                                $listaProduto = $objProductos->filtrarProducto($idProducto);
                                if(count($listaProduto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProduto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $idFotoProducto = $objMetodos->desencriptar($idFotoProductoEncriptado);
                                    if(!is_numeric($idFotoProducto)){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                    }else{
                                        $listaFotoProducto = $objFotoProducto->filtrarFotoProducto($idFotoProducto);
                                        if(count($listaFotoProducto) != 1){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">LA FOTO DEBE ESTAR HABILITADA PARA SER SELECCIONADA</div>';
                                        }else if($listaFotoProducto[0]['idProducto'] != $idProducto){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTA FOTO NO PERTENECE A ESTE PRODUCTO</div>';
                                        }else{
                                            $objFotoProducto->eliminarFotoProducto($idFotoProducto);
                                            $listaFotoProducto2 = $objFotoProducto->filtrarFotoProducto($idFotoProducto);
                                            if(count($listaFotoProducto2) > 0){
                                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE ELIMINÓ LA FOTO POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                            }else{
                                                $src = $_SERVER['DOCUMENT_ROOT'].$this->getRequest()->getBaseUrl().$listaFotoProducto[0]['rutaFoto'];
                                                unlink($src);
                                                $mensaje = '';
                                                $validar = TRUE;
                                                return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idProducto'=>$idProductoEncriptado));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }

    public function cambiarfotoprincipalAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objFotoProducto = new FotosProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $idProductoEncriptado = $post['id2'];
                $idFotoProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod3'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idFotoProductoEncriptado == NULL || $idFotoProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                            }else{
                                $listaProduto = $objProductos->filtrarProducto($idProducto);
                                if(count($listaProduto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProduto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $idFotoProducto = $objMetodos->desencriptar($idFotoProductoEncriptado);
                                    if(!is_numeric($idFotoProducto)){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                    }else{
                                        $listaFotoProducto = $objFotoProducto->filtrarFotoProductoActivo($idFotoProducto);
                                        if(count($listaFotoProducto) != 1){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">LA FOTO DEBE ESTAR HABILITADA PARA SER SELECCIONADA</div>';
                                        }else if($listaFotoProducto[0]['idProducto'] != $idProducto){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTA FOTO NO PERTENECE A ESTE PRODUCTO</div>';
                                        }else{
                                            $arrayFotoProducto1 = array(
                                                'principal'=>0
                                            );
                                            if($objFotoProducto->actualizarFotoProductoPorProducto($idProducto, $arrayFotoProducto1) == FALSE){
                                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE PUDO ASIGNAR LA FOTO COMO PRINCIPAL POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                            }else{
                                                $arrayFotoProducto2 = array(
                                                    'principal'=>TRUE
                                                );
                                                if($objFotoProducto->actualizarFotoProducto($idFotoProducto, $arrayFotoProducto2) == FALSE){
                                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE PUDO ASIGNAR LA FOTO COMO PRINCIPAL POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                                }else{
                                                    $mensaje = '';
                                                    $validar = TRUE;
                                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idProducto'=>$idProductoEncriptado));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }

    public function ingresarfotosAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
            
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objFotosProducto = new FotosProducto($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTiendaModal'];
                $codigoEncriptado = $post['cod1Modal'];
                $fotos = $post['fotosProductoModal'];
                $idProductoEncriptado = $post['idProductoModal'];
                if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if(empty($fotos)){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR SELECCIONE UNA FOTO</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto =  $objProductos->filtrarProducto($idProducto);
                                if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    ini_set('date.timezone','America/Bogota'); 
                                    $hoy = getdate();
                                    $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                                    $image = $fotos;
                                    if($image['type'] != 'image/jpeg' && $image['type'] != 'image/jpg'){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">LAS IMÁGENES DEBEN SER FORMATO JPG o JPG</div>';
                                    }else{
                                        $listaFotosProducto = $objFotosProducto->filtrarFotoProductoPorProducto($idProducto);
                                        if(count($listaFotosProducto) > 5){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">YA EXISTEN 6 FOTOS EN ESTE PRODUCTO</div>';
                                        }else{
                                        
                                            $nombreFechaFoto = $hoy['year'].$hoy['mon'].$hoy['mday'].$hoy['hours'].$hoy['minutes'].$hoy['seconds'];
                                            $name = $image['name'];
                                            $trozos = explode('.',$name);
                                            $ext = end($trozos);
                                            $nombreFinalImagen = $this->nombrefotoAction(10, TRUE, TRUE, FALSE).$nombreFechaFoto.'.'.$ext;
                                            $destino = '/public/images/productos/'.$nombreFinalImagen;
                                            $src = $_SERVER['DOCUMENT_ROOT'].$this->getRequest()->getBaseUrl().$destino;
//                                            REDIMENSION DE IMAGEN
                                            $rutaImagenOriginal = $image['tmp_name'];
                                            $img_original = imagecreatefromjpeg($rutaImagenOriginal);
        
                                            $max_ancho = 500;
                                            $max_alto = 500;
                                            list($ancho,$alto)=getimagesize($rutaImagenOriginal);
                                            $x_ratio = $max_ancho / $ancho;
                                            $y_ratio = $max_alto / $alto;
                                            if( ($ancho <= $max_ancho) && ($alto <= $max_alto) ){
                                                $ancho_final = $ancho;
                                                $alto_final = $alto;
                                            }else if (($x_ratio * $alto) < $max_alto){
                                                $alto_final = ceil($x_ratio * $alto);
                                                $ancho_final = $max_ancho;
                                            }else{
                                                $ancho_final = ceil($y_ratio * $ancho);
                                                $alto_final = $max_alto;
                                            }
                                            $img_base = $_SERVER['DOCUMENT_ROOT'].$this->getRequest()->getBaseUrl().'/public/images/otras/imagenbase.jpg';
                                            $img_base = imagecreatefromjpeg($img_base);
                                            $crop_x = 0;
                                            $crop_y = 0;
                                            if($ancho > $alto){
                                                $crop_y = ($ancho_final -  $alto_final)/2;
                                            }else if($alto > $ancho){
                                                $crop_x = ($alto_final - $ancho_final)/2;
                                            }
                                            imagecopyresampled($img_base,$img_original,$crop_x,$crop_y,0,0,$ancho_final, $alto_final,$ancho,$alto);
                                            imagedestroy($img_original); 
            //                                            FIN REDIMENSION
            //                                             GUARDAR IMAGEN
                                            if(imagejpeg($img_base,$src,100))
                                            {
                                                $pincipal = 0;
                                                if(count($listaFotosProducto) == 0){
                                                    $pincipal = TRUE;
                                                }
                                                
                                                $arrayFotoProducto = array(
                                                    'idProducto'=>$idProducto,
                                                    'rutaFoto'=>$destino,
                                                    'principal'=>$pincipal,
                                                    'fechaSubida'=>$fechaSubida,
                                                    'estado'=>TRUE
                                                );
                                                $idFoto = $objFotosProducto->ingresarFotoProducto($arrayFotoProducto);
                                                if($idFoto == 0){
                                                    unlink($src);
                                                }
                                            }      
//                                            FIN GUARDAR IMAGEN
                                            $mensaje = '<div class="alert alert-success text-center" role="alert">FOTO GUARDADA EXITOSAMENTE</div>';
                                            $validar = TRUE;
                                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idProducto'=>$idProductoEncriptado));
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    public function nombrefotoAction($length,$uc,$n,$sc)
    {
        $source = 'abcdefghijklmnopqrstuvwxyz';
        if($uc==1) $source .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
        if($n==1) $source .= '1234567890'; 
        if($sc==1) $source .= '|@#~$%()=^*+[]{}-_'; 
        if($length>0)
        { 
            $rstr = ""; 
            $source = str_split($source,1);
            for($i=1; $i<=$length; $i++)
            { 
                mt_srand((double)microtime() * 1000000); 
                $num = mt_rand(1,count($source)); 
                $rstr .= $source[$num-1];  
            }   
        } 
        return $rstr;
    }

    public function filtrarfotosproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objProducto = new Productos($this->dbAdapter);
                $objFotoProducto = new FotosProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $codigoEncriptado = $post['cod1'];
                $idProductoEncriptado = $post['id'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto = $objProducto->filtrarProducto($idProducto);
                                 if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO EXISTE</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                                    $nombreCodigoEncriptado = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                                    $listaFotosProducto = $objFotoProducto->filtrarFotoProductoPorProducto($idProducto);
                                    
                                    $formNuevaFoto = '';
                                    if(count($listaFotosProducto) < 6){
                                        $formNuevaFoto = '<div id="progressModal" class="progress">
                                                <div id="progress-barModal" class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
                                                    <label id="progresoModal"></label>
                                                </div>
                                            </div>
                                            <div style="text-align: center;" id="megasModal"></div>
                                            <div class="form-group col-sm-12 text-center" >
                                                <input id="idTiendaModal" name="idTiendaModal" type="hidden" value="'.$idTiendaEncriptado.'">
                                                <input id="cod1Modal" name="cod1Modal" type="hidden" value="'.$nombreCodigoEncriptado.'">
                                                <input id="idProductoModal" name="idProductoModal" type="hidden" value="'.$idProductoEncriptado.'">
                                                <h6>TE RECOMENDAMOS SUBIR FOTOS TOMADAS DE MANERA HORIZONTAL CON TU TELÉFONO</h6>
                                                <div  class="fileUpload btn btn-danger btn-square">
                                                    <span>SELECCIONE UNA FOTO</span>
                                                    <input type="file" id="fotosProductoModal" name="fotosProductoModal" class="upload form-control" onchange="vistaPreviaProductoModal();" accept="image/jpeg" />
                                                </div>
                                            </div>
                                            <br />
                                            <output id="contenedorVistaPreviaProductoModal" class="col-sm-9"></output>
                                            <div id="contenedorBtnGuardarProductoModal" class="col-sm-3"></div>';
                                    }
                                    $tabla = '';
                                    if(count($listaFotosProducto) > 0){
                                        foreach ($listaFotosProducto as $value) {
                                            $idFotoProductoEncriptado = $objMetodos->encriptar($value['idFotoProducto']);
                                            
                                            
                                            $btnEliminarFoto = '<i onclick="eliminarFotoProducto(\''.$idFotoProductoEncriptado.'\',\''.$idProductoEncriptado.'\');" title="ELIMIINAR ESTA FOTO" class="fa fa-times" style="cursor: pointer;"></i>';
                                            $radio = '<input onclick="cambiarFotoPrincipal(\''.$idFotoProductoEncriptado.'\',\''.$idProductoEncriptado.'\');" style="cursor: pointer;" class="form-control" name="principalModal" id="principalModal" type="radio" value="0">';
                                            if($value['principal'] == TRUE){
                                                $radio = '<br><br>';
                                                $btnEliminarFoto = '';
                                            }
                                            $tabla = $tabla.'<div class="col-sm-4">'.$radio.'<img class="img-responsive" style="cursor: pointer;" src="'.$this->getRequest()->getBaseUrl().$value['rutaFoto'].'" alt="">'.$btnEliminarFoto.'</div>';
                                        }
                                    }
                                    $tabla = '<div class="col-sm-12">'.$tabla.'</div>';
                                    $mensaje = '';
                                    $validar = TRUE;
                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla,'formNuevaFoto'=>$formNuevaFoto));
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
}