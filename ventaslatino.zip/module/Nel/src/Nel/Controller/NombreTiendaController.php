<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Modelo\Entity\Tiendas;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\NombreTienda;
use Nel\Modelo\Entity\DescripcionTienda;
use Nel\Modelo\Entity\CaracteristicasProducto;
use Zend\Session\Container;

class NombreTiendaController extends AbstractActionController
{
    public $dbAdapter;
    public function modifcarnombretiendaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
            
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objNombreTienda = new NombreTienda($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTiendaNombreTienda'];
                $codigoEncriptado = $post['cod3NombreTienda'];
                $nombreTienda = strtoupper($post['nombreTienda']);
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($objMetodos->soloLetras($nombreTienda) == FALSE || strlen($nombreTienda) == 0){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR EL NOMBRE NO DEBE ESTAR EN BLANCO NI CONTENER CARACTERES ESPECIALES</div>';
                }else if(strlen($nombreTienda) > 30){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">EL NOMBRE DE LA TIENDA NO DEBE SUPERAR LOS 30 CARACTERES</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            ini_set('date.timezone','America/Bogota'); 
                            $hoy = getdate();
                            $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                            $listaNombreTienda = $objNombreTienda->filtrarNombreTiendaPorTiendaActivo($idTienda);
                            if(count($listaNombreTienda) > 1){
                                $validarMT = true;
                                foreach ($listaNombreTienda as $value) {
                                    $idNombreTiendaF = $value['idNombreTienda'];
                                    $arrayNombreTiendaM = array(
                                        'fechaDesignacion'=>$fechaSubida,
                                        'estado'=>0
                                    );
                                    if($objNombreTienda->actualizarNombreTienda($idNombreTiendaF, $arrayNombreTiendaM) == FALSE){
                                        $validarMT = FALSE;
                                        break;
                                    }
                                }
                                if($validarMT == FALSE){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ EL NOMBRE DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                }else{
                                    $arrayNombreTienda = array(
                                        'idTienda'=>$idTienda,
                                        'nombreTienda'=>$nombreTienda,
                                        'fechaAsignacion'=>$fechaSubida,
                                        'fechaDesignacion'=>NULL,
                                        'estado'=>TRUE
                                    );
                                    if($objNombreTienda->ingresarNombreTienda($arrayNombreTienda) == 0){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ EL NOMBRE DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $mensaje = '<div class="alert alert-success text-center" role="alert">MODIFICADO EXITOSAMENTE</div>';
                                        $validar = TRUE;
                                    }
                                    
                                }
                            }else if(count($listaNombreTienda) == 1){
                                if($objMetodos->compararFechas($fechaSubida, $listaNombreTienda[0]['fechaAsignacion']) <= 15){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">DEBEN PASAR 15 DÍAS PARA QUE PUEDA MODIFICAR EL NOMBRE</div>';
                                }else if($listaNombreTienda[0]['nombreTienda'] == $nombreTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE HA MODIFICADO EL NOMBRE</div>';
                                }else{
                                    $idNombreTienda = $listaNombreTienda[0]['idNombreTienda'];
                                    $arrayNombreTienda = array(
                                        'fechaDesignacion'=>$fechaSubida,
                                        'estado'=>0
                                    );
                                    if($objNombreTienda->actualizarNombreTienda($idNombreTienda, $arrayNombreTienda) == FALSE){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ EL NOMBRE DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $arrayNombreTienda = array(
                                            'idTienda'=>$idTienda,
                                            'nombreTienda'=>$nombreTienda,
                                            'fechaAsignacion'=>$fechaSubida,
                                            'fechaDesignacion'=>NULL,
                                            'estado'=>TRUE
                                        );
                                        if($objNombreTienda->ingresarNombreTienda($arrayNombreTienda) == 0){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ EL NOMBRE DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                        }else{
                                            $mensaje = '<div class="alert alert-success text-center" role="alert">MODIFICADO EXITOSAMENTE</div>';
                                            $validar = TRUE;
                                        }
                                    }
                                }
                            }else{
                                $arrayNombreTienda = array(
                                    'idTienda'=>$idTienda,
                                    'nombreTienda'=>$nombreTienda,
                                    'fechaAsignacion'=>$fechaSubida,
                                    'fechaDesignacion'=>NULL,
                                    'estado'=>TRUE
                                );
                                if($objNombreTienda->ingresarNombreTienda($arrayNombreTienda) == 0){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ EL NOMBRE DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                }else{
                                    $mensaje = '<div class="alert alert-success text-center" role="alert">MODIFICADO EXITOSAMENTE</div>';
                                    $validar = TRUE;
                                }
                            }
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'id'=>$idTiendaEncriptado));
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    public function filtrarnombretiendaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objNombreTienda = new NombreTienda($this->dbAdapter);
                $objDescripcionTienda = new DescripcionTienda($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['id'];
                $codigoEncriptado = $post['cod1'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            ini_set('date.timezone','America/Bogota'); 
                            $hoy = getdate();
                            $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                            $listaNombreTienda = $objNombreTienda->filtrarNombreTiendaPorTiendaActivo($idTienda);
                            $tabla = '';
                            if(count($listaNombreTienda) != 1){
                                $tabla = '<div class="col-sm-2"><i data-toggle="modal" data-target="#modalFormNombreTienda" title="AGREGAR NOMBRE" class="fa fa-pencil" style="cursor: pointer"></i></div><div class="col-sm-10">
                                    <h2 class="title text-center">EL NOMBRE DE LA TIENDA NO HA SIDO ESTABLECIDO</h2>
				</div>';
                            }else{
                                $botonAdd = '';
                                $dias  = $objMetodos->compararFechas($fechaSubida, $listaNombreTienda[0]['fechaAsignacion']);
                                if($dias > 15)
                                {
                                    $botonAdd = '<div class="col-sm-2"><i data-toggle="modal" data-target="#modalFormNombreTienda" title="MODIFICAR NOMBRE" class="fa fa-pencil" style="cursor: pointer"></i></div>';
                                }else{
                                    $diasRestantes = 15 - $dias;
                                    $botonAdd = '<div class="col-sm-2"><p>Podrá actualizar el nombre en '.$diasRestantes.' días</p></div>';
                                }
                                $tabla = $botonAdd.'<div class="col-sm-10">
                                    <h2 class="title text-center">'.$listaNombreTienda[0]['nombreTienda'].'</h2>
				</div>';
                            }
                            $listaDescripcionTienda = $objDescripcionTienda->filtrarDescripcionTiendaPorTiendaActivo($idTienda);
                            $tabla2 = '';
                            if(count($listaDescripcionTienda) != 1){
                                $tabla2 = '<div class="col-sm-2"><i data-toggle="modal" data-target="#modalFormDescripcionTienda" title="AGREGAR DESCRIPCIÓN" class="fa fa-pencil" style="cursor: pointer"></i></div><div class="col-sm-10">
                                    <h4 class="title text-center">LA DESCRIPCIÓN DE LA TIENDA NO HA SIDO ESTABLECIDA</h4>
				</div>';
                            }else{
                                $botonAdd2 = '';
                                $dias2  = $objMetodos->compararFechas($fechaSubida, $listaDescripcionTienda[0]['fechaAsignacion']);
                                if($dias2 > 15)
                                {
                                    $botonAdd2 = '<div class="col-sm-2"><i data-toggle="modal" data-target="#modalFormDescripcionTienda" title="MODIFICAR DESCRIPCIÓN" class="fa fa-pencil" style="cursor: pointer"></i></div>';
                                }else{
                                    $diasRestantes2 = 15 - $dias2;
                                    $botonAdd2 = '<div class="col-sm-2"><p>Podrá actualizar la descripción en '.$diasRestantes2.' días</p></div>';
                                }
                                $tabla2 = $botonAdd2.'<div class="col-sm-10">
                                    <h4 class="title text-center">'.$listaDescripcionTienda[0]['descripcionTienda'].'</h4>
				</div>';
                            }
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla,'tabla2'=>$tabla2));
                            
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
}