<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\Productos;
use Nel\Modelo\Entity\Tiendas;
use Nel\Modelo\Entity\NombreTienda;
use Nel\Modelo\Entity\FotoTienda;
use Nel\Modelo\Entity\ContactoTienda;
use Nel\Modelo\Entity\PrecioProducto;
use Nel\Modelo\Entity\Paginas;
use Nel\Modelo\Entity\Monedas;
use Nel\Modelo\Entity\Clientes;
use Nel\Modelo\Entity\FotosProducto;
use Nel\Modelo\Entity\Pedidos;
use Zend\Db\Adapter\Adapter;
use Zend\Session\Container;

class PedidosController extends AbstractActionController
{
    public $dbAdapter;
    public function filtrarpedidosAction()
    {
        $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
        $validar = false;
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $request=$this->getRequest();
            if(!$request->isPost()){
                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objMetodos = new Metodos();
                $objCodigo = new Codigos($this->dbAdapter);
                $objPedidos = new Pedidos($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objPaginas = new Paginas($this->dbAdapter);
                $objTienda = new Tiendas($this->dbAdapter);
                $objNombreTienda = new NombreTienda($this->dbAdapter);
                $objFotoTienda = new FotoTienda($this->dbAdapter);
                $objContactoTienda = new ContactoTienda($this->dbAdapter);
                $objFotoProducto = new FotosProducto($this->dbAdapter);
                $objPrecioProducto = new PrecioProducto($this->dbAdapter);
                $objClientes = new Clientes($this->dbAdapter);
                $objMonedas = new Monedas($this->dbAdapter);
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                
                $idTiendaEncriptado = $post['vari'];
                $tipoPedido = $post['tipoPedido'];
                $cod = $post['cod2'];
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $listaPaginas = $objPaginas->filtrarPaginaActivo(3);
                
                if(count($listaPaginas) != 1){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INTERNO DEL SISTEMA POR FAVOR COMUNÍCATE CON NEL - LATINO</div>';
                }else if($cod == NULL || $cod == "" ){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == "" ){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($tipoPedido != '0' && $tipoPedido != '1' ){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $cod = $objMetodos->desencriptar($cod);
                    $listaCodigo = $objCodigo->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigo->filtrarCodigoPorNombreActivo($cod);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTienda($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else{
                            $where = "";
                            if($tipoPedido == '0'){
                                $where = " where `cabecerapedido`.`idTienda` = $idTienda  and `cabecerapedido`.`rutaDocumentoEnvio` is null ";
                            }else if($tipoPedido == '1'){
                                $where = " where `cabecerapedido`.`idTienda` = $idTienda and `cabecerapedido`.`rutaDocumentoEnvio` is not null ";
                            }
                            $listaCabeceraPedido = $this->dbAdapter->query("select * from `cabecerapedido` $where",Adapter::QUERY_MODE_EXECUTE)->toArray();
                        
                            if(count($listaCabeceraPedido) == 0){
                                if($tipoPedido == '0'){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTEN PEDIDOS SIN DESPACHAR</div>';
                                }else if($tipoPedido == '1'){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTEN PEDIDOS DESPACHADOS</div>';
                                }
                            }else{
                                $iCabeceraPedido = 1;
                                $iPedido = 0;
                                $tabla = '';
                            
                                foreach ($listaCabeceraPedido as $valueCabecera) {
                                    $idCabeceraPedido = $valueCabecera['idCabeceraPedido'];
                                    $idCabeceraPedidoEncriptado = $objMetodos->encriptar($idCabeceraPedido);
                                    $documentoEnvio = '<button data-target="#modalFormSubirDocumentoEnvio" data-toggle="modal" onclick="filtrarDocumentoEnvio(\''.$idCabeceraPedidoEncriptado.'\','.$iCabeceraPedido.')" class="btn btn-danger btn-sm">SUBIR DOC. ENV.</button>';
                                    if($valueCabecera['rutaDocumentoEnvio'] != NULL && $valueCabecera['rutaDocumentoEnvio'] != ''){
                                        $documentoEnvio = '<button data-target="#modalFormSubirDocumentoEnvio" data-toggle="modal" onclick="filtrarDocumentoEnvio(\''.$idCabeceraPedidoEncriptado.'\','.$iCabeceraPedido.')" class="btn btn-success btn-sm">VER DOC. ENV.</button>';
                                    }
                                    
                                    $documentoDeposito = 'NO DISPONIBLE';
                                    if($valueCabecera['rutaDocumentoDeposito'] != NULL && $valueCabecera['rutaDocumentoDeposito'] != ''){
                                       $validarDocumentoDeposito = TRUE;
                                        $documentoDeposito = '<button data-target="#modalVerDocumentoDeposito" data-toggle="modal" onclick="filtrarDocumentoDepostio(\''.$idCabeceraPedidoEncriptado.'\','.$iCabeceraPedido.')" class="btn btn-success btn-sm">VER DOC. DEP.</button>';
                                    }
                                
                                    $listaPedidos = $objPedidos->filtrarPedidoPorCabecera($idCabeceraPedido);
                                    if(count($listaPedidos) > 0){
                                        $iColor = 0;
                                        $clasePedido = 'success';
                                        $colorCabecera = '#0B3B0B';
                                        if(($iCabeceraPedido%2) == 0){
                                            $iColor = 1;
                                            $clasePedido = 'danger';
                                            $colorCabecera = '#610B0B';
                                        }
                                        

                                        $listaMoneda = $objMonedas->filtrarMonedaActivo($listaTienda[0]['idMoneda']);
                                        $simbolo = '';
                                        if(count($listaMoneda) == 1){
                                            $simbolo = $listaMoneda[0]['simbolo'];
                                        }
                                        $cuerpoTabla = '';
                                        $precioFinal = $simbolo.'0';
                                        foreach ($listaPedidos as $value) {


                                            $listaProducto = $objProductos->filtrarProducto($value['idProducto']);
                                            if(count($listaProducto) == 1){
                                                $listaPrecioProducto = $objPrecioProducto->filtrarPrecioProductoPorProductoActivo($listaProducto[0]['idProducto']);
                                                if(count($listaPrecioProducto) == 1){
                                                    $idPedidoEncriptado = $objMetodos->encriptar($value['idPedido']);
                                                    $listaFotoProducto = $objFotoProducto->filtrarFotoProductoPrincipalPorProductoActivo($listaProducto[0]['idProducto']);
                                                    $precioProducto = '';
                                                    $cantidad = $value['cantidad'];
                                                    if(count($listaPrecioProducto) == 1){
                                                        $precioProducto = $simbolo.$listaPrecioProducto[0]['precio'];
                                                        $pt = number_format($cantidad * $listaPrecioProducto[0]['precio'],2);
                                                        $precioProductoTotal = '<h4 class="precioTotal'.$iCabeceraPedido.'" id="contenedorPrecio'.$iPedido.'">'.$simbolo.$pt.'<h4>';

                                                    }

                                                    $fotoProducto = '<img class="img-responsive" src="'.$this->getRequest()->getBaseUrl().'/public/images/otras/nodisponible.png" alt="">';
                                                    if(count($listaFotoProducto) == 1){
                                                        $fotoProducto = '<img class="img-responsive" src="'.$this->getRequest()->getBaseUrl().$listaFotoProducto[0]['rutaFoto'].'" alt="">';
                                                    }
                                                    $codigo = $value['idProducto'];
                                                    if(strlen($codigo) < 10){
                                                        $totalCod = 10 - strlen($codigo);
                                                        for ($k = 0; $k < $totalCod ; $k++){
                                                            $codigo = '0'.$codigo;
                                                        }
                                                    } 
                                                
                                                
                                                    $btnEliminarPedido = '';
                                                    if($validarDocumentoDeposito == FALSE){
                                                        $btnEliminarPedido = '<a id="contendorBotonEliminar'.$iPedido.'" class="cart_quantity_delete" style="cursor: pointer;" title="ELIMINAR '.$listaProducto[0]['nombreProducto'].'" onclick="eliminarPedido(\''.$idPedidoEncriptado.'\','.$iCabeceraPedido.','.$iPedido.');"><i class="fa fa-times"></i></a>';
                                                        $botonSumarRestar = '<div class="cart_quantity_button">
                                                            <a style="cursor: pointer;" onclick="sumar('.$iPedido.','.$iCabeceraPedido.',\''.$idPedidoEncriptado.'\');" class="cart_quantity_up"> + </a>
                                                            <input disabled class="cart_quantity_input" type="text" name="cantidad'.$iPedido.'" id="cantidad'.$iPedido.'" min="1" value="'.$cantidad.'" autocomplete="off" size="2">
                                                            <a style="cursor: pointer;" onclick="restar('.$iPedido.','.$iCabeceraPedido.',\''.$idPedidoEncriptado.'\');" class="cart_quantity_down"> - </a>
                                                        </div>';
                                                    }else{
                                                        $botonSumarRestar = '<div class="cart_quantity_button">
                                                                <h4>'.$cantidad.'</h4>
                                                            </div>';
                                                    }
                                                    $cuerpoTabla = $cuerpoTabla.'
                                                        <tr id="filaIndividual'.$iPedido.'">
                                                            <td style="width:10%; text-align: center;vertical-align: central;">
                                                                <a href="">'.$fotoProducto.'</a>
                                                            </td>
                                                            <td class="'.$clasePedido.'" style="width:40%; text-align: center;vertical-align: central;">
                                                                <h5><a href="">'.$listaProducto[0]['nombreProducto'].'</a></h5>
                                                                <p>NL'.$codigo.'</p>    
                                                            </td>
                                                            <td class="'.$clasePedido.'" style="width:10%; text-align: center;vertical-align: central;">
                                                                <h4 id="precioProducto'.$iPedido.'">'.$precioProducto.'</h4>
                                                            </td>
                                                            <td class="'.$clasePedido.'" style="width:10%; text-align: center;vertical-align: central;">
                                                                '.$botonSumarRestar.'
                                                            </td>
                                                            <td class="'.$clasePedido.'" style="width:10%; text-align: center;vertical-align: central;">
                                                                '.$precioProductoTotal.'
                                                            </td>
                                                            <td class="'.$clasePedido.'" style="width:10%; text-align: center;vertical-align: central;">
                                                                '.$btnEliminarPedido.'
                                                            </td>
                                                        </tr>';
                                                    $precioFinal = $precioFinal + $pt;
                                                }
                                            }
                                            $iPedido++;
                                        }
                                        
                                        $idCliente = $valueCabecera['idCliente'];
                                        $listaCliente = $objClientes->filtrarCliente($idCliente);
                                        $nombreCliente = 'NOMBRE NO ESTABLECIDO';
                                        $correo = 'NO ESTABLECIDO';
                                        $telefono = 'NO ESTABLECIDO';
                                        if(count($listaCliente) == 1){
                                            $nombreCliente = '<h5>CLIENTE: '.$listaCliente[0]['nombres'].' '.$listaCliente[0]['apellidos'].'</h5>';
                                            $correo = '<h5>CORREO: '.$listaCliente[0]['correo'].'</h5>';
                                            $telefono = '<h5>TELÉFONO: '.$listaCliente[0]['telefono'].'</h5>';
                                        }

                                        $tabla = $tabla. '<br><div id="contenedorTablaIndividual'.$iCabeceraPedido.'" class="table-responsive cart_info">
                                            <table style="" class="table table-condensed table-bordered">
                                                <thead>
                                                    <tr class="text-center" style="background: '.$colorCabecera.';color: #fff;font-size: 16px;font-family: Roboto, sans-serif;font-weight: normal;">
                                                        <td colspan="1">
                                                            COD: NL'.$valueCabecera['idCabeceraPedido'].'
                                                        </td>
                                                        <td colspan="1">
                                                            DATOS DEL CLIENTE
                                                        </td>
                                                        <td colspan="2">
                                                            DOCUMENTO DE DEPÓSITO
                                                        </td>
                                                        <td colspan="2">
                                                            DOCUMENTO DE ENVÍO
                                                        </td>
                                                    </tr>
                                                    <tr class="text-center">
                                                        <td style="width:10%;">
                                                        </td>
                                                        <td class="'.$clasePedido.'" style="width:40%;text-align: justify;">
                                                            '.$nombreCliente.'
                                                            '.$correo.'
                                                            '.$telefono.'
                                                        </td>
                                                        <td style="width:20%;"  class="'.$clasePedido.'" colspan="2">
                                                            '.$documentoDeposito.'
                                                        </td>
                                                        <td style="width:20%;"  class="'.$clasePedido.'" colspan="2">
                                                            '.$documentoEnvio.'
                                                        </td>
                                                    </tr>

                                                    <tr class="text-center" style="background: '.$colorCabecera.';color: #fff;font-size: 16px;font-family: Roboto, sans-serif;font-weight: normal;">
                                                        <td>
                                                            PROD.
                                                        </td>
                                                        <td>
                                                            DETAL.
                                                        </td>
                                                        <td>
                                                            PREC.
                                                        </td>
                                                        <td style="width:10%;">
                                                            CANT.
                                                        </td>
                                                        <td>
                                                            TOTAL
                                                        </td>
                                                        <td>
                                                            OPC.
                                                        </td>
                                                    </tr>
                                                </thead><tbody id="cuerpoTablaIndividual'.$iCabeceraPedido.'" >'.$cuerpoTabla.'
                                                    <tr class="text-center">
                                                       <td colspan="3" class="'.$clasePedido.' precio" style="text-align: center;vertical-align: central;">EL COSTO DE ENVÍO SE ARREGLA CON EL VENDEDOR O TIENDA</td>
                                                       <td class="'.$clasePedido.'" style=" text-align: center;vertical-align: central;"><h4>TOTAL</h4></td>
                                                       <td class="'.$clasePedido.'"  style="text-align: center;vertical-align: central;"><h4 id="precioFinalFinal'.$iCabeceraPedido.'">'.$simbolo.number_format($precioFinal,2).'</h4></td>
                                                       <td class="'.$clasePedido.'"></td>
                                                    </tr>


                                                </tbody>
                                            </table>
                                        </div>';
                                        $iCabeceraPedido++;
                                    }
                                }
                                $mensaje = '';
                                $validar = TRUE;
                                return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                            }    
                        }
                    }
                }
            }
        }
        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
    }
    
    
    
    
//    public function modificarpedidoAction()
//    {
//        $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
//        $validar = false;
//        $request=$this->getRequest();
//        if(!$request->isPost()){
//            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//        }else{
//            $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
//            $objMetodos = new Metodos();
//            $objCodigo = new Codigos($this->dbAdapter);
//            $objPedidos = new Pedidos($this->dbAdapter);
//            $objProductos = new Productos($this->dbAdapter);
//            $objPrecioProducto = new PrecioProducto($this->dbAdapter);
//            $post = array_merge_recursive(
//                $request->getPost()->toArray(),
//                $request->getFiles()->toArray()
//            );
//            $idPedidoEncriptado = $post['vari'];
//            $cantidad = $post['vari2'];
//            $cod3 = $post['cod3'];
//            if($idPedidoEncriptado == NULL || $idPedidoEncriptado == "" ){
//                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//            }else if($cod3 == NULL || $cod3 == "" ){
//                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//            }else if(!is_numeric($cantidad)){
//                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//            }else{
//                $cod3 = $objMetodos->desencriptar($cod3);
//                $listaCodigo = $objCodigo->filtrarCodigoPorNumeroActivo(3);
//                $listaCodigo2 = $objCodigo->filtrarCodigoPorNombreActivo($cod3);
//                $idPedido = $objMetodos->desencriptar($idPedidoEncriptado);
//                if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
//                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                }else if(!is_numeric($idPedido) && $cantidad < 1){
//                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                }else{
//                    $listaPedido  = $objPedidos->filtrarPedido($idPedido);
//                    if(count($listaPedido) != 1){
//                        $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO YA FUE ELIMINADO DEL PEDIDO POR FAVOR RECARQUE LA PÁGINA</div>';
//                    }else{
//                        $listaProducto = $objProductos->filtrarProducto($listaPedido[0]['idProducto']);
//                        if(count($listaProducto) != 1){
//                            $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO FUE FUE ELIMINADO DE LA TIENDA POR FAVOR RECARQUE LA PÁGINA</div>';
//                        }else{
//                            $listaPrecioProducto = $objPrecioProducto->filtrarPrecioProductoPorProductoActivo($listaProducto[0]['idProducto']);
//                            if(count($listaPrecioProducto) != 1){
//                                $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO TIENE PRECIO POR FAVOR ELIMÍNELO DEL PEDIDO</div>';
//                            }else{
//                                $cantidadLP = $listaPedido[0]['cantidad'];
//                                $verificarCantidad = $cantidadLP - $cantidad;
//                                if($verificarCantidad != (-1) && $verificarCantidad != 1){
//                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA LA CANTIDAD DEBE SUMARSE O RESTARSE DE UNO EN UNO</div>';
//                                }else{
//                                    $arrayPedido = array(
//                                      'cantidad'=>$cantidad  
//                                    );
//                                    if($objPedidos->actualizarPedido($idPedido, $arrayPedido) == TRUE){
//                                        $listaPedido2 = $objPedidos->filtrarPedido($idPedido);
//                                        $cantidad = $listaPedido2[0]['cantidad'];
//                                        $precio = $listaPrecioProducto[0]['precio'];
//                                        $precioTotal = '$'.number_format($precio * $cantidad,2);
//                                        $mensaje = '';
//                                        $validar = TRUE;
//                                        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'cantidad'=>$cantidad,'precioTotal'=>$precioTotal));
//                                    }else{
//                                        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'cantidad'=>$cantidad));
//                                    }
//                                    
//                                }
//                            }
//                        }
//                    }
//                }
//            }
//        }
//        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
//    }
//    
//    
//    
//    public function eliminarproductopedidoAction()
//    {
//        $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
//        $validar = false;
//        $request=$this->getRequest();
//        if(!$request->isPost()){
//            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//        }else{
//            $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
//            $objMetodos = new Metodos();
//            $objCodigo = new Codigos($this->dbAdapter);
//            $objPedidos = new Pedidos($this->dbAdapter);
//            $post = array_merge_recursive(
//                $request->getPost()->toArray(),
//                $request->getFiles()->toArray()
//            );
//            $idPedidoEncriptado = $post['var1'];
//            $iPedido = $post['var3'];
//            $iCabecera = $post['var2'];
//            $cod4 = $post['cod4'];
//            if($idPedidoEncriptado == NULL || $idPedidoEncriptado == "" ){
//                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//            }else if($cod4 == NULL || $cod4 == "" ){
//                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//            }else if(!is_numeric($iPedido)){
//                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//            }else if(!is_numeric($iCabecera)){
//                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//            }else{
//                $cod4 = $objMetodos->desencriptar($cod4);
//                $listaCodigo = $objCodigo->filtrarCodigoPorNumeroActivo(4);
//                $listaCodigo2 = $objCodigo->filtrarCodigoPorNombreActivo($cod4);
//                $idPedido = $objMetodos->desencriptar($idPedidoEncriptado);
//                if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
//                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                }else if(!is_numeric($idPedido)){
//                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                }else{
//                    $listaPedido  = $objPedidos->filtrarPedido($idPedido);
//                    if(count($listaPedido) != 1){
//                        $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRDUCTO YA FUE ELIMINADO DEL PEDIDO POR FAVOR RECARQUE LA PÁGINA</div>';
//                    }else{          
//                        $objPedidos->eliminarPedido($idPedido);
//                        $listaPedido2 = $objPedidos->filtrarPedido($idPedido);
//                        if(count($listaPedido2) > 0){
//                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE ELIMINÓ EL PRODUCTO DEL PEDIDO POR FAVOR COMUNÍCATE CON NEL LATINO</div>';
//                        }else{
//                            $mensaje = '';
//                            $validar = TRUE;
//                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'iCabecera'=>$iCabecera,'iPedido'=>$iPedido));
//                        }
//                    }
//                }
//            }
//        }
//        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
//    }
//    
//    
//    
//    
//    
//
//    
//    public function addalcarritoAction()
//    {
//        $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
//        $validar = false;
//        $sesionUsuario = new Container('cberSesionClienteCompradorNeLLatino');
//        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idCliente')){
//            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/clientes/iniciarsesion');
//        }else{
//            $request=$this->getRequest();
//            if(!$request->isPost()){
//                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//            }else{
//                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
//                $objCabeceraPedido = new CabeceraPedido($this->dbAdapter);
//                $objPedidos = new Pedidos($this->dbAdapter);
//                $objCodigo = new Codigos($this->dbAdapter);
//                $objProductos = new Productos($this->dbAdapter);
//                $objTienda = new Tiendas($this->dbAdapter);
//                $objMetodos = new Metodos();
//                $post = array_merge_recursive(
//                    $request->getPost()->toArray(),
//                    $request->getFiles()->toArray()
//                );
//                $idProductoEncriptado = $post['vari'];
//                $idTiendaEncriptado = $post['vari2'];
//                $contadorCarrito = $post['vari3'];
//                $cod = $post['cod5'];
//                $idCliente = $sesionUsuario->offsetGet('idCliente');
//                if($cod == NULL || $cod == "" ){
//                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == "" ){
//                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == "" ){
//                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                }else if(!is_numeric($contadorCarrito)){
//                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                }else{
//                    $cod = $objMetodos->desencriptar($cod);
//                    $listaCodigo = $objCodigo->filtrarCodigoPorNumeroActivo(5);
//                    $listaCodigo2 = $objCodigo->filtrarCodigoPorNombreActivo($cod);
//                    $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
//                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
//                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
//                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                    }else if(!is_numeric($idProducto)){
//                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                    }else if(!is_numeric($idTienda)){
//                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
//                    }else{
//                        $listaProductos = $objProductos->filtrarProductoActivo($idProducto);
//                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
//                        if(count($listaTienda) != 1){
//                            $mensaje = '<div class="alert alert-danger text-center" role="alert">LA TIENDA NO ESTA DISPONIBLE PORQUE NO HA RENOVADO EL PLAN</div>';
//                        }else if(count($listaProductos) != 1){
//                            $mensaje = '<div class="alert alert-danger text-center" role="alert">EL PRODUCTO YA NO ESTA DISPONIBLE</div>';
//                        }else{
//                            ini_set('date.timezone','America/Bogota'); 
//                            $hoy = getdate();
//                            $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
//                            $listaCabeceraPedido = $objCabeceraPedido->filtrarCabeceraPedidoPorClienteTiendaSinCompletar($idCliente, $idTienda, NULL, NULL);
//                            $tabla = '<button title="AGREGAR '.$listaProductos[0]['nombreProducto'] .' AL CARRITO" data-loading-text="AGREGANDO..." onclick="addAlCarrito(\''.$idProductoEncriptado.'\',\''.$idTiendaEncriptado.'\','.$contadorCarrito.');" id="btnCarrito'.$contadorCarrito.'" style="width:100%;" type="button" class="btn btn-success"><i class="fa fa-fw fa-shopping-cart"></i>ADD AL CARRITO</button>';
//                            if(count($listaCabeceraPedido) == 1){
//                                $idCabeceraPedido = $listaCabeceraPedido[0]['idCabeceraPedido'];
//                                $arrayPedido = array(
//                                    'idCabeceraPedido'=>$idCabeceraPedido,
//                                    'cantidad'=>1,
//                                    'idProducto'=>$idProducto,
//                                    'fechaSubida'=>$fechaSubida,
//                                    'estado'=>0
//                                ); 
//                                if($objPedidos->ingresarPedido($arrayPedido) == 0){
//                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE PUDO AGREGAR EL PRODUCTO</div>';
//                                }else{
//                                    $tabla = '<button style="width:100%;" title="'.$listaProductos[0]['nombreProducto'] .'YA ESTÁ AGREGADO AL CARRITO" type="button" class="btn btn-danger"><i class="fa fa-check"></i>AGREGADO</button>';
//                                    $validar = TRUE;
//                                    $mensaje = '';
//                                } 
//                            }else if(count($listaCabeceraPedido) == 0){
//                                $arrayCabeceraPedido = array(
//                                    'idCliente'=>$idCliente,
//                                    'idTienda'=>$idTienda,
//                                    'rutaDocumentoDeposito'=>NULL,
//                                    'fechaSubidaDocumentoD'=>NULL,
//                                    'rutaDocumentoEnvio'=>NULL,
//                                    'fechaDocumentoE'=>NULL,
//                                    'fechaPedido'=>$fechaSubida,
//                                    'observacion'=>NULL,
//                                    'estado'=>0
//                                );
//                                $idCabeceraPedido = $objCabeceraPedido->ingresarCabeceraPedido($arrayCabeceraPedido);
//                                if($idCabeceraPedido == 0){
//                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE PUDO AGREGAR EL PRODUCTO</div>';
//                                }else{
//                                    $arrayPedido = array(
//                                        'idCabeceraPedido'=>$idCabeceraPedido,
//                                        'cantidad'=>1,
//                                        'idProducto'=>$idProducto,
//                                        'fechaSubida'=>$fechaSubida,
//                                        'estado'=>0
//                                    ); 
//                                    if($objPedidos->ingresarPedido($arrayPedido) == 0){
//                                        $objCabeceraPedido->eliminarCabeceraPedido($idCabeceraPedido);
//                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE PUDO AGREGAR EL PRODUCTO</div>';
//                                    }else{
//                                        $tabla = '<button style="width:100%;" title="'.$listaProductos[0]['nombreProducto'] .'YA ESTÁ AGREGADO AL CARRITO" type="button" class="btn btn-danger"><i class="fa fa-check"></i>AGREGADO</button>';
//                                        $validar = TRUE;
//                                        $mensaje = '';
//                                    } 
//                                }
//                            }
//                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
//                        }    
//                    }
//                }
//            }
//        }
//        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
//    }

}