<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Modelo\Entity\Tiendas;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\AsignarCategoriaProducto;
use Nel\Modelo\Entity\FotosProducto;
use Nel\Modelo\Entity\PrecioProducto;
use Nel\Modelo\Entity\Monedas;
use Nel\Modelo\Entity\Productos;
use Nel\Modelo\Entity\CaracteristicasProducto;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter;

class ProductosController extends AbstractActionController
{
    public $dbAdapter;
    public function modificardescripcionproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
            
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTiendaDescrip'];
                $codigoEncriptado = $post['cod3Descrip'];
                $descripcionProducto = $post['descripcionProductoModal'];
                $idProductoEncriptado = $post['idProductoDescrip'];
                if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($objMetodos->comprobarCadena($descripcionProducto) == FALSE){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR LA CARACTERÍSTICA NO DEBE ESTAR EN BLANCO NI CONTENER CARACTERES ESPECIALES</div>';
                }else if(strlen($descripcionProducto) > 450){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">LA DESCRIPCIÓN NO DEBE SUPERAR LOS 450 CARACTERES</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto =  $objProductos->filtrarProducto($idProducto);
                                if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $arrayProducto = array(
                                        'descripcionProducto'=>$descripcionProducto,
                                    );
                                    if($objProductos->actualizarProducto($idProducto, $arrayProducto) == FALSE){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFICÓ LA DESCRIPCIÓN POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $mensaje = '<div class="alert alert-success text-center" role="alert">GUARDADA EXITOSAMENTE</div>';
                                        $validar = TRUE;
                                    }
                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idProducto'=>$idProductoEncriptado));
                                }
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    
    public function filtrardescripcionproductoAction()
    {
       $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $idProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod1'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto = $objProductos->filtrarProducto($idProducto);
                                if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $descripcion = '';
                                    if($listaProducto[0]['descripcionProducto'] != NULL){
                                        $descripcion = $listaProducto[0]['descripcionProducto'];
                                    }
                                    $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                                    $codigoEncriptado = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                                    $tabla = '<div class="form-group col-sm-12"> 
                                        <input type="hidden" id="idProductoDescrip" name="idProductoDescrip" value="'.$idProductoEncriptado.'">
                                        <input type="hidden" id="idTiendaDescrip" name="idTiendaDescrip" value="'.$idTiendaEncriptado.'">
                                        <input type="hidden" id="cod3Descrip" name="cod3Descrip" value="'.$codigoEncriptado.'">
                                        <label for="descripcionProducto">Descripción del producto</label>
                                        <textarea maxlength="200" class="form-control" rows="4" id="descripcionProductoModal" name="descripcionProductoModal">'.$descripcion.'</textarea>
                                    </div><button id="btnGuardarDescripcionProducto" type="submit" class="btn btn-danger btn-sm" data-loading-text="GUARDANDO...">GUARDAR</button>';
//                                    
                                    $mensaje = '';
                                    $validar = TRUE;
                                    return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                                    
                                }
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    public function deshabilitarproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objCaracteristicaProducto = new CaracteristicasProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $idProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod3'];
                $numeroFila = $post['numeroFila'];
                $contador = $post['contador'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if(!is_numeric($numeroFila)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if(!is_numeric($contador)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto = $objProductos->filtrarProducto($idProducto);
                                if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $estadoProducto = TRUE;
                                    
                                    if($listaProducto[0]['estado'] == TRUE){
                                        $estadoProducto = 0;
                                    }
                                    
                                    $arrayProducto = array(
                                        'estado'=>$estadoProducto
                                    );
                                    if($objProductos->actualizarProducto($idProducto, $arrayProducto) == FALSE){
                                        if($estadoProducto == TRUE){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE DESHABILITÓ EL PRODUCTO</div>';
                                        }else{
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE HABILITÓ EL PRODUCTO</div>';
                                        }
                                    }else{
                                        $listaProducto2 = $objProductos->filtrarProducto($idProducto);
                                        $idAsignarCategoriaEncriptado = $objMetodos->encriptar($listaProducto2[0]['idAsignarCategoriaProducto']);
                                        $idProductoEncriptado = $objMetodos->encriptar($listaProducto2[0]['idProducto']);
                                        $btnVerFotos = '<button data-toggle="modal" data-target="#modalForm" onclick="filtrarFotosProducto(\''.$idProductoEncriptado.'\');" class="btn btn-info btn-xs btn-square">Ver</button>';
                                        $btnEliminarProducto = '<button title="ELIMINAR '.$listaProducto2[0]['nombreProducto'].'" id="btnEliminarProducto'.$numeroFila.'" data-loading-text="Eliminando..." onclick="eliminarProducto(\''.$idProductoEncriptado.'\','.$numeroFila.')" class="btn btn-danger btn-xs btn-square">Eliminar</button>';

                                        $color = '';
                                        $btnEstado = '<button title="DESHABILITAR '.$listaProducto2[0]['nombreProducto'].'" id="btnDeshabilitarProducto'.$numeroFila.'" data-loading-text="Deshabilitando..." onclick="deshabilitarPorducto(\''.$idProductoEncriptado.'\','.$numeroFila.','.$contador.')" class="btn btn-success btn-xs btn-square">Habilitado</button>';
                                        if($listaProducto2[0]['estado'] == FALSE){
                                            $color='style="background-color: #FED6CE;"';
                                            $btnEstado = '<button title="HABILITAR '.$listaProducto2[0]['nombreProducto'].'"  id="btnDeshabilitarProducto'.$numeroFila.'" data-loading-text="Habilitando..." onclick="deshabilitarPorducto(\''.$idProductoEncriptado.'\','.$numeroFila.','.$contador.')" class="btn btn-danger btn-xs btn-square">Deshabilitado</button>';
                                        }
                                        $btnDescripcionProducto = '<button data-toggle="modal" data-target="#modalFormDescripcion" onclick="filtrarDescripcionProducto(\''.$idProductoEncriptado.'\');" class="btn btn-info btn-xs btn-square">Ver</button>';
                                        
                                        $botones = $btnEliminarProducto.' '.$btnEstado;
                                        $listaCaracteristicasProducto = $objCaracteristicaProducto->filtrarCaracteristicaProductoPorProducto($listaProducto2[0]['idProducto']);
                                        $botonCaracteristicas = '';
                                        if(count($listaCaracteristicasProducto) < 10){
                                            $botonCaracteristicas = '<button data-toggle="modal" data-target="#modalFormCaracteristica" onclick="cargandoCaracteristica();filtrarCaracteristicaProducto(\''.$idProductoEncriptado.'\');" class="btn btn-warning btn-xs btn-square">Ver</button>';
                                        }
                                        
                                        
                                        $array1 = array(
                                            'idProducto'=>$contador,
                                            'nombreProducto'=>'<div '.$color.' >'.$listaProducto2[0]['nombreProducto'].'</div>',
                                            'descripcionProducto'=>$listaProducto2[0]['descripcionProducto'],
                                            'fotosProducto'=>$btnVerFotos,
                                            'caracteristicaProducto'=>$botonCaracteristicas,
                                            'descripcionProducto'=>$btnDescripcionProducto,
                                            'fechaIngreso'=>'<div '.$color.' >'.$listaProducto2[0]['fechaIngreso'].'</div>',
                                            'opciones'=>$botones,
                                        );
                                        $mensaje = '';
                                        $validar = TRUE;
                                        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idAsignarCategoria'=>$idAsignarCategoriaEncriptado,'tabla'=>$array1,'numeroFila'=>$numeroFila));
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }

    public function eliminarproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objFotoProducto = new FotosProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['IDT'];
                $idProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod3'];
                $numeroFila = $post['numeroFila'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProductoEncriptado == NULL || $idProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }elseif(!is_numeric($numeroFila)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(4);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idProducto = $objMetodos->desencriptar($idProductoEncriptado);
                            if(!is_numeric($idProducto)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaProducto = $objProductos->filtrarProducto($idProducto);
                                if(count($listaProducto) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaProducto[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTE PRODUCTO NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    $idAsignarCategoriaEncriptado = $objMetodos->encriptar($listaProducto[0]['idAsignarCategoriaProducto']);
                                    $listaFotoProducto = $objFotoProducto->filtrarFotoProductoPorProducto($idProducto);
                                    $objProductos->eliminarProducto($idProducto);
                                    if(count($objProductos->filtrarProducto($idProducto)) > 0){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE ELIMINÓ EL PRODUCTO COMUNÍQUESE CON NEL - LATINO</div>';
                                    }else{
                                        if(count($listaFotoProducto) > 0){
                                            foreach ($listaFotoProducto as $value) {
                                                $src = $_SERVER['DOCUMENT_ROOT'].$this->getRequest()->getBaseUrl().$value['rutaFoto'];
                                                unlink($src);
                                            }
                                        }
                                        $mensaje = '';
                                        $validar = TRUE;
                                        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idAsignarCategoria'=>$idAsignarCategoriaEncriptado,'numeroFila'=>$numeroFila));
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }

    public function ingresarproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
            
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objPrecioProducto = new PrecioProducto($this->dbAdapter);
                $objCaracteristicasProducto = new CaracteristicasProducto($this->dbAdapter);
                $objFotosProducto = new FotosProducto($this->dbAdapter);
                $objProductos = new Productos($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objAsignarCategoria = new AsignarCategoriaProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTienda'];
                $codigoEncriptado = $post['cod9'];
                $idAsignarCategoriaEncriptado = $post['idAsignarCategoria'];
                $nombreProducto = strtoupper($post['nombreProducto']);
                $precio = $post['precio'];
                $caracteristica1 = $post['caracteristica1'];
                $caracteristica2 = $post['caracteristica2'];
                $descripcionProducto = $post['descripcionProducto'];
                $fotos = $post['fotosProducto'];
                $principal = $post['principal'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idAsignarCategoriaEncriptado == NULL || $idAsignarCategoriaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($objMetodos->comprobarCadena($nombreProducto) == false || strlen($nombreProducto) > 50  || $nombreProducto == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">INGRESE EL NOMBRE DEL PRODUCTO MÁXIMO 50 CARACTERES (NO USAR CARACTERES ESPECIALES)</div>';
                }else if(!is_numeric($precio)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL PRECIO DEBEN SER SÓLO NUMEROS</div>';
                }else if($objMetodos->comprobarCadena($descripcionProducto) == FALSE || strlen($descripcionProducto) > 450){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO USAR CARACTERES ESPECIALES EN LA DESCRIPCIÓN (MÁXIMO 450 CARACTERES)</div>';
                }else if($objMetodos->comprobarCadena($caracteristica1) == FALSE || strlen($caracteristica1) > 200){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO USAR CARACTERES ESPECIALES EN LA CARACTERÍSTICA 1(MÁXIMO 200 CARACTERES)</div>';
                }else if($objMetodos->comprobarCadena($caracteristica2) == FALSE || strlen($caracteristica2) > 200){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO USAR CARACTERES ESPECIALES EN LA CARACTERÍSTICA 2(MÁXIMO 200 CARACTERES)</div>';
                }else if(empty($fotos)){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR SELECCIONE UNA FOTO</div>';
                }else if($principal != "0" && $principal != "1" && $principal != "2"){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR SELECCIONE UNA FOTO PRINCIPAL VÁLIDA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $idAsignarCategoria = $objMetodos->desencriptar($idAsignarCategoriaEncriptado);
                            if(!is_numeric($idAsignarCategoria)){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaAsignarCategoria =  $objAsignarCategoria->filtrarAsignarCategoriaProductoActivo($idAsignarCategoria);
                                if(count($listaAsignarCategoria) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else if($listaAsignarCategoria[0]['idTienda'] != $idTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTA CATEGORÍA NO PERTENECE A SU TIENDA</div>';
                                }else{
                                    ini_set('date.timezone','America/Bogota'); 
                                    $hoy = getdate();
                                    $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                                    $validarImagenes = TRUE;
                                    for($i=0; $i<count($fotos); $i++)
                                    {
                                        $image = $fotos[$i];
                                        if($image['type'] != 'image/jpeg' && $image['type'] != 'image/jpg')
                                        {
                                            $validarImagenes = FALSE;
                                            break;
                                        }
                                    }
                                    if($validarImagenes == FALSE){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">TODAS LAS IMÁGENES DEBEN SER FORMATO JPG o JPG</div>';
                                    }else{
                                        $arrayProducto = array(
                                            'idTienda'=>$idTienda,
                                              'idAsignarCategoriaProducto'=>$idAsignarCategoria,
                                              'nombreProducto'=>$nombreProducto,
                                              'descripcionProducto'=>$descripcionProducto,
                                              'stock'=>0,
                                              'fechaIngreso'=>$fechaSubida,
                                              'estado'=>TRUE
                                          );
//                                    
                                        $idProducto = $objProductos->ingresarProducto($arrayProducto);
                                        if($idProducto == 0){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE INGRESÓ EL PRODUCTO POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                        }else{
                                            $arrayPrecioProducto = array(
                                                'idProducto'=>$idProducto,
                                                'precio'=>$precio,
                                                'fechaIngresoPrecio'=>$fechaSubida,
                                                'fechaEliminado'=>NULL,
                                                'estado'=>TRUE
                                            );
                                            if($objPrecioProducto->ingresarPrecioProducto($arrayPrecioProducto) == 0){
                                                $objProductos->eliminarProducto($idProducto);
                                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE INGRESÓ EL PRODUCTO POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                            }else{
                                                
                                                if($caracteristica1 != ""){
                                                    $arrayCaracteristica = array(
                                                        'idProducto'=>$idProducto,
                                                        'descripcion'=>$caracteristica1,
                                                        'fechaIngreso'=>$fechaSubida,
                                                        'estado'=>TRUE
                                                    );
                                                    $objCaracteristicasProducto->ingresarcaracteristicaProducto($arrayCaracteristica);
                                                }
                                                
                                                if($caracteristica2 != ""){
                                                    $arrayCaracteristica2 = array(
                                                        'idProducto'=>$idProducto,
                                                        'descripcion'=>$caracteristica2,
                                                        'fechaIngreso'=>$fechaSubida,
                                                        'estado'=>TRUE
                                                    );
                                                    $objCaracteristicasProducto->ingresarcaracteristicaProducto($arrayCaracteristica2);
                                                }
                                                $nombreFechaFoto = $hoy['year'].$hoy['mon'].$hoy['mday'].$hoy['hours'].$hoy['minutes'].$hoy['seconds'];
                                                for($i=0; $i < count($fotos); $i++)
                                                {
                                                    $image = $fotos[$i];
                                                    $name = $image['name'];
                                                    $trozos = explode('.',$name);
                                                    $ext = end($trozos);
                                                    $nombreFinalImagen = $this->nombrefotoAction(10, TRUE, TRUE, FALSE).$nombreFechaFoto.'.'.$ext;
                                                    $destino = '/public/images/productos/'.$nombreFinalImagen;
                                                    $src = $_SERVER['DOCUMENT_ROOT'].$this->getRequest()->getBaseUrl().$destino;

                                                   $rutaImagenOriginal = $image['tmp_name'];
                                                    $img_original = imagecreatefromjpeg($rutaImagenOriginal);

                                                    $max_ancho = 500;
                                                    $max_alto = 500;
                                                    list($ancho,$alto)=getimagesize($rutaImagenOriginal);
                                                    $x_ratio = $max_ancho / $ancho;
                                                    $y_ratio = $max_alto / $alto;
                                                    if( ($ancho <= $max_ancho) && ($alto <= $max_alto) ){
                                                        $ancho_final = $ancho;
                                                        $alto_final = $alto;
                                                    }else if (($x_ratio * $alto) < $max_alto){
                                                        $alto_final = ceil($x_ratio * $alto);
                                                        $ancho_final = $max_ancho;
                                                    }else{
                                                        $ancho_final = ceil($y_ratio * $ancho);
                                                        $alto_final = $max_alto;
                                                    }
                                                    $img_base = $_SERVER['DOCUMENT_ROOT'].$this->getRequest()->getBaseUrl().'/public/images/otras/imagenbase.jpg';
                                                    $img_base = imagecreatefromjpeg($img_base);
                                                    $crop_x = 0;
                                                    $crop_y = 0;
                                                    if($ancho > $alto){
                                                        $crop_y = ($ancho_final -  $alto_final)/2;
                                                    }else if($alto > $ancho){
                                                        $crop_x = ($alto_final - $ancho_final)/2;
                                                    }
                                                    imagecopyresampled($img_base,$img_original,$crop_x,$crop_y,0,0,$ancho_final, $alto_final,$ancho,$alto);
                                                    imagedestroy($img_original); 
                    //                                            FIN REDIMENSION
                    //                                             GUARDAR IMAGEN
                                                    if(imagejpeg($img_base,$src,100))
                                                    {
                                                        $estadoPrincipal = 0;
                                                        if($principal == $i){
                                                            $estadoPrincipal = TRUE;
                                                        }
                                                        $arrayFotoProducto = array(
                                                            'idProducto'=>$idProducto,
                                                            'rutaFoto'=>$destino,
                                                            'principal'=>$estadoPrincipal,
                                                            'fechaSubida'=>$fechaSubida,
                                                            'estado'=>TRUE
                                                        );
                                                        $idFoto = $objFotosProducto->ingresarFotoProducto($arrayFotoProducto);
                                                        if($idFoto == 0){
                                                            unlink($src);
                                                        }
                                                    }      
//                                                    FIN GUARDAR IMAGEN
                                                }
                                                $mensaje = '<div class="alert alert-success text-center" role="alert">PRODUCTO GUARDADO EXITOSAMENTE</div>';
                                                $validar = TRUE;
                                                return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'idAsignarCategoria'=>$idAsignarCategoriaEncriptado));
                                                
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    
    public function nombrefotoAction($length,$uc,$n,$sc)
    {
        $source = 'abcdefghijklmnopqrstuvwxyz';
        if($uc==1) $source .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
        if($n==1) $source .= '1234567890'; 
        if($sc==1) $source .= '|@#~$%()=^*+[]{}-_'; 
        if($length>0)
        { 
            $rstr = ""; 
            $source = str_split($source,1);
            for($i=1; $i<=$length; $i++)
            { 
                mt_srand((double)microtime() * 1000000); 
                $num = mt_rand(1,count($source)); 
                $rstr .= $source[$num-1];  
            }   
        } 
        return $rstr;
    }
    
    public function filtrarcategoriaproductoAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
            
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['id'];
                $codigoEncriptado = $post['cod1'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $listaAsignarCategoriaProducto = $this->dbAdapter->query("select * 
                                        from `asignarcategoriaproducto` inner join `categoriaproducto` 
                                        on `asignarcategoriaproducto`.`idCategoria` = `categoriaproducto`.`idCategoriaProducto`
                                        where `asignarcategoriaproducto`.`idTienda` = $idTienda and `asignarcategoriaproducto`.`perteneceA` is NULL
                                        and `asignarcategoriaproducto`.`estado` = true
                                        order by `categoriaproducto`.`descripcionCategoria` asc ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                            $categoriaProducto = "";
                            if(count($listaAsignarCategoriaProducto) > 0){
                                $subcategoriaProducto = '';
                                $i = 0;
                                foreach ($listaAsignarCategoriaProducto as $valueCategorias) {
                                    $perteneceA = $valueCategorias['idCategoria'];
                                    $idAsignarCategoriaEncriptado = $objMetodos->encriptar($valueCategorias['idAsignarCategoriaProducto']);
                                    $subcategoriaProducto = $this->obtenerSubcategoriaAction($idTienda, $perteneceA,"",$i);
                                    $i = $subcategoriaProducto['contador'];
                                    if($subcategoriaProducto['validar'] == 0){
                                        $categoriaProducto = $categoriaProducto.'
                                            <div class="panel panel-default">
                                              <div class="panel-heading">
                                                  <h4 class="panel-title"><a class="finalMenu" style="cursor: pointer;" onclick="cargandoProducto();obtenerProductos(\''.$idAsignarCategoriaEncriptado.'\');">'.$valueCategorias['descripcionCategoria'].'</a></h4>
                                              </div>
                                          </div>';
                                    }else{
                                        $categoriaProducto = $categoriaProducto.'
                                            <div class="panel panel-default">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    <a data-toggle="collapse" data-parent="#'.$i.'" href="#'.$i.'" class="collapsed">
                                                        <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                                                        '.$valueCategorias['descripcionCategoria'].'
                                                    </a>
                                                </h4>
                                            </div>
                                            <div id="'.$i.'" class="panel-collapse collapse" style="height: 0px;">
                                                <div class="panel-body">
                                                    <ul>
                                                        '.$subcategoriaProducto['menu'].'
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>';
                                    }
                                    $i++;
                                }
                            }else{
                                $categoriaProducto = "";
                            }
                            $tabla = '<h2 class="title text-center">CATEGORÍAS</h2><div class="left-sidebar">
                                <div class=" panel-group category-products" id="accordian">
                                    '.$categoriaProducto.'
                                </div>
                                </div>';
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
  
    public function obtenerSubcategoriaAction($idTienda,$perteneceA,$menu,$i){
       $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
       $objMetodos = new Metodos();
       $listaAsignarCategoria = $this->dbAdapter->query("select * 
                    from `asignarcategoriaproducto` inner join `categoriaproducto` 
                    on `asignarcategoriaproducto`.`idCategoria` = `categoriaproducto`.`idCategoriaProducto`
                    where `asignarcategoriaproducto`.`idTienda` = $idTienda and `asignarcategoriaproducto`.`perteneceA` = $perteneceA 
                    and `asignarcategoriaproducto`.`estado` = true
                    order by `categoriaproducto`.`descripcionCategoria` asc ",Adapter::QUERY_MODE_EXECUTE)->toArray();
       if(count($listaAsignarCategoria) == 0){
           $array = array(
               'menu'=>$menu,
               'validar'=>0,
               'contador'=>$i
           );
           return $array;
       }else{
            foreach ($listaAsignarCategoria as $valueAsignarCategoria) {
                $idAsignarCategoriaEncriptado = $objMetodos->encriptar($valueAsignarCategoria['idAsignarCategoriaProducto']);
                $idCategoria = $valueAsignarCategoria['idCategoria'];
                
                
                if($idCategoria != $perteneceA){
                    $subCategoria = $this->obtenerSubcategoriaAction($idTienda, $idCategoria,"",$i);
                }else{
                    $subCategoria = array(
                        'menu'=>$menu,
                        'validar'=>0,
                        'contador'=>$i
                    );
                }
                
                
                $i = $subCategoria['contador'];
                if($subCategoria['validar'] == 0){
                    $objMetodos = new Metodos();
                    $idAsignarCategoriaEncriptado = $objMetodos->encriptar($valueAsignarCategoria['idAsignarCategoriaProducto']);
                    $menu = $menu.'<div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title"><a class="finalMenu" style="cursor: pointer;" onclick="cargandoProducto();obtenerProductos(\''.$idAsignarCategoriaEncriptado.'\');" >'.$valueAsignarCategoria['descripcionCategoria'].'</a></h4>
                            </div>
                        </div>';
                }else{
                    $menu = $menu.'
                            <div class="panel panel-default">
                            <div class="panel-heading">
                                <h4 class="panel-title">
                                    <a data-toggle="collapse" data-parent="#cp'.$i.'" href="#cp'.$i.'" class="">
                                        <span class="badge pull-right"><i class="fa fa-plus"></i></span>
                                        '.$valueAsignarCategoria['descripcionCategoria'].'
                                    </a>
                                </h4>
                            </div>
                            <div id="cp'.$i.'" class="panel-collapse in" style="height: auto;">
                                <div class="panel-body">
                                    <ul>
                                        '.$subCategoria['menu'].'
                                    </ul>
                                </div>
                            </div>
                        </div>';
                }
                $i++;
            }
            $array2 = array(
               'menu'=>$menu,
               'validar'=>1,
               'contador'=>$i
           );
           return $array2;
       }
    }
    public function filtrarproductosporcategoriaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTiendas = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMonedas = new Monedas($this->dbAdapter);
                $objFotoProducto = new FotosProducto($this->dbAdapter);
                $objCaracteristicaProducto = new CaracteristicasProducto($this->dbAdapter);
                $objAsignarCategoria = new AsignarCategoriaProducto($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idAsignarCategoriaProductoEncriptado = $post['id'];
                $codigoEncriptado = $post['cod1'];
                $idTiendaEncriptado = $post['cod2'];
                if($idAsignarCategoriaProductoEncriptado == NULL || $idAsignarCategoriaProductoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE ENCUENTRA LA CATEGORÍA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                    }else{
                        $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                        if(!is_numeric($idTienda)){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                        }else{
                            $listaTienda = $objTiendas->filtrarTiendaActivo($idTienda);
                            if(count($listaTienda) != 1){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                            }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                            }else{
                                $listaMoneda = $objMonedas->filtrarMonedaActivo($listaTienda[0]['idMoneda']);
                                $moneda = '';
                                if(count($listaMoneda) > 0){
                                    $moneda = $listaMoneda[0]['simbolo'];
                                }
                                $idAsignarCategoriaProducto = $objMetodos->desencriptar($idAsignarCategoriaProductoEncriptado);
                                if(!is_numeric($idAsignarCategoriaProducto)){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                }else{
                                    $listaAsignarCategoriaProducto = $objAsignarCategoria->filtrarAsignarCategoriaProductoActivo($idAsignarCategoriaProducto);
                                    if(count($listaAsignarCategoriaProducto) != 1){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">ESTA CATEGORÍA NO EXISTE O NO PERTENECE A SU TIENDA</div>';
                                    }else if($listaAsignarCategoriaProducto[0]['idTienda'] != $listaTienda[0]['idTienda']){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                                    }else{
                                        $listaProductosPorCategoria = $this->dbAdapter->query("select * 
                                        from `productos`
                                        where `productos`.`idAsignarCategoriaProducto` = $idAsignarCategoriaProducto
                                        order by `productos`.`idProducto` desc ",Adapter::QUERY_MODE_EXECUTE)->toArray();

                                        $array1 = array();
                                        $i = 0;
                                        $j = count($listaProductosPorCategoria);
                                        foreach ($listaProductosPorCategoria as $value) {
                                            
                                            $idProductoEncriptado = $objMetodos->encriptar($value['idProducto']);
                                            $codigo = $value['idProducto'];
                                            if(strlen($codigo) < 10){
                                                $totalCod = 10 - strlen($codigo);
                                                for ($k = 0; $k < $totalCod ; $k++){
                                                    $codigo = '0'.$codigo;
                                                }
                                            } 
                                            
                                            $listaFotoProducto = $objFotoProducto->filtrarFotoProductoPrincipalPorProductoActivo($value['idProducto']);
                                            $btnVerFotos = '<img style="cursor: pointer;" data-toggle="modal" data-target="#modalForm" onclick="filtrarFotosProducto(\''.$idProductoEncriptado.'\');" class="img-responsive" src="'.$this->getRequest()->getBaseUrl().'/public/images/otras/nodisponible.png" alt="">';
                                            if(count($listaFotoProducto) == 1){
                                                $btnVerFotos = '<img style="cursor: pointer;" data-toggle="modal" data-target="#modalForm" onclick="filtrarFotosProducto(\''.$idProductoEncriptado.'\');" class="img-responsive" src="'.$this->getRequest()->getBaseUrl().$listaFotoProducto[0]['rutaFoto'].'" alt="">';
                                            }
                                            $btnEliminarProducto = '<button title="ELIMINAR '.$value['nombreProducto'].'" id="btnEliminarProducto'.$i.'" data-loading-text="Eliminando..." onclick="eliminarProducto(\''.$idProductoEncriptado.'\','.$i.')" class="btn btn-danger btn-xs btn-square">Eliminar</button>';
                                            $color = '';
                                            $btnEstado = '<button title="DESHABILITAR '.$value['nombreProducto'].'" id="btnDeshabilitarProducto'.$i.'" data-loading-text="Deshabilitando..." onclick="deshabilitarPorducto(\''.$idProductoEncriptado.'\','.$i.','.$j.')" class="btn btn-success btn-xs btn-square">Habilitado</button>';
                                            if($value['estado'] == FALSE){
                                                $color='style="background-color: #FED6CE;"';
                                                $btnEstado = '<button title="HABILITAR '.$value['nombreProducto'].'"  id="btnDeshabilitarProducto'.$i.'" data-loading-text="Habilitando..." onclick="deshabilitarPorducto(\''.$idProductoEncriptado.'\','.$i.','.$j.')" class="btn btn-danger btn-xs btn-square">Deshabilitado</button>';
                                            }
                                            
                                            $btnDescripcionProducto = '<button data-toggle="modal" data-target="#modalFormDescripcion" onclick="filtrarDescripcionProducto(\''.$idProductoEncriptado.'\');" class="btn btn-info btn-xs btn-square">Ver</button>';
                                            
                                            $botones = $btnEliminarProducto.' '.$btnEstado;
                                            $listaCaracteristicasProducto = $objCaracteristicaProducto->filtrarCaracteristicaProductoPorProducto($value['idProducto']);
                                            $botonCaracteristicas = '';
                                            if(count($listaCaracteristicasProducto) < 10){
                                                $botonCaracteristicas = '<button data-toggle="modal" data-target="#modalFormCaracteristica" onclick="cargandoCaracteristica();filtrarCaracteristicaProducto(\''.$idProductoEncriptado.'\');" class="btn btn-warning btn-xs btn-square">Ver</button>';
                                            }
                                            $precio = '<a title="MODIFICAR PRECIO" onclick="cargandoPrecio();filtrarPrecioProducto(\''.$idProductoEncriptado.'\')" data-toggle="modal" data-target="#modalFormPrecio" style="cursor: pointer;">VER</a>';
                                            $array1[$i] = array(
                                                'idProducto'=>$j,
                                                'codigo'=>'NL'.$codigo,
                                                'nombreProducto'=>'<div '.$color.' >'.$value['nombreProducto'].'</div>',
                                                'precio'=>$precio,
                                                'descripcionProducto'=>$value['descripcionProducto'],
                                                'fotosProducto'=>$btnVerFotos,
                                                'caracteristicaProducto'=>$botonCaracteristicas,
                                                'descripcionProducto'=>$btnDescripcionProducto,
                                                'fechaIngreso'=>'<div '.$color.' >'.$value['fechaIngreso'].'</div>',
                                                'opciones'=>$botones,
                                            );
                                            $j--;
                                            $i++;
                                        }
                                        $mensaje = '';
                                        $validar = TRUE;
                                        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$array1));
                                    
                                    }
                                }
                            }
                        }
                    }
                }
                
            }
        }
        return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
    }
}