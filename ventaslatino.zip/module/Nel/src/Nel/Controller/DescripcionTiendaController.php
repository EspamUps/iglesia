<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Modelo\Entity\Tiendas;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\DescripcionTienda;
use Zend\Session\Container;

class DescripcionTiendaController extends AbstractActionController
{
    public $dbAdapter;
    public function modifcardescripciontiendaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objDescripcionTienda = new DescripcionTienda($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $idTiendaEncriptado = $post['idTiendaDescripcionTienda'];
                $codigoEncriptado = $post['cod3DescripcionTienda'];
                $descripcionTienda = $post['descripcionTienda'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if( $objMetodos->comprobarCadena($descripcionTienda) == FALSE){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR LA DESCRIPCIÓN NO DEBE ESTAR EN BLANCO NI CONTENER CARACTERES ESPECIALES</div>';
                }else if(strlen($descripcionTienda) > 455 || strlen($descripcionTienda) == 0){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">LA DESCRIPCIÓN DE LA TIENDA NO DEBE SUPERAR LOS 455 CARACTERES</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTienda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            
                            ini_set('date.timezone','America/Bogota'); 
                            $hoy = getdate();
                            $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                            $listaDescripcionTienda = $objDescripcionTienda->filtrarDescripcionTiendaPorTiendaActivo($idTienda);
                            if(count($listaDescripcionTienda) > 1){
                                $validarMT = true;
                                foreach ($listaDescripcionTienda as $value) {
                                    $idDescripcionTiendaF = $value['idDescripcionTienda'];
                                    $arrayDescripcionTiendaM = array(
                                        'fechaDesignacion'=>$fechaSubida,
                                        'estado'=>0
                                    );
                                    if($objDescripcionTienda->actualizarDescripcionTienda($idDescripcionTiendaF, $arrayDescripcionTiendaM) == FALSE){
                                        $validarMT = FALSE;
                                        break;
                                    }
                                }
                                if($validarMT == FALSE){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ LA DESCRIPCIÓN DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                }else{
                                    $arrayDescripcionTienda = array(
                                        'idTienda'=>$idTienda,
                                        'descripcionTienda'=>$descripcionTienda,
                                        'fechaAsignacion'=>$fechaSubida,
                                        'fechaDesignacion'=>NULL,
                                        'estado'=>TRUE
                                    );
                                    if($objDescripcionTienda->ingresarDescripcionTienda($arrayDescripcionTienda) == 0){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ LA DESCRIPCIÓN DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                    }else{
                                        $mensaje = '<div class="alert alert-success text-center" role="alert">MODIFICADO EXITOSAMENTE</div>';
                                        $validar = TRUE;
                                    }
                                    
                                }
                            }else if(count($listaDescripcionTienda) == 1){
                                if($objMetodos->compararFechas($fechaSubida, $listaDescripcionTienda[0]['fechaAsignacion']) <= 15){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">DEBEN PASAR 15 DÍAS PARA QUE PUEDA MODIFICAR LA DESCRIPCIÓN</div>';
                                }else if($listaDescripcionTienda[0]['descripcionTienda'] == $descripcionTienda){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE HA MODIFICADO LA DESCRIPCIÓN</div>';
                                }else{
                                
                                
                                    $idDescripcionTienda = $listaDescripcionTienda[0]['idDescripcionTienda'];
                                    $arraDescripcionTienda = array(
                                        'fechaDesignacion'=>$fechaSubida,
                                        'estado'=>0
                                    );
                                    if($objDescripcionTienda->actualizarDescripcionTienda($idDescripcionTienda, $arraDescripcionTienda) == FALSE){
                                        $mensaje = '<div class="alert alert-success text-center" role="alert">MODIFICADO EXITOSAMENTE</div>';
                                    }else{
                                        $arrayDescripcionTienda = array(
                                            'idTienda'=>$idTienda,
                                            'descripcionTienda'=>$descripcionTienda,
                                            'fechaAsignacion'=>$fechaSubida,
                                            'fechaDesignacion'=>NULL,
                                            'estado'=>TRUE
                                        );
                                        if($objDescripcionTienda->ingresarDescripcionTienda($arrayDescripcionTienda) == 0){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ LA DESCRIPCIÓN DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                        }else{
                                            $mensaje = '<div class="alert alert-success text-center" role="alert">MODIFICADO EXITOSAMENTE</div>';
                                            $validar = TRUE;
                                        }
                                    }
                                }
                            }else{
                                $arrayDescripcionTienda = array(
                                    'idTienda'=>$idTienda,
                                    'descripcionTienda'=>$descripcionTienda,
                                    'fechaAsignacion'=>$fechaSubida,
                                    'fechaDesignacion'=>NULL,
                                    'estado'=>TRUE
                                );
                                if($objDescripcionTienda->ingresarDescripcionTienda($arrayDescripcionTienda) == 0){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE MODIFIÓ LA DESCRIPCIÓN DE LA TIENDA POR FAVOR COMUNÍQUESE CON NEL - LATINO</div>';
                                }else{
                                    $mensaje = '<div class="alert alert-success text-center" role="alert">MODIFICADO EXITOSAMENTE</div>';
                                    $validar = TRUE;
                                }
                            }
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'id'=>$idTiendaEncriptado));
                        }
                    }
                    
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
}