<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\NombreTienda;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\Tiendas;
use Zend\Session\Container;


class ConfiguracionController extends AbstractActionController
{
    public $dbAdapter;
    
    public function pedidosAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $idUsuario = $sesionUsuario->offsetGet('idUsuario');
            $nombreUsuario = $this->getEvent()->getRouteMatch()->getParam('id');
            $objMetodos = new Metodos();
            if($nombreUsuario == NULL || $nombreUsuario == "" || $objMetodos->comprobarCadena($nombreUsuario) == FALSE){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
            }else{
                $this->layout('layout/inicio');
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $listaCodigo2 = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                $listaCodigo5 = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                $codigo2 = $objMetodos->encriptar($listaCodigo2[0]['nombreCodigo']);
                $codigo3 = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                $codigo5 = $objMetodos->encriptar($listaCodigo5[0]['nombreCodigo']);
                $listaTienda = $objTienda->filtrarTiendaPorNombreUsuarioActivo($nombreUsuario);
                if(count($listaTienda) != 1){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else{
                    $idTienda = $listaTienda[0]['idTienda'];
                    $idTiendaEncriptado = $objMetodos->encriptar($idTienda);
                    $array = array(
                        'codigo2'=>$codigo2,
                        'codigo3'=>$codigo3,
                        'codigo5'=>$codigo5,
                        'nombreUsuarioEncriptado'=>$objMetodos->encriptar($nombreUsuario),
                        'idTiendaEncriptado'=>$idTiendaEncriptado,
                        'nombreUsuario'=>$nombreUsuario
                    );
                    return new ViewModel($array);
                }
            }
        }
    }
    
    
    
    
    
    
    
    
    
    
    public function tiendaAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        
        if(!$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $idUsuario = $sesionUsuario->offsetGet('idUsuario');
            $nombreUsuario = $this->getEvent()->getRouteMatch()->getParam('id');
            $objMetodos = new Metodos();
            if($nombreUsuario == NULL || $nombreUsuario == "" || $objMetodos->comprobarCadena($nombreUsuario) == FALSE){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
            }else{
                $this->layout('layout/inicio');
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
                $codigo3 = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                $listaTienda = $objTienda->filtrarTiendaPorNombreUsuarioActivo($nombreUsuario);
                if(count($listaTienda) != 1){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else{
                    $idTienda = $listaTienda[0]['idTienda'];
                    $idTiendaEncriptado = $objMetodos->encriptar($idTienda);
                    $array = array(
                        'codigo'=>$codigo,
                        'codigo3'=>$codigo3,
                        'nombreUsuarioEncriptado'=>$objMetodos->encriptar($nombreUsuario),
                        'idTiendaEncriptado'=>$idTiendaEncriptado,
                        'nombreUsuario'=>$nombreUsuario
                    );
                    return new ViewModel($array);
                }
            }
        }
    }
    
    public function productosAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $idUsuario = $sesionUsuario->offsetGet('idUsuario');
            $nombreUsuario = $this->getEvent()->getRouteMatch()->getParam('id');
            $objMetodos = new Metodos();
            if($nombreUsuario == NULL || $nombreUsuario == "" || $objMetodos->comprobarCadena($nombreUsuario) == FALSE){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
            }else{
                $this->layout('layout/inicio');
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objNombreTienda = new NombreTienda($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                $listaCodigo2 = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(4);
                $listaCodigo4 = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
                $codigo2 = $objMetodos->encriptar($listaCodigo2[0]['nombreCodigo']);
                $codigo3 = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                $codigo4 = $objMetodos->encriptar($listaCodigo4[0]['nombreCodigo']);
                $listaTienda = $objTienda->filtrarTiendaPorNombreUsuarioActivo($nombreUsuario);
                if(count($listaTienda) != 1){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else{
                    $idTienda = $listaTienda[0]['idTienda'];
                    
                    $listaNombreTienda = $objNombreTienda->filtrarNombreTiendaPorTiendaActivo($idTienda);
                    $nombreTienda = 'NOMBRE NO ESTABLECIDO';
                    if(count($listaNombreTienda) == 1){
                        $nombreTienda = $listaNombreTienda[0]['nombreTienda'];
                    }
                    $array = array(
                        'nombreTienda'=>$nombreTienda,
                        'codigo'=>$codigo,
                        'codigo2'=>$codigo2,
                        'codigo3'=>$codigo3,
                        'codigo4'=>$codigo4,
                        'idTiendaEncriptado'=>$objMetodos->encriptar($idTienda),
                        'nombreUsuario'=>$nombreUsuario
                    );
                    return new ViewModel($array);
                }
            }
        }
    }

    public function contactodirAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        
        if(!$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $idUsuario = $sesionUsuario->offsetGet('idUsuario');
            $nombreUsuario = $this->getEvent()->getRouteMatch()->getParam('id');
            $objMetodos = new Metodos();
            if($nombreUsuario == NULL || $nombreUsuario == "" || $objMetodos->comprobarCadena($nombreUsuario) == FALSE){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
            }else{
                $this->layout('layout/inicio');
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objNombreTienda = new NombreTienda($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
                $codigo3 = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                $listaTienda = $objTienda->filtrarTiendaPorNombreUsuarioActivo($nombreUsuario);
                if(count($listaTienda) != 1){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else{
                    $idTienda = $listaTienda[0]['idTienda'];
                    $idTiendaEncriptado = $objMetodos->encriptar($idTienda);
                    $listaNombreTienda = $objNombreTienda->filtrarNombreTiendaPorTiendaActivo($idTienda);
                    $nombreTienda = 'NOMBRE NO ESTABLECIDO';
                    if(count($listaNombreTienda) == 1){
                        $nombreTienda = $listaNombreTienda[0]['nombreTienda'];
                    }
                    $array = array(
                        'nombreTienda'=>$nombreTienda,
                        'codigo'=>$codigo,
                        'codigo3'=>$codigo3,
                        'nombreUsuarioEncriptado'=>$objMetodos->encriptar($nombreUsuario),
                        'nombreUsuario'=>$nombreUsuario,
                        'idTiendaEncriptado'=>$idTiendaEncriptado
                    );
                    return new ViewModel($array);
                }
            }
        }
    }
    
    
    public function categoriasAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $idUsuario = $sesionUsuario->offsetGet('idUsuario');
            $nombreUsuario = $this->getEvent()->getRouteMatch()->getParam('id');
            $objMetodos = new Metodos();
            if($nombreUsuario == NULL || $nombreUsuario == "" || $objMetodos->comprobarCadena($nombreUsuario) == FALSE){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
            }else{
                $this->layout('layout/inicio');
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objNombreTienda = new NombreTienda($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                $listaCodigo2 = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                $listaCodigo3 = $objCodigos->filtrarCodigoPorNumeroActivo(4);
                $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
                $codigo2 = $objMetodos->encriptar($listaCodigo2[0]['nombreCodigo']);
                $codigo3 = $objMetodos->encriptar($listaCodigo3[0]['nombreCodigo']);
                $listaTienda = $objTienda->filtrarTiendaPorNombreUsuarioActivo($nombreUsuario);
                if(count($listaTienda) != 1){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else{
                    $idTienda = $listaTienda[0]['idTienda'];
                    $listaNombreTienda = $objNombreTienda->filtrarNombreTiendaPorTiendaActivo($idTienda);
                    $nombreTienda = 'NOMBRE NO ESTABLECIDO';
                    if(count($listaNombreTienda) == 1){
                        $nombreTienda = $listaNombreTienda[0]['nombreTienda'];
                    }
                    $array = array(
                        'nombreUsuario'=>$nombreUsuario,
                        'nombreTienda'=>$nombreTienda,
                        'codigo'=>$codigo,
                        'codigo2'=>$codigo2,
                        'codigo3'=>$codigo3,
                        'idTiendaEncriptado'=>$objMetodos->encriptar($idTienda)
                    );
                    return new ViewModel($array);
                }
            }
        }
    }

}