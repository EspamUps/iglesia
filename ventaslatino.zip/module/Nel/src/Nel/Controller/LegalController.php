<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
class LegalController extends AbstractActionController
{
    public $dbAdapter;

    public function reembolsoAction()
    {
        set_time_limit(600);
        $this->layout('layout/layout');
        return new ViewModel();
    }
    
    public function terminosycondicionesAction()
    {
        set_time_limit(600);
        $this->layout('layout/layout');
        return new ViewModel();
    }
    
    public function privacidadAction()
    {
        set_time_limit(600);
        $this->layout('layout/layout');
        return new ViewModel();
    }
  
}