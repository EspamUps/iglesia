<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\Cantones;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter;

class ParroquiaCantonController extends AbstractActionController
{
    public $dbAdapter;
    public function filtrarparroquiacantonporcantonAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCanton = new Cantones($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idCantonEncriptado = $post['idCanton'];
                $codigoEncriptado = $post['cod1'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idCantonEncriptado == NULL || $idCantonEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $listaCodigo6 = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $idCanton = $objMetodos->desencriptar($idCantonEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo6[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idCanton)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else {
                        $listaCanton = $objCanton->filtrarCantonActivo($idCanton);
                        if(count($listaCanton) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE EL CANTÓN SELECCIONADO</div>';
                        }else{
                             $listaParroquiaCanton = $this->dbAdapter->query("select * 
                                        from `parroquiacanton` inner join  `parroquias` on `parroquiacanton`.`idParroquia` = `parroquias`.`idParroquia`
                                        where `parroquiacanton`.`idCanton` = $idCanton and `parroquiacanton`.`estadoParroquiaCanton` = true
                                        order by `parroquias`.`nombreParroquia` asc ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                            $optionParroquias = '<option value="0">SELECCIONE UNA PARROQUIA</option>';
                            if(count($listaParroquiaCanton) == 0){
                                $optionParroquias = '<option value="0">SELECCIONE UNA PARROQUIA</option>';
                            }else{
                                foreach ($listaParroquiaCanton as $valueParroquiaCanton) {
                                    $idParroquiaEncriptado = $objMetodos->encriptar($valueParroquiaCanton['idParroquia']);
                                    $optionParroquias = $optionParroquias.'<option value="'.$idParroquiaEncriptado.'">'.$valueParroquiaCanton['nombreParroquia'].'</option>';
                                }
                            }
                            $tabla = $optionParroquias;
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
}