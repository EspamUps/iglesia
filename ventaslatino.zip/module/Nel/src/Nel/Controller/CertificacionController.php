<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Modelo\Entity\Tiendas;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\Certificacion;
use Nel\Modelo\Entity\FotosProducto;
use Nel\Modelo\Entity\Planes;
use Nel\Modelo\Entity\Paginas;
use Nel\Modelo\Entity\Productos;
use Nel\Modelo\Entity\CaracteristicasProducto;
use Zend\Session\Container;



class CertificacionController extends AbstractActionController
{
    public $dbAdapter;


    public function subircertificacionAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCertificacion = new Certificacion($this->dbAdapter);
                $objPlanes  = new Planes($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $codigoEncriptado = $post['cod'];
                $fotos = $post['fotoComprobante'];
                $plan = "";
                if(isset($post['planCertificacion'])){
                   $plan = $post['planCertificacion']; 
                }
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if(empty($fotos)){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR SELECCIONE UNA FOTO</div>';
                }else if($plan == ""){
                    $mensaje='<div class="alert alert-danger text-center" role="alert">POR FAVOR SELECCIONE UN PLAN</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $idPlan = $objMetodos->desencriptar($plan);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idPlan)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaPlan = $objPlanes->filtrarPlanActivo($idPlan);
                        if(count($listaPlan) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            ini_set('date.timezone','America/Bogota'); 
                            $hoy = getdate();
                            $fechaSubida = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                            $image = $fotos;
                            if($image['type'] != 'image/jpeg' && $image['type'] != 'image/jpg'){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">LAS IMÁGENES DEBEN SER FORMATO JPG o JPG</div>';
                            }else{
                                $listaCertificacion = $objCertificacion->filtrarCertificacionPorUsuarioFechasActivo($idUsuario);
                                if(count($listaCertificacion) > 0){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">UD YA TIENE UN COMPROBANTE EN ESPERA DE VERIFICACIÓN</div>';
                                }else{
                                    $nombreFechaFoto = $hoy['year'].$hoy['mon'].$hoy['mday'].$hoy['hours'].$hoy['minutes'].$hoy['seconds'];
                                    $name = $image['name'];
                                    $trozos = explode('.',$name);
                                    $ext = end($trozos);
                                    $nombreFinalImagen = $this->nombrefotoAction(10, TRUE, TRUE, FALSE).$nombreFechaFoto.'.'.$ext;
                                    $destino = '/public/images/comprobantes/'.$nombreFinalImagen;
                                    $src = $_SERVER['DOCUMENT_ROOT'].$this->getRequest()->getBaseUrl().$destino;
                                    
                                    if(move_uploaded_file($image['tmp_name'],$src))
                                    {
                                        $arrayComprobante = array(
                                            'idUsuario'=>$idUsuario,
                                            'idPlan'=>$idPlan,
                                            'rutaDocumento'=>$destino,
                                            'fechaSubida'=>$fechaSubida,
                                            'fechaInicio'=>NULL,
                                            'fechaFin'=>NULL,
                                            'estado'=>0
                                        );
                                        $idCertificacion = $objCertificacion->ingresarCertificacion($arrayComprobante);
                                        if($idCertificacion == 0){
                                            unlink($src);
                                        }
                                    }      
                                    $mensaje = '<div class="alert alert-success text-center" role="alert">FOTO GUARDADA EXITOSAMENTE</div>';
                                    $validar = TRUE;
                                    }
                                }
                            }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    public function nombrefotoAction($length,$uc,$n,$sc)
    {
        $source = 'abcdefghijklmnopqrstuvwxyz';
        if($uc==1) $source .= 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'; 
        if($n==1) $source .= '1234567890'; 
        if($sc==1) $source .= '|@#~$%()=^*+[]{}-_'; 
        if($length>0)
        { 
            $rstr = ""; 
            $source = str_split($source,1);
            for($i=1; $i<=$length; $i++)
            { 
                mt_srand((double)microtime() * 1000000); 
                $num = mt_rand(1,count($source)); 
                $rstr .= $source[$num-1];  
            }   
        } 
        return $rstr;
    }

   
}