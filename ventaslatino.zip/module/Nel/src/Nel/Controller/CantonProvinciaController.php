<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\Provincias;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter;

class CantonProvinciaController extends AbstractActionController
{
    public $dbAdapter;
    public function filtrarcantonprovinciaporprovinciaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objProvincias = new Provincias($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $idProvinciaEncriptado = $post['idProvincia'];
                $codigoEncriptado = $post['cod1'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idProvinciaEncriptado == NULL || $idProvinciaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $listaCodigo6 = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $idProvincia = $objMetodos->desencriptar($idProvinciaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo6[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idProvincia)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaProvincia = $objProvincias->filtrarProvinciaActivo($idProvincia);
                        if(count($listaProvincia) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA PROVINCIA</div>';
                        }else{
                             $listaCantonProvincia = $this->dbAdapter->query("select * 
                                        from `cantonprovincia` inner join  `cantones` on `cantonprovincia`.`idCanton` = `cantones`.`idCanton`
                                        where `cantonprovincia`.`idProvincia` = $idProvincia and `cantonprovincia`.`estadoCantonProvincia` = true
                                        order by `cantones`.`nombreCanton` asc ",Adapter::QUERY_MODE_EXECUTE)->toArray();
                            $optionCantones = '<option value="0">SELECCIONE UN CANTÓN</option>';
                            if(count($listaCantonProvincia) == 0){
                                $optionCantones = '<option value="0">SELECCIONE UN CANTÓN</option>';
                            }else{
                                foreach ($listaCantonProvincia as $valueCantonProvincia) {
                                    $idCantonEncriptado = $objMetodos->encriptar($valueCantonProvincia['idCanton']);
                                    $optionCantones = $optionCantones.'<option value="'.$idCantonEncriptado.'">'.$valueCantonProvincia['nombreCanton'].'</option>';
                                }
                            }
                            $tabla = $optionCantones;
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
}