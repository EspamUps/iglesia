<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\Usuario;
use Nel\Modelo\Entity\FotoTienda;
use Nel\Modelo\Entity\Paginas;
use Nel\Modelo\Entity\NombreTienda;
use Zend\Session\Container;
use Zend\Db\Adapter\Adapter;

class UsuarioController extends AbstractActionController
{
    public $dbAdapter;
    public function actualizarcontrasenaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCodigos = new Codigos($this->dbAdapter);
                $objUsuario = new Usuario($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $codigoEncriptado = $post['cod3Contrasena'];
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $contrasena1 = $post['contrasena1'];
                $contrasena2 = $post['contrasena2'];
                $contrasena3 = $post['contrasena3'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if(strlen ($contrasena1) < 8 || $objMetodos->comprobarCadena($contrasena1) == FALSE && strpos($contrasena1, ' ') == FALSE){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">INGRESE SU CONTRASEÑA ACTUAL SIN ESPACIOS MIN. 8 CARACTERES, SÓLO ESTOS CARACTERES ESPECIALES SE PERMITEN(-_)</div>';
                }else if(strlen ($contrasena2) < 8 || $objMetodos->comprobarCadena($contrasena2) == FALSE && strpos($contrasena2, ' ') == FALSE){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">INGRESE LA NUEVA CONTRASEÑA SIN ESPACIOS MIN. 8 CARACTERES, SÓLO ESTOS CARACTERES ESPECIALES SE PERMITEN(-_)</div>';
                }else if($contrasena2 != $contrasena3){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">LAS CONTRASEÑAS NO COINCIDEN</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaUsuario = $objUsuario->filtrarUsuario($idUsuario);
                        if(count($listaUsuario) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE EL USUARIO</div>';
                        }else{
                            $contrasenaReal = $objMetodos->desencriptar($listaUsuario[0]['contrasena']);
                            if($contrasenaReal != $contrasena1){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">LA CONTRASEÑA INGRESADA NO ES CORRECTA</div>';
                            }else{
                                $array = array(
                                    'contrasena'=>$objMetodos->encriptar($contrasena2)
                                );
                                if($objUsuario->actualizarUsuario($idUsuario, $array) == FALSE){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE INGRESÓ LA CONTRASEÑA POR FAVOR INTENTE MÁS TARDE</div>';
                                }else{
                                    $mensaje = 'CONTRASEÑA ACTUALIZADA CORRECTAMENTE';
                                    $validar = TRUE;
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    
}