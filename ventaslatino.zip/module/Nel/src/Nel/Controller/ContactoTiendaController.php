<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Nel\Metodos\Metodos;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\Tiendas;
use Nel\Modelo\Entity\ContactoTienda;
use Zend\Session\Container;

class ContactoTiendaController extends AbstractActionController
{
    public $dbAdapter;
    public function filtrarcontactotiendaAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCodigos = new Codigos($this->dbAdapter);
                $objTieda = new Tiendas($this->dbAdapter);
                $objContactoTienda = new ContactoTienda($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $codigoEncriptado = $post['cod1'];
                $idTiendaEncriptado = $post['id'];
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $listaCodigo6 = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo6[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTiendas = $objTieda->filtrarTiendaActivo($idTienda);
                        if(count($listaTiendas) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTiendas[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $listaContactoTienda = $objContactoTienda->filtrarContactoTiendaPorTiendaActivo($idTienda);
                            $contactoTienda = ''; 
                            if(count($listaContactoTienda) == 0 || count($listaContactoTienda) > 1){
                                $listaCodigo2 = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                                $codigoModal = $objMetodos->encriptar($listaCodigo2[0]['nombreCodigo']);
                                $contactoTienda = '<input value="'.$codigoModal.'" id="codMod" name="codMod" type="hidden" class="form-control" >
                                    <h4>Correo: <input id="correo" name="correo" type="text" class="form-control" ></h4>
                                    <h4>Teléfono: <input id="telefono" name="telefono" type="text" class="form-control" ></h4>
                                    <h4>Whatsapp: <input id="whatsapp" name="whatsapp" type="text" class="form-control" ></h4>
                                    <h4>Facebook: <input id="facebook" name="facebook" type="text" class="form-control" ></h4>
                                    <button onclick="guardarContactos(\''.$idTiendaEncriptado.'\');" class="btn btn-primary btn-sm btn-square" type="button" id="btnGuardarContacto" data-loading-text="GUARDANDO...">GUARDAR</button>';
                            }else if(count($listaContactoTienda) == 1){
                                $listaCodigo2 = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                                $codigoModal = $objMetodos->encriptar($listaCodigo2[0]['nombreCodigo']);
                                $contactoTienda = '<input  value="'.$codigoModal.'" id="codMod" name="codMod" type="hidden" class="form-control" >
                                        <h4>Correo: <input value="'.$listaContactoTienda[0]['correo'].'" id="correo" name="correo" type="text" class="form-control" ></h4>
                                    <h4>Teléfono: <input value="'.$listaContactoTienda[0]['telefono'].'" id="telefono" name="telefono" type="text" class="form-control" ></h4>
                                    <h4>Whatsapp: <input value="'.$listaContactoTienda[0]['whatsapp'].'" id="whatsapp" name="whatsapp" type="text" class="form-control" ></h4>
                                    <h4>Facebook: <input value="'.$listaContactoTienda[0]['facebook'].'" id="facebook" name="facebook" type="text" class="form-control" ></h4>
                                    <button onclick="guardarContactos(\''.$idTiendaEncriptado.'\');" class="btn btn-primary btn-sm btn-square" type="button" id="btnGuardarContacto" data-loading-text="GUARDANDO...">GUARDAR</button>';
                            } 
                            $tabla = $contactoTienda;
                            $mensaje = '';
                            $validar = TRUE;
                            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar,'tabla'=>$tabla));
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    
    public function guardarcontactosAction()
    {
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo') || !$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
            $validar = false;
            $request=$this->getRequest();
            if(!$request->isPost()){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
            }else{
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objCodigos = new Codigos($this->dbAdapter);
                $objTieda = new Tiendas($this->dbAdapter);
                $objContactoTienda = new ContactoTienda($this->dbAdapter);
                $objMetodos = new Metodos();
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $codigoEncriptado = $post['codMod'];
                $idTiendaEncriptado = $post['id'];
                $idUsuario = $sesionUsuario->offsetGet('idUsuario');
                $correo = trim($post['correo']);
                $telefono = trim($post['telefono']);
                $whats = trim($post['whatsapp']);
                $face = trim($post['faceb']);
                
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if($idTiendaEncriptado == NULL || $idTiendaEncriptado == ""){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENETE VULNERAR EL SISTEMA</div>';
                }else if(filter_var($correo,FILTER_VALIDATE_EMAIL) == FALSE){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL CORREO INGRESADO NO ES VÁLIDO</div>';
                }else if(!is_numeric($telefono)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL TELÉFONO INGRESADO NO ES VÁLIDO</div>';
                }else if(!is_numeric($whats)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL WHATSAPP INGRESADO NO ES VÁLIDO</div>';
                }else if(filter_var($face,FILTER_VALIDATE_URL) == FALSE){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">LA URL INGRESADA NO ES VÁLIDA</div>';
                }else{
                    $codigo = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNombreActivo($codigo);
                    $listaCodigoInsert = $objCodigos->filtrarCodigoPorNumeroActivo(5);
                    $listaCodigoModif = $objCodigos->filtrarCodigoPorNumeroActivo(3);
                    $idTienda = $objMetodos->desencriptar($idTiendaEncriptado);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigoInsert[0]['nombreCodigo'] && $listaCodigo[0]['nombreCodigo'] != $listaCodigoModif[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else if(!is_numeric($idTienda)){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        $listaTienda = $objTieda->filtrarTiendaActivo($idTienda);
                        if(count($listaTienda) != 1){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE LA TIENDA</div>';
                        }else if($listaTienda[0]['idUsuario'] != $idUsuario){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                        }else{
                            $listaContactoTienda = $objContactoTienda->filtrarContactoTiendaPorTiendaActivo($idTienda);
                            if(count($listaContactoTienda) == 0){
                                $arrayContactoTienda = array(
                                    'idTienda'=>$idTienda,
                                    'correo'=>$correo,
                                    'telefono'=>$telefono,
                                    'whatsapp'=>$whats,
                                    'facebook'=>$face,
                                    'estado'=>TRUE
                                );
                                if($objContactoTienda->ingresarContactoTienda($arrayContactoTienda) == 0){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE COMPLETARON LOS CAMBIOS POR FAVOR COMUNIQUESE CON LA EMPRESA</div>';
                                }else{
                                    $mensaje = '<div class="alert alert-success text-center" role="alert">CAMBIOS REALIAZADOS CORRECTAMENTE</div>';
                                    $validar = TRUE; 
                                }
                            }else if(count($listaContactoTienda) == 1){
                                $arrayContactoTienda = array(
                                    'correo'=>$correo,
                                    'telefono'=>$telefono,
                                    'whatsapp'=>$whats,
                                    'facebook'=>$face,
                                    'estado'=>TRUE
                                );
                                if($objContactoTienda->actualizarContactoTienda($idTienda,$arrayContactoTienda) == FALSE){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE COMPLETARON LOS CAMBIOS POR FAVOR COMUNIQUESE CON LA EMPRESA</div>';
                                }else{
                                    $mensaje = '<div class="alert alert-success text-center" role="alert">CAMBIOS REALIAZADOS CORRECTAMENTE</div>';
                                    $validar = TRUE; 
                                }
                            }else if(count($listaContactoTienda) > 1){
                                $arrayContactoTienda1 = array(
                                    'estado'=>0
                                );
                                if($objContactoTienda->actualizarContactoTienda($idTienda,$arrayContactoTienda1) == FALSE){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE COMPLETARON LOS CAMBIOS POR FAVOR COMUNIQUESE CON LA EMPRESA</div>';
                                }else{
                                    $arrayContactoTienda = array(
                                    'idTienda'=>$idTienda,
                                    'correo'=>$correo,
                                    'telefono'=>$telefono,
                                    'whatsapp'=>$whats,
                                    'facebook'=>$face,
                                    'estado'=>TRUE
                                    );
                                    if($objContactoTienda->ingresarContactoTienda($arrayContactoTienda) == 0){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO SE COMPLETARON LOS CAMBIOS POR FAVOR COMUNIQUESE CON LA EMPRESA</div>';
                                    }else{
                                        $mensaje = '<div class="alert alert-success text-center" role="alert">CAMBIOS REALIAZADOS CORRECTAMENTE</div>';
                                        $validar = TRUE; 
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return new JsonModel(array('mensaje'=>$mensaje,'validar'=>$validar));
        }
    }
    
    
}