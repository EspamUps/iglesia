<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Nel\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Nel\Metodos\Metodos;
use Nel\Metodos\Correo;
use Nel\Modelo\Entity\Usuario;
use Nel\Modelo\Entity\NombreTienda;
use Nel\Modelo\Entity\Monedas;
use Nel\Modelo\Entity\Codigos;
use Nel\Modelo\Entity\CredencialesCorreo;
use Nel\Modelo\Entity\Tiendas;
use Nel\Modelo\Entity\Planes;
use Nel\Modelo\Entity\Certificacion;
use Nel\Modelo\Entity\TipoUsuario;
use Nel\Modelo\Entity\Persona;
use Nel\Modelo\Entity\Paginas;
use Zend\Session\Container;
use Zend\Crypt\Password\Bcrypt;

class IndexController extends AbstractActionController
{
    public $dbAdapter;
    
    
    public function recuperarclaveAction()
    {
        set_time_limit(600);
        $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
        $objCodigos = new Codigos($this->dbAdapter);
        $objMetodos = new Metodos();
        $objCorreos = new Correo();
        $objTipoUsuario = new TipoUsuario($this->dbAdapter);
        $objCertificacion = new Certificacion($this->dbAdapter);
        $objPersona = new Persona($this->dbAdapter);
        $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
        $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
        $request=$this->getRequest();
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if($sesionUsuario->offsetExists('correo')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
        }else{
            if(!$request->isPost()){
                 $this->layout('layout/login');
                $array = array(
                    'codigo'=>$codigo,
                    'mensaje'=>'',
                    'correo'=>'',
                    'ruc'=>''
                );
                return new ViewModel($array);            
            }else{
                $this->layout('layout/login');
                $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
                $objUsuario = new Usuario($this->dbAdapter);
                $objCredenciales = new CredencialesCorreo($this->dbAdapter);
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $correo = trim($post['correo']);
                $ruc = trim($post['ruc']);
                $codigoEncriptado = $post['cod'];
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                     $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                }else if(!filter_var ($correo,FILTER_VALIDATE_EMAIL)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL CORREO INGRESADO NO ES VÁLIDO</div>';
                }else if(is_numeric($ruc) == FALSE){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">EL RUC DEBE ESTAR COMPUESTO DE SÓLO NÚMEROS</div>';
                }else{
                    $cod = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($cod);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        if($objMetodos->comprobarCadena($correo) == FALSE){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA</div>';
                        }else{
                            $listaUsuario = $objUsuario->filtrarUsuarioPorCorreo($correo);
                            if(count($listaUsuario) != 1){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE UN USUARIO CON EL CORREO '.$correo.'</div>';
                            }else{
                                $listaTipoUsuario =  $objTipoUsuario->filtrarTipoUsuario($listaUsuario[0]['idTipoUsuario']);
                                if(count($listaTipoUsuario) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE EL TIPO USUARIO</div>';
                                }else if($listaTipoUsuario[0]['numeroTipoUsuario'] != 2){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA</div>';
                                }else{
                                    if($listaUsuario[0]['estado'] == FALSE){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">SU CUENTA NO HA SIDO HABILITADA POR LO TANTO NO PODEMOS RECUPERAR SU CONTRASEÑA</div>';
                                    }else{
                                        
                                        
                                        $listaCertificacion = $objCertificacion->filtrarCertificacionPorUsuarioActivo($listaUsuario[0]['idUsuario']);
                                        
                                        
                                        
                                        if(count($listaCertificacion) == 0){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO CUENTA CON UN PLAN ACTIVO POR LO TANTO NO PODEMOS RECUPERAR SU CONTRASEÑA.</div>';
                                        }else if(count($listaCertificacion) == 1){
                                            if($listaUsuario[0]['estado'] == FALSE){
                                                $mensaje = '<div class="alert alert-danger text-center" role="alert">SU CUENTA HA EXPIRADO POR LO TANTO NO PODEMOS RECUPERAR SU CONTRASEÑA.</div>';
                                            }else{
                                                $idPersona = $listaUsuario[0]['idPersona'];
                                                $listaPersona = $objPersona->filtrarPersona($idPersona);
                                                if(count($listaPersona) != 1){
                                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL CORREO '.$correo.' NO ESTÁ RELACIONADO CON UN RUC.</div>';
                                                }else if($listaPersona[0]['identificacion'] != $ruc){
                                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL CORREO '.$correo.' NO ESTÁ RELACIONADO CON EL RUC INGRESADO.</div>';
                                                }else{
                                                    $listaCredenciales = $objCredenciales->obtenerCredencialesActivo();
                                                    if(count($listaCredenciales) != 1){
                                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INTERNO DEL SISTEMA. COMUNÍCATE CON NEL - LATINO</div>';
                                                    }else{
                                                        
                                                        $destinatario = $listaUsuario[0]['correo'];
                                                        $emisor = $listaCredenciales[0]['correo'];
                                                        $contrasena = $listaCredenciales[0]['contrasena'];
                                                        $servidor = $listaCredenciales[0]['servidor'];
                                                        $puerto = $listaCredenciales[0]['puerto'];
                                                        $nombre = $listaCredenciales[0]['nombre'];
                                                        $asunto = 'RECUPERACIÓN  DE CONTRASEÑA NEL - LATINO';
                                                        
                                                        $cuerpo = '<html>'.
                                                            '<head><title>'.$asunto.'</title></head>
                                                            <body><h1>SU CONTRASEÑA ES: </h1>
                                                            '.$objMetodos->desencriptar($listaUsuario[0]['contrasena']).'
                                                            <hr>
                                                            Enviado por NEL - LATINO
                                                            </body>
                                                            </html>';
 
                                                       $objCorreos->enviarCorreo($destinatario, $emisor, $contrasena, $asunto, $cuerpo, $nombre, $servidor, $puerto);
                                                            
                                                            $mensaje = '<div class="alert alert-success text-center" role="alert">SU CONTRASEÑA HA SIDO ENVIADA A SU CORREO ELECTRÓNICO</div>';
                                                            $array = array(
                                                                'codigo'=>$codigo,
                                                                'mensaje'=>$mensaje,
                                                                'correo'=>'',
                                                                'ruc'=>''
                                                            );
                                                            return new ViewModel($array);
                                                        
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $array = array(
                'codigo'=>$codigo,
                'mensaje'=>$mensaje,
                'correo'=>$correo,
                'ruc'=>$ruc
            );
            return new ViewModel($array);
        }
    }
    
    
    
    
    
    
    public function renovacionAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('idUsuario')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $this->layout('layout/renovar');
            $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
            $objCodigos = new Codigos($this->dbAdapter);
            $objCertificacion = new Certificacion($this->dbAdapter);
            $objMetodos = new Metodos();
            $objMonedas = new Monedas($this->dbAdapter);
            $objPlanes = new Planes($this->dbAdapter);
            $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(5);
            $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
            $listaPlanes = $objPlanes->obtenerPlanesActivos();
            $listaMoneda = $objMonedas->obtenerMonedaActivo();
            $simboloMoneda = '';
            $idUsuario = $sesionUsuario->offsetGet('idUsuario');
            if(count($listaMoneda) == 1){
                $simboloMoneda = $listaMoneda[0]['simbolo'];
            }
            
            $listaCertificacion = $objCertificacion->filtrarCertificacionPorUsuarioFechasActivo($idUsuario);
            $listaCertificacion2 = $objCertificacion->filtrarCertificacionPorUsuarioActivo($idUsuario);
            $tabla = '';
            if(count($listaCertificacion) == 1){
                $tabla = '<table class="table table-condensed">
                        <thead>
                            <tr class="cart_menu">
                               
                            </tr>
                        </thead><tbody><tr><h2>GRACIAS POR REACTIVAR TU CUENTA UN AGENTE DE NEL - LATINO 
                        VERIFICARÁ EL DEPOSITO Y ACTIVARÁ TU CUENTA EN UN LAPSO DE 24 HORAS POR FAVOR CIERRA LA SESIÓN 
                        HASTA QUE SEAS NOTIFICADO AL CORREO ELECTRÓNICO</h2> </tr></tbody></table>';
            }else if(count($listaCertificacion2) == 0){
                $cuerpoTabla = '';
                foreach ($listaPlanes as $value) {
                    $cuerpoTabla = $cuerpoTabla.'<tr>
                                <td class="cart_product">
                                    '.$value['nombrePlan'].'
                                </td>
                                <td class="cart_price">
                                    '.$value['descripcionPlan'].'
                                </td>
                                <td class="cart_total">
                                    <p class="cart_total_price">'.$simboloMoneda.' '.$value['precio'].'</p>
                                </td>
                                <td class="">
                                    <input style="cursor:pointer;" value="'.$objMetodos->encriptar($value['idPlan']).'" name="planCertificacion" id="planCertificacion" type="radio" class="form-control">
                                </td>
                            </tr>';
                }

                $inputFile = '<input type="hidden" name="cod" id="cod" value="'.$codigo.'">
                            <div class="form-group col-sm-12 text-center" >
                                <h6></h6>
                                <div  class="fileUpload btn btn-danger btn-square">
                                    <span>SELECCIONE LA FOTO DEL COMPROBANTE</span>
                                    <input type="file" id="fotoComprobante" name="fotoComprobante" class="upload form-control" onchange=" vistaPreviaComprobante();" accept="image/jpeg" />
                                </div>
                            </div>
                            <br />
                            <output id="contenedorVistaPreviaComprobante" class="col-sm-12 text-center" ></output>
                            <div id="contenedorBtnGuardarComprobante" class="col-sm-12 text-center"></div>';

                $tabla = '<table class="table table-condensed">
                        <thead>
                            <tr class="cart_menu">
                                <td class="image">Plan</td>
                                <td class="quantity">Tiempo</td>
                                <td class="total">Precio</td>
                                <td></td>
                            </tr>
                        </thead><tbody>'.$cuerpoTabla.'</tbody></table>'.$inputFile;
                
            }else if(count($listaCertificacion2) == 1){
              
                 $tabla = '<table class="table table-condensed">
                    <thead>
                        <tr class="cart_menu">

                        </tr>
                    </thead><tbody><tr><h2>TU CUENTA YA ESTA ACTIVA CIERRA LA SESIÓN E INICIALA OTRA VEZ</h2> </tr></tbody></table>';
            }
            
            
            
            $array = array(
                'codigo'=>$codigo,
                'tabla'=>$tabla
            );
            return new ViewModel($array);
        }
    }
    
    
    
    public function indexAction()
    {
        set_time_limit(600);
       
        $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
        $objCodigos = new Codigos($this->dbAdapter);
        $objMetodos = new Metodos();
        $objTipoUsuario = new TipoUsuario($this->dbAdapter);
        $objCertificacion = new Certificacion($this->dbAdapter);
        $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
        $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
        $request=$this->getRequest();
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if($sesionUsuario->offsetExists('correo')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
        }else{
            if(!$request->isPost()){
                 $this->layout('layout/login');
                $array = array(
                    'codigo'=>$codigo,
                    'mensaje'=>'',
                    'correo'=>'',
                    'contrasena'=>''
                );
                return new ViewModel($array);            
            }else{
                 $this->layout('layout/login');
                $mensaje = '<div class="alert alert-danger text-center" role="alert">OCURRIÓ UN ERROR INESPERADO</div>';
                $objUsuario = new Usuario($this->dbAdapter);
            
                $post = array_merge_recursive(
                    $request->getPost()->toArray(),
                    $request->getFiles()->toArray()
                );
                $correo = trim($post['correo']);
                $contrasena = trim($post['contrasena']);
                $codigoEncriptado = $post['cod'];
                
                
                if($codigoEncriptado == NULL || $codigoEncriptado == ""){
                     $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                }else if(!filter_var ($correo,FILTER_VALIDATE_EMAIL)){
                    $mensaje = '<div class="alert alert-danger text-center" role="alert">EL CORREO INGRESADO NO ES VÁLIDO</div>';
                }else if($objMetodos->comprobarCadena($contrasena) == FALSE){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                }else{
                    $cod = $objMetodos->desencriptar($codigoEncriptado);
                    $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                    $listaCodigo2 = $objCodigos->filtrarCodigoPorNombreActivo($cod);
                    if($listaCodigo[0]['nombreCodigo'] != $listaCodigo2[0]['nombreCodigo']){
                        $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA O SU IP Y MAC SERÁN BLOQUEADAS</div>';
                    }else{
                        if($objMetodos->comprobarCadena($correo) == FALSE){
                            $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA</div>';
                        }else{
                            $listaUsuario = $objUsuario->filtrarUsuarioPorCorreo($correo);
                            if(count($listaUsuario) != 1){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">USUARIO O CONTRASEÑA INCORRECTOS</div>';
                            }else if($contrasena != $objMetodos->desencriptar ($listaUsuario[0]['contrasena'])){
                                $mensaje = '<div class="alert alert-danger text-center" role="alert">USUARIO O CONTRASEÑA INCORRECTOS</div>';
                            }else{
                                
                                $listaTipoUsuario =  $objTipoUsuario->filtrarTipoUsuario($listaUsuario[0]['idTipoUsuario']);
                                if(count($listaTipoUsuario) != 1){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO EXISTE EL TIPO USUARIO</div>';
                                }else if($listaTipoUsuario[0]['numeroTipoUsuario'] != 2){
                                    $mensaje = '<div class="alert alert-danger text-center" role="alert">NO INTENTE VULNERAR EL SISTEMA</div>';
                                }else{
                                    $listaCertificacion2 = $objCertificacion->filtrarCertificacionPorUsuario($listaUsuario[0]['idUsuario']);
                                    if(count($listaCertificacion2) == 0){
                                        $mensaje = '<div class="alert alert-danger text-center" role="alert">SU CUENTA NO HA SIDO ACTIVADA POR FAVOR ESPERE UN LAPSO DE 24 HORAS MÁXIMO</div>';
                                    }else{ 
                                        if($listaUsuario[0]['estado'] == FALSE){
                                            $mensaje = '<div class="alert alert-danger text-center" role="alert">SU CUENTA NO ESTÁ HABILITADA</div>';
                                        }else{
                                        
                                            $sesionUsuario->offsetSet('idUsuario',$listaUsuario[0]['idUsuario']);
                                            $sesionUsuario->offsetSet('correo', $listaUsuario[0]['correo']);
                                            $sesionUsuario->offsetSet('contrasena', $listaUsuario[0]['contrasena']);
                                            $listaCertificacion = $objCertificacion->filtrarCertificacionPorUsuarioActivo($listaUsuario[0]['idUsuario']);
                                            if(count($listaCertificacion) != 1){
                                                $mensaje = '<div class="alert alert-danger text-center" role="alert">SU CUENTA NO HA SIDO ACTIVADA POR FAVOR ESPERE UN LAPSO DE 24 HORAS MÁXIMO</div>';
                                            }else{
                                                ini_set('date.timezone','America/Bogota'); 
                                                $hoy = getdate();
                                                $fechaActual = $hoy['year']."-".$hoy['mon']."-".$hoy['mday']." ".$hoy['hours'].":".$hoy['minutes'].":".$hoy['seconds'];
                                                if($objMetodos->compararFechas($listaCertificacion[0]['fechaFin'],$fechaActual) <= 0){
                                                    if($listaCertificacion[0]['estado'] == TRUE){
                                                        $array = array(
                                                            'estado'=>0
                                                        );
                                                       $objCertificacion->actualizarCertificacion($listaCertificacion[0]['idCertificacion'], $array);
                                                    }
                                                    $sesionUsuario->offsetSet('certificacion', FALSE);
                                                }else{
                                                    $sesionUsuario->offsetSet('certificacion', TRUE);
                                                }
                                                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                                                
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $array = array(
                'codigo'=>$codigo,
                'mensaje'=>$mensaje,
                'correo'=>$correo,
                'contrasena'=>$contrasena
            );
            return new ViewModel($array);
            
        }
    }
    
    public function mistiendasAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $this->layout('layout/inicio');
            $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
            $objCodigos = new Codigos($this->dbAdapter);
            $objMetodos = new Metodos();
            $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
            $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
            $array = array(
                'codigo'=>$codigo,
            );
            return new ViewModel($array);
        }
    }
    
    public function configuracionAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if(!$sesionUsuario->offsetExists('correo')){
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $nombreUsuario = $this->getEvent()->getRouteMatch()->getParam('id');
            $objMetodos = new Metodos();
            if($nombreUsuario == NULL || $nombreUsuario == ""){
                $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
            }else{
                $this->layout('layout/inicio');
                $this->dbAdapter=$this->getServiceLocator()->get('Zend\Db\Adapter');
                $objTienda = new Tiendas($this->dbAdapter);
                $objPagina = new Paginas($this->dbAdapter);
                $objNombreTienda = new NombreTienda($this->dbAdapter);
                $objCodigos = new Codigos($this->dbAdapter);
                $listaCodigo = $objCodigos->filtrarCodigoPorNumeroActivo(2);
                $codigo = $objMetodos->encriptar($listaCodigo[0]['nombreCodigo']);
                $listaTienda = $objTienda->filtrarTiendaPorNombreUsuarioActivo($nombreUsuario);
                $listaPagina = $objPagina->filtrarPaginaActivo(3);
                if(count($listaPagina) != 1){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }elseif(count($listaTienda) != 1){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else if($listaTienda[0]['idUsuario'] != $sesionUsuario->offsetGet('idUsuario')){
                    $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/mistiendas');
                }else{
                    $idTienda = $listaTienda[0]['idTienda'];
                    $listaNombreTienda = $objNombreTienda->filtrarNombreTiendaPorTiendaActivo($idTienda);
                    $nombreTienda = 'NOMBRE NO ESTABLECIDO';
                    if(count($listaNombreTienda) == 1){
                        $nombreTienda = $listaNombreTienda[0]['nombreTienda'];
                    }
                    $miPagina = $listaPagina[0]['rutaPagina'].'/index/tienda/'.$nombreUsuario;
                    $array = array(
                        'nombreTienda'=>$nombreTienda,
                        'codigo'=>$codigo,
                        'nombreUsuario'=>$nombreUsuario,
                        'miPagina'=>$miPagina
                    );
                    return new ViewModel($array);
                }
            }
        }
    }
    
    public function salirAction()
    {
        set_time_limit(600);
        $sesionUsuario = new Container('cberSesionUsuarioNeLLatino');
        if($sesionUsuario->offsetExists('correo')){
            $sesionUsuario->offsetUnset('idUsuario');
            $sesionUsuario->offsetUnset('correo');
            $sesionUsuario->offsetUnset('contrasena');
            $sesionUsuario->offsetUnset('certificacion');
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }else{
            $this->redirect()->toUrl($this->getRequest()->getBaseUrl().'/index/index');
        }
    }

}