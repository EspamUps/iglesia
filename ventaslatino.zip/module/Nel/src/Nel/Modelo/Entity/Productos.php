<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Nel\Modelo\Entity;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

class Productos extends TableGateway
{
    public function __construct(Adapter $adapter = null, $databaseSchema = null, ResultSet $selectResultPrototype = null)
    {
        return parent::__construct('productos', $adapter, $databaseSchema, $selectResultPrototype);
    }
    
//    public  function obtenerUsuarios()
//    {
//        return  $this->select()->toArray();
//    }
//  
    
    public function filtrarProductosPorAsignarCategoriaActivo($idAsignarCategoriaProducto)
    {
        return $this->select(array('idAsignarCategoriaProducto=?'=>$idAsignarCategoriaProducto,'estado=?'=>true))->toArray();
    }
    public function filtrarProductosPorAsignarCategoria($idAsignarCategoriaProducto)
    {
        return $this->select(array('idAsignarCategoriaProducto=?'=>$idAsignarCategoriaProducto))->toArray();
    }
    public function filtrarProductoActivo($idProducto)
    {
        return $this->select(array('idProducto=?'=>$idProducto,'estado=?'=>true))->toArray();
    }
    
    public function filtrarProducto($idProducto)
    {
        return $this->select(array('idProducto=?'=>$idProducto))->toArray();
    }
    
    public function filtrarProductoPorNombreActivo($nombreProducto)
    {
        return $this->select(array('nombreProducto=?'=>$nombreProducto,'estado=?'=>true))->toArray();
    }
    
    

    
//    public function filtrarUsuarioPorUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    
//    public function login($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    

//    
//    public function filtrarUsuarioPorNombreUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
//    
//    public function filtrarUsuarioPorTipo($idTipoUSuario,$idUsuario)
//    {
//        return $this->select(array('idTipoUsuario=?'=>$idTipoUSuario,'idUsuario !=?'=>$idUsuario))->toArray();
//    }
    
    public function ingresarProducto($array)
    {
        $inserted = $this->insert($array);
        if($inserted)
        {
            return  $this->getLastInsertValue();
        }  else {
            return 0;
        }
    }
    
    public function actualizarProducto($idProducto, $array)
    {
        return (bool) $this->update($array,array('idProducto=?'=>$idProducto));
    }

    public function eliminarProducto($idProducto)
    {
        return $this->delete(array('idProducto=?'=>$idProducto));
    }
   
}