<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Nel\Modelo\Entity;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;

class CaracteristicasProducto extends TableGateway
{
    public function __construct(Adapter $adapter = null, $databaseSchema = null, ResultSet $selectResultPrototype = null)
    {
        return parent::__construct('caracteristicaproducto', $adapter, $databaseSchema, $selectResultPrototype);
    }
    
//    public  function obtenerUsuarios()
//    {
//        return  $this->select()->toArray();
//    }
//  
    public function filtrarCaracteristicaProducto($idCaracteristicaProducto)
    {
        return $this->select(array('idCaracteristicaProducto=?'=>$idCaracteristicaProducto))->toArray();
    }

    
    public function filtrarCaracteristicaProductoPorProductoActivo($idProducto)
    {
        return $this->select(array('idProducto=?'=>$idProducto,'estado=?'=>true))->toArray();
    }
    
    public function filtrarCaracteristicaProductoPorProducto($idProducto)
    {
        return $this->select(array('idProducto=?'=>$idProducto))->toArray();
    }
    
//    public function filtrarUsuarioPorUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    
//    public function login($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    

//    
//    public function filtrarUsuarioPorNombreUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
//    
//    public function filtrarUsuarioPorTipo($idTipoUSuario,$idUsuario)
//    {
//        return $this->select(array('idTipoUsuario=?'=>$idTipoUSuario,'idUsuario !=?'=>$idUsuario))->toArray();
//    }
    
    public function ingresarcaracteristicaProducto($array)
    {
        $inserted = $this->insert($array);
        if($inserted)
        {
            return  $this->getLastInsertValue();
        }  else {
            return 0;
        }
    }
    
//    public function actualizarUsuario($idUsuario, $array)
//    {
//        return (bool) $this->update($array,array('idUsuario=?'=>$idUsuario));
//    }

    public function eliminarCaracteristicaProducto($idCaracteristicaProducto)
    {
        return $this->delete(array('idCaracteristicaProducto=?'=>$idCaracteristicaProducto));
    }
   
}