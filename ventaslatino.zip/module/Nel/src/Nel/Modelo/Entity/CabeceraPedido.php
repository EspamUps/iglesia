<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Nel\Modelo\Entity;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;

class CabeceraPedido extends TableGateway
{
    public function __construct(Adapter $adapter = null, $databaseSchema = null, ResultSet $selectResultPrototype = null)
    {
        return parent::__construct('cabecerapedido', $adapter, $databaseSchema, $selectResultPrototype);
    }
    
//    public  function obtenerUsuarios()
//    {
//        return  $this->select()->toArray();
//    }
//  
    
//    public function filtrarCabeceraPedido($idCabeceraPedido)
//    {
//        return $this->select(array(
//            'idCliente=?'=>$idCliente,
//            'idTienda'=>$idTienda,
//            'rutaDocumentoDeposito'=>$rutaDocumentoDepostio,
//            'rutaDocumentoEnvio'=>$rutaDocumentoEnvio
//            ))->toArray();
//    }
    
    public function filtrarCabeceraPedidoPorClienteTiendaSinCompletar($idCliente,$idTienda,$rutaDocumentoDepostio,$rutaDocumentoEnvio)
    {
        return $this->select(array(
            'idCliente=?'=>$idCliente,
            'idTienda'=>$idTienda,
            'rutaDocumentoDeposito'=>$rutaDocumentoDepostio,
            'rutaDocumentoEnvio'=>$rutaDocumentoEnvio
            ))->toArray();
    }
    
    public function filtrarCabeceraPedido($idCabeceraPedido)
    {
        return $this->select(array('idCabeceraPedido=?'=>$idCabeceraPedido))->toArray();
    }
    
    
//    public function filtrarUsuarioPorUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    
//    public function login($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    

//    
//    public function filtrarUsuarioPorNombreUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
//    
//    public function filtrarUsuarioPorTipo($idTipoUSuario,$idUsuario)
//    {
//        return $this->select(array('idTipoUsuario=?'=>$idTipoUSuario,'idUsuario !=?'=>$idUsuario))->toArray();
//    }
    
    public function ingresarCabeceraPedido($array)
    {
        $inserted = $this->insert($array);
        if($inserted)
        {
            return  $this->getLastInsertValue();
        }  else {
            return 0;
        }
    }
    
    public function actualizarCabeceraPedido($idCabeceraPedido, $array)
    {
        return (bool) $this->update($array,array('idCabeceraPedido=?'=>$idCabeceraPedido));
    }

    public function eliminarCabeceraPedido($idCabeceraPedido)
    {
        return $this->delete(array('idCabeceraPedido=?'=>$idCabeceraPedido));
    }
   
}