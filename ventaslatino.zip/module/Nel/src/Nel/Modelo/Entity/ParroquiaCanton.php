<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Nel\Modelo\Entity;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Where;


class ParroquiaCanton extends TableGateway
{
    public function __construct(Adapter $adapter = null, $databaseSchema = null, ResultSet $selectResultPrototype = null)
    {
        return parent::__construct('parroquiacanton', $adapter, $databaseSchema, $selectResultPrototype);
    }
    public $idCanton;
    public function filtrarParroquiaCantonPorCantonActivo($idCanton)
    {
        $this->idCanton = $idCanton;
        return $this->select(function (Select $select) {
            $select->where->like('estadoParroquiaCanton',TRUE);
            $select->where->like('idCanton', $this->idCanton);
            $select->order('idParroquia ASC');
        })->toArray();
    }
    
    public function filtrarParroquiaCantonPorCantonParroquiaActivo($idCanton,$idParroquia)
    {
        return $this->select(array('idCanton'=>$idCanton,'idParroquia'=>$idParroquia,'estadoParroquiaCanton=?'=>true))->toArray();
    }
    
}