<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Nel\Modelo\Entity;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;

class FotosProducto extends TableGateway
{
    public function __construct(Adapter $adapter = null, $databaseSchema = null, ResultSet $selectResultPrototype = null)
    {
        return parent::__construct('fotoproducto', $adapter, $databaseSchema, $selectResultPrototype);
    }
    
//    public  function obtenerUsuarios()
//    {
//        return  $this->select()->toArray();
//    }
//  
    public function filtrarFotoProductoActivo($idFotoProducto)
    {
        return $this->select(array('idFotoProducto=?'=>$idFotoProducto,'estado=?'=>true))->toArray();
    }
    
    public function filtrarFotoProducto($idFotoProducto)
    {
        return $this->select(array('idFotoProducto=?'=>$idFotoProducto))->toArray();
    }
    public function filtrarFotoProductoPrincipalPorProductoActivo($idProducto)
    {
        return $this->select(array('idProducto=?'=>$idProducto,'principal'=>true,'estado=?'=>true))->toArray();
    }
    
    public function filtrarFotoProductoPorProductoActivo($idProducto)
    {
        return $this->select(array('idProducto=?'=>$idProducto,'estado=?'=>true))->toArray();
    }
    
    public function filtrarFotoProductoPorProducto($idProducto)
    {
        return $this->select(array('idProducto=?'=>$idProducto))->toArray();
    }
    
//    public function filtrarUsuarioPorUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    
//    public function login($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    

//    
//    public function filtrarUsuarioPorNombreUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
//    
//    public function filtrarUsuarioPorTipo($idTipoUSuario,$idUsuario)
//    {
//        return $this->select(array('idTipoUsuario=?'=>$idTipoUSuario,'idUsuario !=?'=>$idUsuario))->toArray();
//    }
    
    public function ingresarFotoProducto($array)
    {
        $inserted = $this->insert($array);
        if($inserted)
        {
            return  $this->getLastInsertValue();
        }  else {
            return 0;
        }
    }
    
    public function actualizarFotoProducto($idFotoProducto, $array)
    {
        return (bool) $this->update($array,array('idFotoProducto=?'=>$idFotoProducto));
    }
    public function actualizarFotoProductoPorProducto($idProducto, $array)
    {
        return (bool) $this->update($array,array('idProducto=?'=>$idProducto));
    }

    public function eliminarFotoProducto($idFotoProducto)
    {
        return $this->delete(array('idFotoProducto=?'=>$idFotoProducto));
    }
   
}