<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Nel\Modelo\Entity;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;

class AsignarCategoriaProducto extends TableGateway
{
    public function __construct(Adapter $adapter = null, $databaseSchema = null, ResultSet $selectResultPrototype = null)
    {
        return parent::__construct('asignarcategoriaproducto', $adapter, $databaseSchema, $selectResultPrototype);
    }
    
//    public  function obtenerUsuarios()
//    {
//        return  $this->select()->toArray();
//    }
//  
    
    public function filtrarAsignarCategoriaProductoPorTiendaActivo($idTienda,$perteneceA)
    {
        return $this->select(array('idTienda=?'=>$idTienda,'perteneceA'=>$perteneceA,'estado=?'=>true))->toArray();
    }
    
        public function filtrarAsignarCategoriaProductoPorCategoriaTiendaActivo($idTienda,$idCategoria,$perteneceA)
    {
        return $this->select(array('idTienda=?'=>$idTienda,'idCategoria'=>$idCategoria,'perteneceA'=>$perteneceA,'estado=?'=>true))->toArray();
    }
    
    public function filtrarAsignarCategoriaProductoActivo($idAsignarCategoriaProducto)
    {
        return $this->select(array('idAsignarCategoriaProducto=?'=>$idAsignarCategoriaProducto,'estado=?'=>true))->toArray();
    }
    
    public function filtrarAsignarCategoriaProducto($idAsignarCategoriaProducto)
    {
        return $this->select(array('idAsignarCategoriaProducto=?'=>$idAsignarCategoriaProducto))->toArray();
    }
    
//    public function filtrarUsuarioPorUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    
//    public function login($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
    

//    
//    public function filtrarUsuarioPorNombreUsuario($nombreUsuario)
//    {
//        return $this->select(array('nombreUsuario=?'=>$nombreUsuario))->toArray();
//    }
//    
//    public function filtrarUsuarioPorTipo($idTipoUSuario,$idUsuario)
//    {
//        return $this->select(array('idTipoUsuario=?'=>$idTipoUSuario,'idUsuario !=?'=>$idUsuario))->toArray();
//    }
    
    public function ingresarAsignarCategoriaProducto($array)
    {
        $inserted = $this->insert($array);
        if($inserted)
        {
            return  $this->getLastInsertValue();
        }  else {
            return 0;
        }
    }
    
    public function actualizarAsignarCategoriaProducto($idAsignarCategoriaProducto, $array)
    {
        return (bool) $this->update($array,array('idAsignarCategoriaProducto=?'=>$idAsignarCategoriaProducto));
    }

    public function eliminarAsignarCategoriaProducto($idAsignarCategoriaProducto)
    {
        return $this->delete(array('idAsignarCategoriaProducto=?'=>$idAsignarCategoriaProducto));
    }
   
}