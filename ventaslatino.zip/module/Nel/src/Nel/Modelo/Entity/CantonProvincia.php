<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Nel\Modelo\Entity;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;



class CantonProvincia extends TableGateway
{
    public function __construct(Adapter $adapter = null, $databaseSchema = null, ResultSet $selectResultPrototype = null)
    {
        return parent::__construct('cantonprovincia', $adapter, $databaseSchema, $selectResultPrototype);
    }

    public $idProvincia;
    public function filtrarCantonProvinciaPorProvinciaActivo($idProvincia)
    {
        $this->idProvincia = $idProvincia;
        return $this->select(function (Select $select) {
            $select->where->like('estadoCantonProvincia',TRUE);
            $select->where->like('idProvincia', $this->idProvincia);
            $select->order('idCanton ASC');
        })->toArray();
    }
    
    
    
    
    public function filtrarCantonProvinciaPorCantonProvinciaActivo($idProvincia,$idCanton)
    {
        return $this->select(array('idProvincia=?'=>$idProvincia,'idCanton'=>$idCanton,'estadoCantonProvincia=?'=>true))->toArray();
    }
    
   
}