<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Nel\Modelo\Entity;

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Adapter\Adapter;

class Pedidos extends TableGateway
{
    public function __construct(Adapter $adapter = null, $databaseSchema = null, ResultSet $selectResultPrototype = null)
    {
        return parent::__construct('pedidos', $adapter, $databaseSchema, $selectResultPrototype);
    }
    
    
    public function filtrarPedidoPorCabecera($idCabeceraPedido)
    {
        return $this->select(array('idCabeceraPedido=?'=>$idCabeceraPedido))->toArray();
    }
    
    public function filtrarPedido($idPedido)
    {
        return $this->select(array('idPedido=?'=>$idPedido))->toArray();
    }
    
    public function filtrarPedidosPorProducto($idProducto)
    {
        return $this->select(array('idProducto=?'=>$idProducto))->toArray();
    }

    
    public function ingresarPedido($array)
    {
        $inserted = $this->insert($array);
        if($inserted)
        {
            return  $this->getLastInsertValue();
        }  else {
            return 0;
        }
    }
    
    public function actualizarPedido($idPedido, $array)
    {
        return (bool) $this->update($array,array('idPedido=?'=>$idPedido));
    }

    public function eliminarPedido($idPedido)
    {
        return $this->delete(array('idPedido=?'=>$idPedido));
    }
   
}